-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 25, 2012 at 10:03 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adminid` varchar(45) NOT NULL,
  `adminpwd` varchar(200) NOT NULL,
  `sid` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `adminid`, `adminpwd`, `sid`) VALUES
(1, 'admin', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(99) NOT NULL,
  `cat_position` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `cat_name`, `cat_position`) VALUES
(37, 'Welcome', 1);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `imageid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=1 AUTO_INCREMENT=35 ;

-- --------------------------------------------------------

--
-- Table structure for table `configurations`
--

CREATE TABLE IF NOT EXISTS `configurations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `maxheight` int(10) unsigned NOT NULL,
  `maxwidth` int(10) unsigned NOT NULL,
  `site_name` varchar(99) NOT NULL,
  `site_tag` varchar(99) NOT NULL,
  `site_title` varchar(99) NOT NULL,
  `meta_desc` varchar(199) NOT NULL,
  `g_track_id` varchar(45) NOT NULL,
  `allow_comments` tinyint(1) NOT NULL,
  `comment_notify` varchar(100) NOT NULL,
  `allow_subs` tinyint(1) NOT NULL,
  `header_display` tinyint(1) NOT NULL,
  `allow_originals` tinyint(1) NOT NULL,
  `image_quality` int(10) unsigned NOT NULL DEFAULT '70',
  `watermark` varchar(100) NOT NULL,
  `footer_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `configurations`
--

INSERT INTO `configurations` (`id`, `maxheight`, `maxwidth`, `site_name`, `site_tag`, `site_title`, `meta_desc`, `g_track_id`, `allow_comments`, `comment_notify`, `allow_subs`, `header_display`, `allow_originals`, `image_quality`, `watermark`, `footer_desc`) VALUES
(1, 800, 800, 'Town Of Pixels', 'Punching Pixes since 2012', 'Town of Pixels', '', '', 1, '', 0, 0, 1, 70, '', 'Town Of Pixels, 2012');

-- --------------------------------------------------------

--
-- Table structure for table `image_uploads`
--

CREATE TABLE IF NOT EXISTS `image_uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `caption` varchar(400) NOT NULL,
  `thumbnail` varchar(45) NOT NULL,
  `actual` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `image_uploads`
--


-- --------------------------------------------------------

--
-- Table structure for table `package_data`
--

CREATE TABLE IF NOT EXISTS `package_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `package_data`
--

INSERT INTO `package_data` (`id`, `version`) VALUES
(1, '1.0.0');

-- --------------------------------------------------------

--
-- Table structure for table `photo_desc`
--

CREATE TABLE IF NOT EXISTS `photo_desc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `image_name` varchar(45) NOT NULL,
  `image_desc` varchar(999) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `photo_desc`
--


-- --------------------------------------------------------

--
-- Table structure for table `plugins`
--

CREATE TABLE IF NOT EXISTS `plugins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plugin_name` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL DEFAULT 'Inactive',
  `navigation` varchar(45) NOT NULL,
  `gallery` varchar(45) NOT NULL,
  `author` varchar(45) NOT NULL,
  `weblink` varchar(45) NOT NULL,
  `publish_date` varchar(45) NOT NULL,
  `description` text NOT NULL,
  `plugin_tech_name` varchar(45) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  PRIMARY KEY (`id`,`plugin_tech_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `plugins`
--

INSERT INTO `plugins` (`id`, `plugin_name`, `status`, `navigation`, `gallery`, `author`, `weblink`, `publish_date`, `description`, `plugin_tech_name`) VALUES
(10, 'Thumbs and Images - 2', 'Inactive', 'false', 'true', 'Abhishek', 'http://ajaxtown.com', '29-08-2010', 'Redeveloped version of Thumbs and Images Plugin. Displays all thumbnails in a row and shows the main image at the bottom. Coverpage feature is unavailable.', 'thumbs_and_images-2'),
(11, 'Thumbs and Images', 'Inactive', 'false', 'true', 'Rajeev', 'http://codegrafix.com', '29-08-2010', 'Shows all thumbanils in a row and displays the full image at the bottom. Comments and Coverpage feature is unavailable in this Plugin', 'thumbs_and_images'),
(12, 'Horizontal Slide', 'Active', 'false', 'true', 'Abhishek Saha', 'http://www.ajaxtown.com', '29-08-2010', 'Shows Images horizontally with sliding option. Displays coverpage and comments.', 'horizontal_slide'),
(14, 'Gallery View', 'Inactive', 'false', 'true', 'Abhishek', 'http://ajaxtown.com', '29-08-2010', 'Gallery view with thumbnails', 'galleryview'),
(15, 'Random Image', 'Inactive', 'false', 'true', 'Abhishek', 'http://ajaxtown.com', '29-08-2010', 'Selects a random image from the database and displays. Best Plugin to be used as default.', 'random_image');

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE IF NOT EXISTS `sub_categories` (
  `sub_cat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sub_name` varchar(45) NOT NULL,
  `sub_cat_position` int(10) unsigned NOT NULL,
  `categoryid` int(10) unsigned NOT NULL,
  `state` varchar(45) NOT NULL DEFAULT 'activate',
  `coverpage` text NOT NULL,
  `coverpagewidth` int(10) unsigned NOT NULL DEFAULT '300',
  `coverpagestatus` int(10) unsigned NOT NULL,
  `linked_plugin` varchar(45) NOT NULL,
  `defaulter` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`sub_cat_id`),
  KEY `FK_sub_categories_1` (`categoryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`sub_cat_id`, `sub_name`, `sub_cat_position`, `categoryid`, `state`, `coverpage`, `coverpagewidth`, `coverpagestatus`, `linked_plugin`, `defaulter`) VALUES
(51, 'Introduction', 2, 37, 'de-activate', '&lt;font color=\\&quot;#ff0000\\&quot; face=\\&quot;Impact\\&quot; size=\\&quot;7\\&quot;&gt;TOWN OF PIXELS&lt;br&gt;&lt;/font&gt;&lt;div align=\\&quot;justify\\&quot;&gt;&lt;font color=\\&quot;#ff0000\\&quot; face=\\&quot;Impact\\&quot; size=\\&quot;7\\&quot;&gt;&lt;font size=\\&quot;3\\&quot;&gt;&lt;font face=\\&quot;Sans Serif\\&quot;&gt;&lt;font color=\\&quot;#bbbbbb\\&quot;&gt;&lt;font size=\\&quot;6\\&quot;&gt;W&lt;/font&gt;elcome to Town of Pixels. I greatly appreciate your decision for using TOP, the open-source web application framework for showcasing your work. I hope you will find this interesting, flexible and easy to use and modify. If you get stuck anywhere, read the&lt;font face=\\&quot;Georgia\\&quot;&gt; &lt;/font&gt;&lt;/font&gt;&lt;/font&gt;&lt;/font&gt;&lt;/font&gt;&lt;font face=\\&quot;Georgia\\&quot;&gt;&lt;a style=\\&quot;color:#00D9FF\\&quot; href=\\&quot;http://townofpixels.com?page=documentation\\&quot; target=\\&quot;_blank\\&quot; alt=\\&quot;documentation\\&quot;&gt;Documentation&lt;/a&gt;&lt;/font&gt;&lt;font color=\\&quot;#ff0000\\&quot; face=\\&quot;Impact\\&quot; size=\\&quot;7\\&quot;&gt;&lt;font size=\\&quot;3\\&quot;&gt;&lt;font face=\\&quot;Sans Serif\\&quot;&gt;&lt;font color=\\&quot;#bbbbbb\\&quot;&gt; for more information. If you have any other questions you can always ask in the Discuss section. If you find any bugs while using this application, make sure you post those bugs in the Discussion section.&amp;nbsp; After you are done creating your website, do not forget to submit your site to Town Of Pixels. It will greatly help you to get visitors and also help TOP to get a bit more popularity.&lt;/font&gt;&lt;/font&gt;&lt;/font&gt;&lt;/font&gt; &lt;br&gt;&lt;br&gt;&lt;font color=\\&quot;#ff0000\\&quot; face=\\&quot;Impact\\&quot; size=\\&quot;7\\&quot;&gt;&lt;font size=\\&quot;3\\&quot;&gt;&lt;font face=\\&quot;Sans Serif\\&quot;&gt;&lt;font color=\\&quot;#bbbbbb\\&quot;&gt;You can login to &lt;font color=\\&quot;#00cccc\\&quot;&gt;&lt;a style=\\&quot;color:#00D9FF\\&quot; href=\\&quot;admin/admin.php\\&quot; alt=\\&quot;Admin Panel\\&quot; target=\\&quot;_blank\\&quot;&gt;Admin Panel&lt;/a&gt;&lt;/font&gt; to start configuring your website.&lt;/font&gt;&lt;/font&gt;&lt;/font&gt;&lt;/font&gt;&lt;br&gt;&lt;br&gt;&lt;font color=\\&quot;#ff0000\\&quot; face=\\&quot;Impact\\&quot; size=\\&quot;7\\&quot;&gt;&lt;font size=\\&quot;3\\&quot;&gt;&lt;font face=\\&quot;Sans Serif\\&quot;&gt;&lt;font color=\\&quot;#bbbbbb\\&quot;&gt;Town Of Pixels will always be a Work-In-Progress as its versions will keep coming with many more exciting features.Thank You for choosing Town Of Pixels.&lt;/font&gt;&lt;/font&gt;&lt;/font&gt;&lt;/font&gt;&lt;br&gt;&lt;/div&gt;', 400, 1, 'horizontal_slide', 0);

-- --------------------------------------------------------

--
-- Table structure for table `theme_editor`
--

CREATE TABLE IF NOT EXISTS `theme_editor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fullbackgroundimg` varchar(300) NOT NULL,
  `fullbackground` varchar(300) NOT NULL,
  `backgroundsize` varchar(300) NOT NULL,
  `backgroundrepeatx` varchar(300) NOT NULL,
  `backgroundrepeaty` varchar(300) NOT NULL,
  `navigation_color` varchar(300) NOT NULL,
  `header_color` varchar(300) NOT NULL,
  `gallery_color` varchar(300) NOT NULL,
  `footer_color` varchar(300) NOT NULL,
  `navigationimage` varchar(300) NOT NULL,
  `navigationrepeatx` varchar(300) NOT NULL,
  `navigationrepeaty` varchar(300) NOT NULL,
  `navigationcatcol` varchar(100) NOT NULL,
  `navigationsubcatcol` varchar(100) NOT NULL,
  `headerimage` varchar(300) NOT NULL,
  `headerrepeatx` varchar(300) NOT NULL,
  `headerrepeaty` varchar(300) NOT NULL,
  `header_font_color` varchar(100) NOT NULL,
  `header_title_color` varchar(100) NOT NULL,
  `galleryimage` varchar(300) NOT NULL,
  `galleryrepeatx` varchar(300) NOT NULL,
  `galleryrepeaty` varchar(300) NOT NULL,
  `footerimage` varchar(300) NOT NULL,
  `footerrepeatx` varchar(300) NOT NULL,
  `footerrepeaty` varchar(300) NOT NULL,
  `footersize` varchar(300) NOT NULL,
  `headersize` varchar(300) NOT NULL,
  `gallerysize` varchar(300) NOT NULL,
  `navigationsize` varchar(300) NOT NULL,
  `comment_bg_color` varchar(100) NOT NULL,
  `comment_bg_opacity` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `theme_editor`
--

INSERT INTO `theme_editor` (`id`, `fullbackgroundimg`, `fullbackground`, `backgroundsize`, `backgroundrepeatx`, `backgroundrepeaty`, `navigation_color`, `header_color`, `gallery_color`, `footer_color`, `navigationimage`, `navigationrepeatx`, `navigationrepeaty`, `navigationcatcol`, `navigationsubcatcol`, `headerimage`, `headerrepeatx`, `headerrepeaty`, `header_font_color`, `header_title_color`, `galleryimage`, `galleryrepeatx`, `galleryrepeaty`, `footerimage`, `footerrepeatx`, `footerrepeaty`, `footersize`, `headersize`, `gallerysize`, `navigationsize`, `comment_bg_color`, `comment_bg_opacity`) VALUES
(1, '', '', '', '', '', '', '', '', '', 'http://icanbecreative.com/res/AbstractBg/dark_colors_abstract-wide.jpg', 'no-repeat', '110% 100%', '#B534E3 ', 'red', '', '', '', '#0095FE ', '#5169BF', '', 'no-repeat', '', '', '', '', '', '', '100% 100%', '25% 100%', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL,
  `subcatid` int(11) NOT NULL,
  `thumbpath` varchar(300) NOT NULL,
  `imagepath` varchar(300) NOT NULL,
  `caption` varchar(500) NOT NULL,
  `tags` varchar(400) NOT NULL,
  `exif` varchar(500) NOT NULL,
  `title` varchar(45) NOT NULL,
  `originalpath` varchar(300) NOT NULL,
  `position` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=225 ;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`id`, `catid`, `subcatid`, `thumbpath`, `imagepath`, `caption`, `tags`, `exif`, `title`, `originalpath`, `position`) VALUES
(222, 37, 51, '/resources/uploads/thumb_AnimalsReptilesSnakeintheGrass032479.jpg', '/resources/uploads/AnimalsReptilesSnakeintheGrass032479.jpg', '', '', '[]', '', '/resources/uploads/originals/AnimalsReptilesSnakeintheGrass032479.jpg', 0),
(223, 37, 51, '/resources/uploads/thumb_Bnature001iq24rjxi.jpg', '/resources/uploads/Bnature001iq24rjxi.jpg', '', '', '[]', '', '/resources/uploads/originals/Bnature001iq24rjxi.jpg', 0),
(224, 37, 51, '/resources/uploads/thumb_IMG17879b.jpg', '/resources/uploads/IMG17879b.jpg', '', '', '{"Make":"Canon","Model":"Canon EOS 7D","ExposureTime":"1\\/400","FNumber":"56\\/10","ISOSpeedRatings":100,"ExifVersion":"0221","ShutterSpeedValue":"565248\\/65536","ApertureValue":"327680\\/65536","ExposureBiasValue":"0\\/1","Flash":16,"FocalLength":"105\\/1","ExifImageWidth":1200,"ExifImageLength":800,"FocalPlaneXResolution":"3888000\\/907","FocalPlaneYResolution":"2592000\\/595"}', '', '/resources/uploads/originals/IMG17879b.jpg', 0);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD CONSTRAINT `FK_sub_categories_1` FOREIGN KEY (`categoryid`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
