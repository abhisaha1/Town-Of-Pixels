<?php
$PATHS_LOADED = TRUE;
function display_header() {
	
	include_once("../config.php");
	include_once("classes/db.class.php");
	include_once("classes/queries.class.php");
	include_once("classes/session.class.php");	
	
	$pbdb = new db(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
	$queries = new queries;
	$session = new session;	
	if(isset($_GET['action']) && $_GET['action'] == "logout")
	{
		$session->destroySession();
		$queries->deleteSession();
	}
	if($session->checkSession()) {
		header("Location:admin.php");
	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN"
"http://www.w3.org/TR/html4/frameset.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>TOWN OF PIXELS &rsaquo; Admin Login</title>
		<script type = "text/javascript" src = "../resources/js/jquery.js"></script>
	</head>
	
	<body>
		
<?php
}
display_header();
?>
		<script language = "javascript">
			
			
			function displayError(msg) {
				
				$(".err").html(msg).slideDown().delay(2000).slideUp();
				
			}
			$(document).ready(function() {
				
				$(".login_but").click(function() {
					$(".err").hide();
					var adminid = $("#adminid").val().trim();
					var adminpwd = $("#adminpwd").val().trim();
					
					if(adminid.length == 0 || adminpwd.length == 0)
					{
						displayError("Authentication Failed.");
					}
					else
					{
						$.ajax({
							url: "classes/queries.class.php",
							data: "login=true&adminid="+adminid+"&adminpwd="+adminpwd,
							type: "POST",
							dataType: "json",
							success: function(msg) {								
								if(msg.success){document.location.href = "admin.php"}
								else{displayError("Authentication Failed.")}
							
							}
						
						
						});
					}
					
					
				});
			});
		
		</script>
		<style type = "text/css">
		html{background:#f9f9f9;}
		body{color:#333;font-family:"Lucida Grande",Verdana,Arial,"Bitstream Vera Sans",sans-serif;margin:2em auto;width:700px;padding:1em 2em;-moz-border-radius:11px;-khtml-border-radius:11px;-webkit-border-radius:11px;border-radius:11px;}
		a{color:#2583ad;text-decoration:none;}
		a:hover{color:#d54e21;}
		h1#logo{clear:both;color:#666;font:24px Georgia,"Times New Roman",Times,serif;margin:5px 0 0 -4px;padding:0;padding-bottom:7px;}
		h2{font-size:16px;}
		//p,li,dd,dt{padding-bottom:2px;font-size:12px;line-height:18px;}
		code,.code{font-size:13px;}
		//ul,ol,dl{padding:5px 5px 5px 22px;}
		a img{border:0;}abbr{border:0;font-variant:normal;}
		#logo{margin:6px 0 14px 0;border-bottom:none;text-align:center;}
		.step{margin:20px 0 15px;}.step,th{text-align:left;padding:0;}
		.submit input,.button,.button-secondary{font-family:"Lucida Grande",Verdana,Arial,"Bitstream Vera Sans",sans-serif;text-decoration:none;font-size:12px!important;line-height:16px;padding:5px;cursor:pointer;border:1px solid #bbb;color:#464646;-moz-border-radius:4px;-khtml-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;-khtml-box-sizing:content-box;box-sizing:content-box;}
		.button:hover,.button-secondary:hover,.submit input:hover{color:#000;border-color:#666;}
		.button,.submit input,.button-secondary{background:#f2f2f2 url(../images/white-grad.png) repeat-x scroll left top;}
		.button:active,.submit input:active,.button-secondary:active{background:#eee url(../images/white-grad-active.png) repeat-x scroll left top;}
		textarea{border:1px solid #bbb;-moz-border-radius:4px;-khtml-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;}
		.form-table{border-collapse:collapse;margin-top:1em;width:100%;}
		.form-table td{margin-bottom:9px;padding:10px;border-bottom:8px solid #fff;font-size:12px;}
		.form-table th{font-size:13px;text-align:left;padding:16px 10px 10px 10px;border-bottom:8px solid #fff;width:130px;vertical-align:top;}
		.form-table tr{background:#f3f3f3;}.form-table code{line-height:18px;font-size:18px;}
		.form-table p{margin:4px 0 0 0;font-size:11px;}
		.form-table input{line-height:20px;font-size:15px;padding:2px;}
		.form-table th p{font-weight:normal;}
		#error-page{margin-top:50px;}
		#error-page p{font-size:12px;line-height:18px;margin:25px 0 20px;}
		#error-page code,.code{font-family:Consolas,Monaco,Courier,monospace;}
		#pass-strength-result{background-color:#eee;border-color:#ddd!important;border-style:solid;border-width:1px;margin:5px 5px 5px 1px;padding:5px;text-align:center;width:200px;}
		#pass-strength-result.bad{background-color:#ffb78c;border-color:#ff853c!important;}
		#pass-strength-result.good{background-color:#ffec8b;border-color:#fc0!important;}
		#pass-strength-result.short{background-color:#ffa0a0;border-color:#f04040!important;}
		#pass-strength-result.strong{background-color:#c3ff88;border-color:#8dff1c!important;}
		.message{border:1px solid #e6db55;padding:.3em .6em;margin:5px 0 15px;background-color:#ffffe0;}
		.error{color:#CC0000}.success{color:#017800}	
		label {
			color: #696969;
			float: left;
			font-family: Times New Roman;
			font-size: 14px;
			width: 100px;
		}
		.input_text {
			 border: 1px solid #CCCCCC;
			color: #696969;
			font-size: 12px;
			padding: 2px;
			border-radius: 4px;
			-moz-border-radius: 4px; 
			-webkit-border-radius: 4px;
		}
		.row {display: block;height:40px;}
		#admin-login {
			border: 1px solid #CCCCCC;
			border-radius: 10px 10px 10px 10px;
			margin: 75px auto;
			padding: 25px 50px;
			width: 240px;
			-moz-border-radius: 10px; 
			-webkit-border-radius: 10px;
		}
		.login_but {
			background: none repeat scroll 0 0 #F2F2F2;
			border: 1px solid #959494;
			border-radius: 4px 4px 4px 4px;
			color: #636060;
			cursor: pointer;
			float: right;
			font-family: Times New Roman;
			font-size: 12px;
			padding: 2px 4px;
		}
		.login_but:hover {
			background: none repeat scroll 0 0 #EBEBEB;			
			color: #808080;
		}
		.err {
			background: none repeat scroll 0 0 #FFB200;
			border-radius: 5px 5px 5px 5px;
			color: #FCFCFC;
			font-size: 12px;
			padding: 4px;
			text-align: center;
			width: 96%;
			-moz-border-radius: 5px; 
			-webkit-border-radius: 5px;
			display:none;
		}
		</style>
		<div id = "login-content">
			<h1 id="logo">TOWN OF PIXELS</h1>
			<div id = "admin-login">
			
				<div class = "row">
					<label class = "err">Message Box</label>
				</div>
				<div class = "row">
					<label>Admin Id:</label><input type = "text" name = "adminid" id = "adminid" class = "input_text" value = "admin">
				</div>
				<div class = "row">
					<label>Password:</label><input type = "password" name = "adminpwd" id = "adminpwd" class = "input_text">
				</div>
				<div class = "row">
					<input type = "submit" name = "login" class = "login_but" value = "Login">
				</div>
			</div>
		</div>
  </body>
</html>
