<?php
error_reporting(0);
ini_set( 'zlib.output_compression', '1' );
include_once ("../paths.php");
include_once(ROOT_DIR."/admin/pages/check.session.php");
$siteInfo = $queries->getSiteDetails();
$title = $siteInfo['site_title'];
echo "<script langauge = 'javascript'>";
include_once(ROOT_DIR.'/resources/js/admin-combine.php');
echo "</script>";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
  <head>	
    <meta name="generator" content=
    "HTML Tidy for Windows (vers 14 February 2006), see www.w3.org">
	<meta content="NO-CACHE" http-equiv="PRAGMA">

	<link media="all" type="text/css" href="<?=ROOT_URL.'/resources/css/admin-combined.css'?>" rel="stylesheet">
	<link media="all" id="stylecss" type="text/css" href="<?=ROOT_URL.'/resources/css/admin_global_css_light.css'?>" rel="stylesheet">
<!--CSS files
menu_editor.css,jquery.lightbox-0.5.css,jquery.cleditor.css,jquery-ui-1.8.16.custom.css,fileuploader.css
	JS Files
jquery.js,layoutquery.2.0.js,jquery-ui-1.8.16.custom.min.js,fileuploader.js,jquery.lightbox-0.5.pack.js,
menu-editor.js,jquery.cleditor.js,jquery.tipsy.js
-->
	
	<style type = "text/css">
	    html,body { margin: 0;padding: 0;}
		
		#container {
			min-height: 80%;
			position: absolute;
			//background:url("<?=ROOT_URL?>/resources/img/body-background.jpg") repeat scroll 0 0 transparent;
			 min-width: 1200px;
			 _width: 1200px;
			 *width: 1200px;
		}		
		
		body, td, input, textarea, select {
			font-family: arial,sans-serif;
		}
		
		#login-content {
			margin-left: -16%;
		}
	</style>
    <script language="javascript" type="text/javascript">
	var spinnerImage;
	spinnerImage = "<?=ROOT_URL?>/admin/images/spinner.gif";  
    $(function() {
         content_page = "menu_editor.php";
         if(location.hash.length > 0) {
             content_page = location.hash.replace("#","")+".php";             
          }else {
             location.hash = "#menu_editor";
         }



		$.ajaxSetup({cache: true}); 
        $("#container").layout({                      
						cols: 2,
						layoutWidth:100,
						left_col: {'display':true,'width':15,'id':'left_col','_class':'left_col','path':'<?=ROOT_URL.'/admin/pages/left.php'?>'},           
						content_col: {'width':85,'id':'content_col','_class':'content_col','path':'<?=ROOT_URL.'/admin/pages/'?>'+ content_page},
						right_col: {'display':false,'width':10,'id':'right_col','_class':'right_col','path':'<?=ROOT_URL.'/admin/pages/right.html'?>'},             
						header: {'display':true,'id':'header','_class':'','height':'auto','path':'<?=ROOT_URL.'/admin/pages/header.php'?>','load_once':true},
						footer: {'display':true,'id':'footer','_class':'','height':'auto','path':'<?=ROOT_URL.'/admin/pages/footer.php'?>','load_once':true},               
						menu: {'display':false,'id':'menu','_class':'','height':'auto','path':'<?=ROOT_URL.'/admin/pages/menu.php'?>','load_once':true},            
						colsPadding: 0,
						loadAtOnce: true,
						smartCSS: true,
						unit: '%',
						preloadImage: '<?=ROOT_URL?>/admin/images/spinner.gif',
						paddOthers: true,
						fullHeight: true,
						afterFinish: function(){
						
								var width = ( 100 * parseFloat($('#content_col').css('width')) / parseFloat($('#content_col').parent().css('width'))-0.1 );
								$("#content_col").css('width',width+'%' );
                                                             
							}
                
		});
		
		$("#adminmenu ul li").live('click',function() {
			
			location.hash = $(this).attr('class');			
			var obj = $(this);
			startSpinner();
			$("#content_col").animate({opacity: 0}, 10,function() {
					
					$("#content_col").load("<?=ROOT_URL.'/admin/pages/'?>"+obj.attr('class')+".php", function(){
						
						$("#content_col").animate({opacity: 1}, 300);
						stopSpinner();
					});
					
			});
			
			$("#adminmenu li").attr('id','');
                         $(location.hash.replace("#",".")).attr('id','selected');
			
		});
		
		function startSpinner() {
		
			$("#spinner").remove();
			var spinner = $(".preload").clone();
			spinner.attr('id','spinner').html("<img src = '"+spinnerImage+"'>").appendTo('body');
			$("#spinner").show();
	
		}
		function stopSpinner() {
			
			$("#spinner").fadeOut("slow",function(){
				$(this).remove();
			});
		
		}

                
                
    });

    </script>
    <title><?=$title?> - Admin Panel</title>
  </head>
  <body>
  
  <div id = "container"></div>


  </body>
</html>