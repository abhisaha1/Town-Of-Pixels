<?php
error_reporting(0);
echo '<style type = "text/css">
html{background:#f9f9f9;}body{background:#fff;color:#333;font-family:"Lucida Grande",Verdana,Arial,"Bitstream Vera Sans",sans-serif;margin:2em auto;width:700px;padding:1em 2em;-moz-border-radius:11px;-khtml-border-radius:11px;-webkit-border-radius:11px;border-radius:11px;border:1px solid #dfdfdf;}a{color:#2583ad;text-decoration:none;}a:hover{color:#d54e21;}h1{border-bottom:1px solid #dadada;clear:both;color:#666;font:24px Georgia,"Times New Roman",Times,serif;margin:5px 0 0 -4px;padding:0;padding-bottom:7px;}h2{font-size:16px;}p,li,dd,dt{padding-bottom:2px;font-size:12px;line-height:18px;}code,.code{font-size:13px;}ul,ol,dl{padding:5px 5px 5px 22px;}a img{border:0;}abbr{border:0;font-variant:normal;}#logo{margin:6px 0 14px 0;border-bottom:none;text-align:center;}.step{margin:20px 0 15px;}.step,th{text-align:left;padding:0;}.submit input,.button,.button-secondary{font-family:"Lucida Grande",Verdana,Arial,"Bitstream Vera Sans",sans-serif;text-decoration:none;font-size:12px!important;line-height:16px;padding:5px;cursor:pointer;border:1px solid #bbb;color:#464646;-moz-border-radius:4px;-khtml-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;-khtml-box-sizing:content-box;box-sizing:content-box;}.button:hover,.button-secondary:hover,.submit input:hover{color:#000;border-color:#666;}.button,.submit input,.button-secondary{background:#f2f2f2 url(../images/white-grad.png) repeat-x scroll left top;}.button:active,.submit input:active,.button-secondary:active{background:#eee url(../images/white-grad-active.png) repeat-x scroll left top;}textarea{border:1px solid #bbb;-moz-border-radius:4px;-khtml-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;}.form-table{border-collapse:collapse;margin-top:1em;width:100%;}.form-table td{margin-bottom:9px;padding:10px;border-bottom:8px solid #fff;font-size:12px;}.form-table th{font-size:13px;text-align:left;padding:16px 10px 10px 10px;border-bottom:8px solid #fff;width:130px;vertical-align:top;}.form-table tr{background:#f3f3f3;}.form-table code{line-height:18px;font-size:18px;}.form-table p{margin:4px 0 0 0;font-size:11px;}.form-table input{line-height:20px;font-size:15px;padding:2px;}.form-table th p{font-weight:normal;}#error-page{margin-top:50px;}#error-page p{font-size:12px;line-height:18px;margin:25px 0 20px;}#error-page code,.code{font-family:Consolas,Monaco,Courier,monospace;}#pass-strength-result{background-color:#eee;border-color:#ddd!important;border-style:solid;border-width:1px;margin:5px 5px 5px 1px;padding:5px;text-align:center;width:200px;}#pass-strength-result.bad{background-color:#ffb78c;border-color:#ff853c!important;}#pass-strength-result.good{background-color:#ffec8b;border-color:#fc0!important;}#pass-strength-result.short{background-color:#ffa0a0;border-color:#f04040!important;}#pass-strength-result.strong{background-color:#c3ff88;border-color:#8dff1c!important;}.message{border:1px solid #e6db55;padding:.3em .6em;margin:5px 0 15px;background-color:#ffffe0;}.error{color:#CC0000}.success{color:#017800}
</style>';
define('ABSPATH', dirname(dirname(__FILE__)) . '/');

function pd_die($msg) {
    $backButton = '<p><a href="setup-config.php?step=2" class="button">Back</a></p>';
    die(display_header() . $msg . $backButton);
    break;
}

if (!file_exists(ABSPATH . 'config-sample.php'))
    pd_die('Sorry, I need a config-sample.php file to work from. Please re-upload this file from your Town Of Pixels installation.');

$configFile = file(ABSPATH . 'config-sample.php');


// Check if config.php has been created
if (file_exists(ABSPATH . 'config.php'))
    pd_die("<p>The file 'config.php' already exists. If you need to reset any of the configuration items in this file, please delete it first. You may try <a href='install.php'>installing now</a>.</p>");


if (isset($_GET['step']))
    $step = $_GET['step'];
else
    $step = 0;

/**
 * Display setup config.php file header. 
 */
function display_header() {
    header('Content-Type: text/html; charset=utf-8');
    ?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
            <title>Town Of Pixels &rsaquo; Setup Configuration File</title>


        </head>
        <body>
            <h1 id="logo">Town Of Pixels</h1>
    <?php
}

//end function display_header();

switch ($step) {
    case 0:
        display_header();
        ?>

                <p>Welcome to Town Of Pixels. Before getting started, we need some information on the database. You will need to know the following items before proceeding.</p>
                <ol>
                    <li>Database name</li>
                    <li>Database username</li>
                    <li>Database password</li>
                    <li>Database host</li>                    
                </ol>
                <p><strong>If for any reason this automatic file creation doesn't work, don't worry. All this does is fill in the database information to a configuration file. You may also simply open <code>config-sample.php</code> in a text editor, fill in your information, and save it as <code>config.php</code>. </strong></p>
                <p>In all likelihood, these items were supplied to you by your Web Host. If you do not have this information, then you will need to contact them before you can continue. If you&#8217;re all ready&hellip;</p>

                <p class="step"><a href="setup-config.php?step=1<?php if (isset($_GET['noapi']))
            echo '&amp;noapi'; ?>" class="button">Let&#8217;s go!</a></p>
                <?php
                break;

            case 1:

                display_header();

                $uploadDir = ABSPATH . 'resources/uploads/';
                $originalDir = ABSPATH . 'resources/uploads/originals/';
                $permissions = true;

                if (!is_writable($uploadDir)) {
                    echo "<p class = 'error'>Image Upload Directory doesnt have write permission.</p>";
                    $permissions = false;
                } else {
                    echo "<p class = 'success'>Image upload directory is writable.</p>";
                }
                if (!is_writable($originalDir)) {
                    echo "<p class = 'error'>Original Backup Directory doesnt have write permission.</p>";
                    $permissions = false;
                } else {
                    echo "<p class = 'success'>Original upload directory is writable.</p>";
                }
                if (!function_exists('exif_read_data')) {
                    echo "<p class = 'error'>PHP Extension php_exif is not installed. This is required to read image information.</p>";
                    $permissions = false;
                } else {
                    echo "<p class = 'success'>php_exif extension installed.</p>";
                }
                if (!function_exists('curl_init')) {
                    echo "<p class = 'error'>PHP Extension php_curl is not installed. This is required for future upgrades and might also be used by few plugins.</p>";
                    $permissions = false;
                } else {
                    echo "<p class = 'success'>php_curl extension installed.</p>";
                }

                if ($permissions) {
                    echo '<form method = "POST" action="setup-config.php?step=2">
				<p>Awesome. Town Of Pixels meets all the functional requirements required for its installation. Time to configure your database.
				<p class="step"><input name="submit" type="submit" value="Next" class="button" /></p>
			  </form>';
                } else {

                    echo '<p>Please rectify the above issues marked in red. If you are not sure about them, contact your host provider
				If you have rectified the errors, hit the button below.</p>
				<input name="submit" onClick="window.location.reload()" type="submit" value="Verify" class="button" />';
                }

                break;

            case 2:
                display_header();
                ?>
                <form method="post" action="setup-config.php?step=3">
                    <p>Below you should enter your database connection details. If you're not sure about these, contact your host. </p>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="dbname">Database Name</label></th>
                            <td><input name="dbname" id="dbname" type="text" size="25" value="" /></td>
                            <td>The name of the database you want to run Town Of Pixels in. </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="uname">User Name</label></th>
                            <td><input name="uname" id="uname" type="text" size="25" value="" /></td>
                            <td>Your MySQL username</td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="pwd">Password</label></th>
                            <td><input name="pwd" id="pwd" type="text" size="25" value="" /></td>
                            <td>...and MySQL password.</td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="dbhost">Database Host</label></th>
                            <td><input name="dbhost" id="dbhost" type="text" size="25" value="localhost" /></td>
                            <td>You should be able to get this info from your web host, if <code>localhost</code> does not work.</td>
                        </tr>
                        <!--
						<tr>
                            <th scope="row"><label for="prefix">Table Prefix</label></th>
                            <td><input name="prefix" id="prefix" type="text" value="" size="25" /></td>
                            <td></td>
                        </tr>-->
                    </table>
        <?php if (isset($_GET['noapi'])) { ?><input name="noapi" type="hidden" value="true" /><?php } ?>
                    <p class="step"><input name="submit" type="submit" value="Submit" class="button" /></p>
                </form>
        <?php
        break;

    case 3:
        $dbname = trim($_POST['dbname']);
        $uname = trim($_POST['uname']);
        $passwrd = trim($_POST['pwd']);
        $dbhost = trim($_POST['dbhost']);
        $prefix = trim($_POST['prefix']);
        if (empty($prefix))
            $prefix = 'wp_';


        define('DB_NAME', $dbname);
        define('DB_USER', $uname);
        define('DB_PASSWORD', $passwrd);
        define('DB_HOST', $dbhost);

        $connection = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
        if ($connection && @mysql_select_db(DB_NAME)) {
            
            if (@!mysql_select_db(DB_NAME)) {
                @unlink(ABSPATH . 'config.php');
                pd_die("<p>Error in Connection</p>");
            }
            
        } else {
            
            @unlink(ABSPATH . 'config.php');
            pd_die("<p>Error in Connection</p>");
            
        }
        $realConfig = array();
        $realConfig[] = "<?php \n";
        $realConfig[] = "// ** MySQL settings - You can get this info from your web host ** //\n";
        $realConfig[] = "/** The name of the database for Town Of Pixels */\n";
        $realConfig[] = "DEFINE('DB_NAME','$dbname');\n";
        $realConfig[] = "/** MYSQL DATABASE USERNAME */\n";
        $realConfig[] = "DEFINE('DB_USER','$uname');\n";
        $realConfig[] = "/** MYSQL DATABASE PASSWORD */\n";
        $realConfig[] = "DEFINE('DB_PASSWORD','$passwrd');\n";
        $realConfig[] = "/** MYSQL DATABASE HOSTNAME */\n";
        $realConfig[] = "DEFINE('DB_HOST','$dbhost');\n";
        $realConfig[] = "?>\n";

        if (!is_writable(ABSPATH)) :
            display_header();
            ?>
                    <p>Sorry, but I can't write the <code>wp-config.php</code> file.</p>
                    <p>You can create the <code>wp-config.php</code> manually and paste the following text into it.</p>
                    <textarea cols="98" rows="15" class="code"><?php
            foreach ($configFile as $line) {
                echo htmlentities($line, ENT_COMPAT, 'UTF-8');
            }
            ?></textarea>
                    <p>After you've done that, click "Run the install."</p>
                    <p class="step"><a href="install.php" class="button">Run the install</a></p>
                    <?php
                else :
                    $handle = fopen(ABSPATH . 'config.php', 'w');
                    foreach ($realConfig as $line) {
                        fwrite($handle, $line);
                    }
                    fclose($handle);
                    chmod(ABSPATH . 'config.php', 0666);
                    display_header();
                    ?>
                    <p>All right sparky! You've made it through this part of the installation. Town Of Pixels can now communicate with your database. If you are ready, time now to&hellip;</p>

                    <p class="step"><a href="install.php" class="button">Run the install</a></p>
                <?php
                endif;
                break;
        }
        ?>
    </body>
</html>