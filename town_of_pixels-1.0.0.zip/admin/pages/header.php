<?php
/**
 * Display Header;
 * 
 * applyHeaderCSS() : Default CSS
 * getHeaderMarkup() : Gets the HTML Markup of Header
 *
 * ---Optional---
 * If you want to create your own header Markup, you can use
 * 
 *        getSiteDetails()
 * 
 * It returns and array containing Site Information, which contains the Header Information as well.
 *
 * You can use display(array) to print the available information in any array. 
 */

include_once ("../../paths.php");
include_once(ROOT_DIR."/admin/pages/check.session.php");
$pbdb = new queries();



echo $pbdb->applyHeaderCSS();
echo $pbdb->getHeaderMarkup();


?>
<style type = "text/css">
#header{
	background: url("<?=ROOT_URL?>/admin/images/header.jpg") repeat-x scroll 0 top #0A0A0A;
    color: #454545;
    height: 40px;
    padding: 20px !important;
}

#update-available {
	background: none repeat scroll 0 0 #E83003;
    color: #E4E4E4;
    font-size: 10px;
    left: 50%;
    margin: auto auto auto -200px;
    padding: 5px;
    position: absolute;
    text-align: center;
    top: 0;
    width: 400px;
}
#header_links {
	color: #5A5B5B;
    float: right;
    font-family: georgia;
    font-size: 11px;
    margin-top: -15px;
}
#header_links a{
	text-decoration: none;
	color: #5A5B5B;
	margin-right:10px;
	
}
#header_links a:hover{	
	color: #FFF;	
}
</style>
<script language = "javascript">

var upgradeMarkup = "<span class = 'upgrade_status' style = 'color:#696969; font-family: times New Roman;margin: 20px;position: absolute;'>Upgade In Progress...Please be patient !!</span>";
$(document).ready(function() {
	
	$(".upgrade-trigger").live('click',function(e) {
		
		e.preventDefault();
		
		$("#"+content_col_id).html(upgradeMarkup);
		$.ajax({
			url: "<?=ROOT_URL?>/admin/classes/upgradeCheck.class.php",
			type: "POST",
			data: "startupgrade=true",
			success: function(msg) {
				
				$("#"+content_col_id+" .upgrade_status").delay(2000).fadeOut(100, function() {
    
					$(this).html(msg).fadeIn();
					$("#update-available").hide();

				});
				
			}
	
		});
		
	});
	//UPGRADE NOTIFICATION IN HEADER
	$.ajax({url:"<?=ROOT_URL?>/admin/pages/header_upgrade_notification.php",async:true,success: function(msg){$("#notification").html(msg);}})
	


        //Change Theme
        $(".theme_but").click(function(e) {
			  e.preventDefault;
              href = $(this).attr('href');
              if(href == "dark")
              $("#stylecss").attr('href',$("#stylecss").attr('href').replace('admin_global_css_light', 'admin_global_color'));
              if(href == "light")
              $("#stylecss").attr('href',$("#stylecss").attr('href').replace('admin_global_color', 'admin_global_css_light'));

				return false;
        });
});

</script>
<div id = "header_links">

<a href="dark" class='theme_but'  style="float: right; background: none repeat scroll 0% 0% black; height: 15px; width: 15px;"></a>
<a href="light" class='theme_but'  style="float: right; background: none repeat scroll 0% 0% white; height: 15px; width: 15px;"></a>

<a style = "float:right" href = "<?=ROOT_URL?>/admin/admin-login.php?action=logout">Logout</a>
<a style = "float:right" target = "_blank" href = "<?=ROOT_URL?>">Preview</a>
</div>
<div id = "notification"/>