<?php
include_once("../../paths.php");
include_once(ROOT_DIR."/admin/pages/check.session.php");
$pbdb = new queries();
$siteConfig = $pbdb->getSiteDetails();

$allow_comments_true = ($siteConfig['allow_comments'])?"checked":"";
$allow_comments_false = (!$siteConfig['allow_comments'])?"checked":"";

$allow_subs_true = ($siteConfig['allow_subs'])?"checked":"";
$allow_subs_false = (!$siteConfig['allow_subs'])?"checked":"";

$header_display_true = ($siteConfig['header_display'])?"checked":"";
$header_display_false = (!$siteConfig['header_display'])?"checked":"";

$allow_originals_true = ($siteConfig['allow_originals'])?"checked":"";
$allow_originals_false = (!$siteConfig['allow_originals'])?"checked":"";

$package = $pbdb->getPackageInfo();
$version = $package['version'];
?>
<style type = "text/css">
#image_info_form *{
	font-family: times New Roman;
}
#image_info_form div:not(.section) {
	width:100%;	
	border-bottom:1px dotted #161712;
	padding:15px 0;
	color: #BBBBBB;
	font-size: 12px;
}
.meta_desc,.footer_desc {
	padding:5px;
	width:25%;
	height: 40px;	
}
.update {
    margin: 0 0 10px 350px;
    padding: 4px 7px;
    position: relative;
    top: 10px;
}

#message {
	background: none repeat scroll 0 0 #232323;
    color: #A4A4A4;
    font-family: Times New Roman;
    font-size: 13px;
    padding: 8px;
	display:none;	
    width: 100%;
}
.explaination {
	color: #1E6299;
    font-style: italic;
    margin-left: 360px;
	text-align: justify;
    width: 40%;
}
.section {
	display:none;
}
#toolbar {
	margin-top:40px;
}
#toolbar li {
	display: inline;
}

</style>
<div id = "message"></div>
<h2 class = 'config_header headline'>Configurations</h2>
<span class = "headdesc">
	You can control various settings of your site from here.	
</span>
<ul id = "toolbar">
	<li><a class = "ui-corner-all selected cbutton" href = "sitedetails">Site Settings</a></li>	
	<li><a class = "ui-corner-all cbutton" href = "imagedetails">Image Settings</a></li>
	<li><a class = "ui-corner-all cbutton" href = "settings">Tweaks</a></li>
</ul>
<script language = "javascript">
	
	$(document).ready(function() {
		
		$('textarea').attr('value',"<?=$siteConfig['meta_desc']?>")
		$("#sitedetails").show();
		$("#toolbar li a").click(function(e) {
			
			e.preventDefault();
			var showsection = $(this).attr('href');
			$("#toolbar a").removeClass("selected");
			$(this).addClass('selected');
			$('.section').hide();
			$("#"+showsection).show();
		
		});
		
		
		
		$("#image_quality").keyup(function() {
			var val =  $(this).val();
			if((val <=50 || val >= 100) && typeof val != "number")
			{
				console.log("Allowed Value should be between 50-100")
			}
		});
		
	});
var formElements = ["#site_name","#site_tag","#site_title","#meta_desc","#g_track_id","#allow_comments","#allow_subs",'#footer_desc'];
		
		function validate()
		{
			$("#message").slideDown().html("Updating. Please Wait..");
			var formdata="";
			for(var i = 0; i < formElements.length; i++) {
				
				if($(formElements[i]).attr("type") == "radio")
					formdata += $(formElements[i]).attr('name')+"="+$(formElements[i]+":checked").val()+"&";
				
				
			}
			
			formdata += "insertSiteDetails=true&"+$("#image_info_form").serialize();
			
			$.ajax({
			
				url: '<?=ROOT_URL?>/admin/classes/queries.class.php',
				data: formdata,
				type: "POST",	
				dataType:'json',
				success: function(msg) {
					
					$("#message").html("Configurations updated successfully.").fadeOut(10000);
					$("#header_title").html($("#site_name").val());
					$("#header_tag").html($("#site_tag").val());
					$("head title").html($("#site_title").val());
					$("#footer .footer_text").html($("#footer_desc").val());
				}
		
			});
		}
		
		
</script>

<form id = "image_info_form">

<div class = "section" id = "sitedetails">
	<div class ="items">
	   <label class='input_label'>Site Name</label>
	   <input type="text" class="input_text" name="site_name" id="site_name" value = "<?=$siteConfig['site_name']?>" tabindex = "1"/>
	</div>
	<div class ="items">
		<label class='input_label'>Site Tagname</label>
		<input type="text" class="input_text" name="site_tag" id="site_tag" value = "<?=$siteConfig['site_tag']?>" tabindex = "2"/>		
	</div>
	<div class ="items">
	   <label class='input_label'>Site Title</label>
	   <input type="text" class="input_text" name="site_title" id="site_title" value = "<?=$siteConfig['site_title']?>" tabindex = "3"/>
	</div>
	<div class ="items">
	   <label class='input_label'>Meta Description</label>	  
	   <textarea class = "meta_desc textarea_text" name = "meta_desc" id = "meta_desc" value = "<?=$siteConfig['meta_desc']?>" tabindex = "4"/>
	   <p class = 'explaination'>This will be displayed in Search Engines</p>
	</div>
	<div class ="items">
	   <label class='input_label'>Footer Text</label>	  
	    <input type="text" class="input_text" name="footer_desc" id="footer_desc" value = "<?=htmlentities($siteConfig['footer_desc'])?>" tabindex = "5"/>
	   <p class = 'explaination'>Footer Text</p>
	</div>
	<div class ="items">
	   <label class='input_label'>Current Version</label>	  
	    <input disabled type="text" class="input_text" name="current_version" id="current_version" value = "<?=$version?>" tabindex = "5"/>
	   <p class = 'explaination'>You are using this version.</p>
	</div>
</div>

<div class = "section" id = "imagedetails">
	<div class ="items">
	   <label class='input_label'>Save Originals</label>
	   <input type = "radio" id = "allow_originals" <?=$allow_originals_true?> name = "allow_originals" value = "1">Yes<input type = "radio" <?=$allow_originals_false?> id = "allow_originals" name = "allow_originals" value = "0">No	   
	   <p class = 'explaination'>All files which are uploaded gets compressed for better loading. Would you like to save the original images as well for backup ?</p>
	</div>
	<div class ="items">
	   <label class='input_label'>Image Compression Quality</label>
	   <input type="text" class="input_text" MAXLENGTH="3" name="image_quality" id="image_quality" value = "<?=$siteConfig['image_quality']?>" tabindex = "3"/>		
	   <p class = 'explaination'>Default is 70 and is recommended for best performance.</p>
	</div>
	<div class ="items">
	   <label class='input_label'>WaterMark</label>
	   <input type = "text" class="input_text" id = "watermark" value="<?=$siteConfig['watermark']?>" name = "watermark">
	   <p class = 'explaination'>WaterMark will be displayed at Right-Bottom corner of the image. The font color automatically turns into Grey or White based on the background color of image.</p>
	</div>
	<div class ="items">
	   <label class='input_label'>Max Image Width</label>
	   <input type = "text" class="input_text" id = "maxwidth" value="<?=$siteConfig['maxwidth']?>" name = "maxwidth">
	   <p class = 'explaination'>Image Height will not exceed this Max Height. Should be an Integer.</p>
	</div>	
	<div class ="items">
	   <label class='input_label'>Max Image Height</label>
	   <input type = "text" class="input_text" id = "maxheight" value="<?=$siteConfig['maxheight']?>" name = "maxheight">
	   <p class = 'explaination'>Image Width will not exceed this Max Width. Should be an Integer.</p>
	</div>	
</div>

<div class = "section" id = "settings">
	<div class ="items">
	   <label class='input_label'>Display Header</label>
	    <input type = "radio" name = "header_display" <?=$header_display_true?> id = "header_display" name = "header_display" value = "1">Yes<input <?=$header_display_false?> type = "radio" name = "header_display" id = "header_display" name = "header_display" value = "0">No	   	   
		<p class = 'explaination'>If Yes, header will be displayed. If No, the contents of header will be shifted to Left SideBar.</p>
	</div>
	
	<div class ="items">
	   <label class='input_label'>Google Tracking Id</label>
	   <input type="text" class="input_text" name="g_track_id" value = "<?=$siteConfig['g_track_id']?>" id="g_track_id" tabindex = "1"/>
	</div>	
	
	<div class ="items">
	   <label class='input_label'>Allow Comments</label>
	   <input type = "radio" id = "allow_comments" <?=$allow_comments_true?> name = "allow_comments" value = "1">Yes<input type = "radio" <?=$allow_comments_false?> id = "allow_comments" name = "allow_comments" value = "0">No	   
	</div>
	<div class ="items">
	   <label class='input_label'>Comment Notification Mail</label>
	   <input type = "text" class="input_text" id = "comment_notify"  name = "comment_notify" value = "<?=$siteConfig['comment_notify']?>">
	</div>
	<div class ="items">
	   <label class='input_label'>Allow Subscriptions</label>
	    <input type = "radio" name = "allow_subs" <?=$allow_subs_true?> id = "allow_subs" name = "allow_subs" value = "1">Yes
		<input <?=$allow_subs_false?> type = "radio" name = "allow_subs" id = "allow_subs" name = "allow_subs" value = "0">No	   	   
	</div>
</div>


	
	<input type="button" class="update ui-corner-all cbutton" value="Update" onClick="javascript:validate()" tabindex = "4"/>
</form>	