<style type = "text/css">
.footer_text {
	color: #FFFFFF;    
    line-height: 40px;
    margin-left: 10px;    
    position: absolute;
	font-size: 12px;
}
#footer {
	height:40px;
	background: #282828;	
}
</style>
<?php
include_once ("../../paths.php");
$pbdb = new queries();
$siteConfig = $pbdb->getSiteDetails();

?>
<span class = "footer_text"><?=$siteConfig['footer_desc']?></span>