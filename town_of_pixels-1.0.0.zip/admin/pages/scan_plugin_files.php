<?php
include_once("../../paths.php");
global $pbdb;

$allowedExtensions = array("css","php","js","html");

$pluginFolder = $_POST['plugin_folder'];
$pluginPath = str_replace("\\","/",PLUGIN_DIR).$pluginFolder;
$pluginFiles = "<select id = 'plugin_files_select'>
					<option value = ''>=select=</option>";

list_plugin_files($pluginPath, $recursive=false, $pluginFiles,"");

function list_plugin_files($pluginPath, $recursive=false, $pluginFiles, $subfolder) {
    
	global $pluginFiles,$allowedExtensions,$extension;
    
	if(is_dir($pluginPath)) {
      if($dh = opendir($pluginPath)) {
        while(($file = readdir($dh)) !== false) {
          if($file != "." && $file != "..") {
				
				if(is_dir($pluginPath."/".$file)) { 
					list_plugin_files($pluginPath."/".$file, $recursive, $pluginFiles, $file);
				}
				else{
					$path_info = pathinfo($file);					
					$extension = @$path_info['extension'];
					if(in_array($extension,$allowedExtensions))
					$pluginFiles .= "<option value = '/$subfolder/$file'>".$file."</option>";
				}              
          }
        }
        closedir($dh);
      }
    }
    
}
$pluginFiles .= "</select>";

echo $pluginFiles;
?>