<?php
include_once ("../../paths.php");
include_once(ROOT_DIR."/admin/pages/check.session.php");
$pbdb = new queries();

$upgradeCheck = new upgradeCheck();

if($upgradeCheck->upgrade_required)
{
	echo $upgradeCheck->upgrade_message;	
}
else if($upgradeCheck->info_message_display == "true")
{
	echo $upgradeCheck->info_message;	
}
?>