<?php
include_once("../../paths.php");
include_once(ROOT_DIR."/admin/pages/check.session.php");
$catid = $_GET['catid'];
$subcatid = $_GET['subcatid'];

$pbdb = new queries();
$thumbsImgs = $pbdb->displayThumbnails($_GET['catid'],$_GET['subcatid']);

$coverpageData = $pbdb->getCoverpageData($subcatid);

$coverpage = addslashes($coverpageData['coverpage']);
$coverpagestatus = $coverpageData['coverpagestatus'];
$coverpagewidth = $coverpageData['coverpagewidth'];
	

$thumbs = "";

$folderPath = $pbdb->currentFolder($catid,$subcatid);

$gallery_plugin_list_markup = $pbdb->displayGalleryPluginsOnly($subcatid);


foreach($thumbsImgs as $key => $array) {
	
	$thumbpath = $array['thumbpath'];
	$imgpath = $array['imagepath'];
	$caption = $array['caption'];
	$id = $array['id'];
	$thumbs .= "<li id = '$id'>
					<a class = 'lightbox' href=\"$imgpath\" title = \"$caption\" rel='lightbox[roadtrip]'>
						<img src=\"$thumbpath\" alt='' />
					</a>
					<span>
						<a class = 'enlarge1' href='#'><img src = 'images/enlarge_icon_black.gif'/></a>						
					</span>
				</li>";
}
?>

	<link rel="stylesheet" type="text/css" href="<?=ROOT_URL.'/admin/pages/css/upload.css'?>" media="screen">
	
<script language = "javascript">
function startSpinner() {
		
	var spinner = $(".preload").clone();
	spinner.attr('id','spinner').html("<img src = '"+spinnerImage+"'>").css({'margin-top':'4px','top':0}).appendTo('#coverpage_title');
	$("#spinner").show();
	
}
function stopSpinner() {
	
	$("#spinner").fadeOut("slow",function(){
		$(this).remove();
	});

}

function createUploader(){
	var uploader = new qq.FileUploader({
		element: document.getElementById('file-uploader-demo1'),
		listElement: document.getElementById('upload-progress'),
		action: '<?=ROOT_URL?>/admin/classes/upload.class.php',
		debug: false,
		params: {
			catid: '<?=$catid?>',
			subcatid: '<?=$subcatid?>',
			loadpaths: false
		},
		onProgress: function(id, fileName, loaded, total){$('.information').hide(); $("#upload_details").show()},
		onComplete: function(id, fileName, responseJSON){
			var msg = (responseJSON.success)?"Success":responseJSON.error;
			$("#upload-progress li:nth-child("+(id+1)+")").append("<span class = 'error'>"+msg+"</span>")
			if(responseJSON.success) {
				$("#thumbnails .thumb").append("<li id = '"+ responseJSON.id +"'><a class = 'lightbox' href='"+responseJSON.image_path+"'><img alt='' src = '"+responseJSON.thumb_path+"' class='img"+$("#thumbnails .thumb li").length+"'></a><span><a class = 'enlarge1' href='#'><img src = 'http://www.aviation-time.com/en/mediabase/_graphics/gif_jpg/img/enlarge_icon_black.gif'/></a><a class = 'edit' href='#'><img src = 'http://www.adprop.com.au/docs/images/edit_black.gif'/></a></span></li>");
				selectImage();
				thumbnailhover();
			}
		},
		showMessage: function(message){
			console.log(message);
		}    
	});           
}


//window.onload = createUploader;     
/**
 * The below function is responsible for selecting the image/images. Users can select multiple
 * images using the Ctrl+Click. 
 *
 * For multiple image selection the class, multiselect is added to the selected images.
 * For single image selection, the class singleselect is added.
 */
function selectImage() {
	var output = $('#output');
	
	
	$('.lightbox img').unbind('click')
		.each(function(i, el){
			$(this).addClass('img' + i);
		})
		.bind('click',function(e){
			e.stopPropagation();
			e.preventDefault();
			if (e.ctrlKey) {
				$('.thumb img').removeClass('singleselect');
				var $img = $(this).toggleClass('multiselect');					
				output.hide();
			} else {
				
				$('.thumb img').removeClass('multiselect').removeClass('singleselect');
				var $img = $(this).addClass('singleselect');		
				
				if($img.hasClass('singleselect'))
					//output.html($img.clone().removeClass('singleselect')).fadeIn();
					{
						getImageDescription();
						//$("#imagetips,#upload_details").remove();
						
						output.show();
						$('.information').hide();
					}
				else
				   {
						output.find('.' + $img[0].className.replace(" ",".")).remove();
						if(output.children('img').length == 0)
						output.hide();
				   }
			}
			
		});

}

function getImageDescription() {
	
	$("#output #title").attr('value','');
	$("#output #caption").attr('value','');
	$("#output #tags").attr('value','');
	var selectedImageId = $("#thumbnails .singleselect").parent().parent().attr('id');
	
	$.ajax({
		url:"<?=ROOT_URL.'/admin/classes/queries.class.php'?>",
		type: 'POST',
		data: "loadpaths=true&getDescription=true&selectedImageId="+selectedImageId,
		dataType: 'json',
		success: function(msg) {
			
			$("#output #title").attr('value',msg.title);
			$("#output #caption").attr('value',msg.caption);
			$("#output #tags").attr('value',msg.tags);
			$(".information").hide();
			$("#output").show();
			
		}
	});
}

function thumbnailhover() {		
	$("#thumbnails li").hover(function() {
			$(this).find('span').slideDown();
			return false;
		},function() {
			$(this).find('span').slideUp();
			return false;
	});		
}

var t;
$(document).ready(function() {
	
	createUploader();
	selectImage();
	thumbnailhover();	
	$("#plugin_list" ).buttonset();
	
/******************************************************************
 *
 */
 
	$("input:radio").change(function() {
		var plugin_tech_name = $(this).attr('id');
		var subcatid = "<?=$subcatid?>";
		var data = "update_cat_plugin=true&plugin_tech_name="+plugin_tech_name+"&subcatid="+subcatid;
		$.ajax({
			url: "<?=ROOT_URL?>/admin/classes/queries.class.php",
			data: data,
			type : "POST",
			success: function() {
			
			
			}
		
		});
		
		
	});
 
/******************************************************************
 * Delete image script
 */	

	$("#deleteimage").die("click").live('click', function() {
		
		var selectedImage = "deleteImage=true";
		var ifselected = false;
		
		$(".thumb li").each(function() {
			
			var obj = $(this);
			if($(this).find('.multiselect').length > 0 || $(this).find('.singleselect').length > 0)
			{				
				var thumblink = $(this).find('img').attr('src').split('/');
				var thumbname = thumblink[thumblink.length - 2]+'/'+thumblink[thumblink.length - 1];		
				var id = obj.attr('id');
				selectedImage += "&images[]=" + id+'!@-'+thumbname;				
				ifselected = true;
			}
		
		});
		
		if(ifselected)
		{
			$.ajax({
				url: '<?=ROOT_URL?>/admin/classes/queries.class.php',
				type: 'POST',
				data: selectedImage,
				dataType: 'json',
				success: function(msg) {										
					if(msg.success) {
						$('.multiselect,.singleselect').parent().parent().fadeOut().remove();
						$("#output #title").attr('value','');
						$("#output #caption").attr('value','');
						$("#output #tags").attr('value','');
						
						//$('#output').fadeOut();
					}
					
				}
			});
		}
	});	

/******************************************************************
 * Update single image information script
 */	
	$("#output .update").live('click',function() {
		
		if($("#title").val().trim().length == 0 && $("#tags").val().trim().length == 0 && $("#caption").val().trim().length == 0) 
		{
			$("#message").fadeIn().html("No data to update.").fadeOut(5000);
			return false;
		}
		$("#message").slideDown().html("Updating. Please Wait..");
		var selectedImageId = $("#thumbnails .singleselect").parent().parent().attr('id');
		var imageInfo = $("#image_info_form").serialize();
		$.ajax({
			url:"<?=ROOT_URL.'/admin/classes/queries.class.php'?>",
			type: 'POST',
			data: "loadpaths=true&update=true&selectedImageId="+selectedImageId+"&"+imageInfo,
			success: function(msg) {
				if(msg)
				$("#message").html("Updated Successfully.").fadeOut(5000);				
			}
		});

	
	});
	
/**
 * IMAGE SORTABLE
 */ 
	
	$( ".thumb" ).sortable({ cursor: 'crosshair' }).bind( "sortupdate", function(event, ui) {			
		var order = "image_pos=true&catid=<?=$catid?>&subcatid=<?=$subcatid?>&";			
		
		$(this).children('li').each(function(idx, elm) {
			
			if(elm.id.length > 0)
			{					
								
				order += 'imagepos[]='+elm.id+'&';
			}
			
		});                                     
		$.ajax({url:obj.queryURL + '/admin/classes/queries.class.php',type: "POST", data:order});
				
	});
	
	
/**
 *Enlarge Thumbnails
 */

 
 $("#thumbnails li span a.enlarge1").die('click').live('click', function(e) {
	
	e.preventDefault();
	var t = $(this).parent().parent().find('.lightbox'); 
	t.lightBox();	
	t.click();
	
 });

/**
 * Cover Page Action
 */
	$("#coverpagebut").click(function() {		
		
		$(".information").hide();
		$("#coverpage").show().find("#coverpage_box").html("<textarea id='input'>"+'<?=$coverpage?>'+"</textarea>");
		t = $("#input").cleditor({
          width:        '98%', // width not including margins, borders or padding
          height:       500, // height not including margins, borders or padding
		 // updateTextArea:function (){},
		 // updateFrame: function() {$("#input").val('<?=$coverpage?>')},
          controls:     // controls to add to the toolbar
                        "bold italic underline strikethrough subscript superscript | font size " +
                        "style | color highlight removeformat | bullets numbering | outdent " +
                        "indent | alignleft center alignright justify | undo redo | " +
                        "rule image link unlink | cut copy paste pastetext | print source",
          colors:       // colors in the color popup
                        "FFF FCC FC9 FF9 FFC 9F9 9FF CFF CCF FCF " +
                        "CCC F66 F96 FF6 FF3 6F9 3FF 6FF 99F F9F " +
                        "BBB F00 F90 FC6 FF0 3F3 6CC 3CF 66C C6C " +
                        "999 C00 F60 FC3 FC0 3C0 0CC 36F 63F C3C " +
                        "666 900 C60 C93 990 090 399 33F 60C 939 " +
                        "333 600 930 963 660 060 366 009 339 636 " +
                        "000 300 630 633 330 030 033 006 309 303",    
          fonts:        // font names in the font popup
                        "Arial,Arial Black,Comic Sans MS,Courier New,Narrow,Garamond," +
                        "Georgia,Impact,Sans Serif,Serif,Tahoma,Trebuchet MS,Verdana",
          sizes:        // sizes in the font size popup
                        "1,2,3,4,5,6,7",
          styles:       // styles in the style popup
                        [["Paragraph", "<p>"], ["Header 1", "<h1>"], ["Header 2", "<h2>"],
                        ["Header 3", "<h3>"],  ["Header 4","<h4>"],  ["Header 5","<h5>"],
                        ["Header 6","<h6>"]],
          useCSS:       false, // use CSS to style HTML when possible (not supported in ie)
         // docType:      // Document type contained within the editor
                       // '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">',
          docCSSFile:   // CSS file used to style the document contained within the editor
                        "", 
          bodyStyle:    // style to assign to document body contained within the editor
                        "margin:4px; font:10pt Arial,Verdana; cursor:text"
        });
		
	});

/**
 * HELP BUTTON TRIGGER
 */

	$("#helpbut").click(function() {
	
		$(".information").hide();
		$("#imagetips").show();
	});
/**
 * LINK PLUGINS TRIGGER
 */

	$("#link_plugin").click(function() {
	
		$(".information").hide();
		$("#gallery_plugins").show();
	});

/**
 * AUTO SAVE COVERPAGE
 */
	
	$("#coverpagewidth").die("focusout").live('focusout',function() {
		startSpinner();
		$.post('<?=ROOT_URL?>/admin/classes/queries.class.php?coverpage=true&catid=<?=$catid?>&subcatid=<?=$subcatid?>', { coverpage: $("#input").val(),coverpagestatus:$("#coverpagestatus").attr('state'),coverpagewidth: $("#coverpagewidth").val() } , function() {
			
			stopSpinner();
		
		});
				
		
	});
	$("#coverpage_save_but").click(function() {
	
		startSpinner();
		$.post('<?=ROOT_URL?>/admin/classes/queries.class.php?coverpage=true&catid=<?=$catid?>&subcatid=<?=$subcatid?>', { coverpage: $("#input").val(),coverpagestatus:$("#coverpagestatus").attr('state'),coverpagewidth: $("#coverpagewidth").val() } , function() {
			
			stopSpinner();
		
		});
	});
	$("#coverpagestatus").click(function() {
		startSpinner();
		var newstate = ($(this).hasClass('active'))?"inactive":"active";
		
		$(this).attr('state',newstate);
		$(this).removeClass('active');
		$(this).removeClass('inactive');
		$(this).addClass(newstate);
		$(this).html(newstate.charAt(0).toUpperCase() + newstate.slice(1));
		$.post('<?=ROOT_URL?>/admin/classes/queries.class.php?coverpage=true&catid=<?=$catid?>&subcatid=<?=$subcatid?>', { coverpage: $("#input").val(),coverpagestatus:$("#coverpagestatus").attr('state'),coverpagewidth: $("#coverpagewidth").val() },function() {
			stopSpinner();
		});
	});

/**
 * REMOVE CORNERS FROM PLUGINS
 */
	$("#gallery_plugins").find(".ui-button").removeClass('ui-corner-left').removeClass('ui-corner-right').addClass('ui-corner-all').css({'margin-bottom':'4px','margin-right':'4px'});

});
</script>
	<style type = "text/css">
	#thumbnails ul.thumb li .lightbox img {
		background: url("<?=ROOT_URL?>/resources/css/images/loading.gif") no-repeat scroll 40px 40px #DCDADA;
	}
	</style>
	
	<div id = "message">This is test message</div>
	<h2 class = 'upload_header_title headline'>Upload Images</h2>
	<button class = "toolbar cbutton" id = "deleteimage">Delete</button>
	<button class = "toolbar cbutton" id = "coverpagebut">Coverpage</button>	
	<button class = "toolbar cbutton" id = "link_plugin">Link Plugin</button>
	<button class = "toolbar cbutton" id = "helpbut">Help</button>
	<div id="file-uploader-demo1">		
		<noscript>			
			<p>Please enable JavaScript to use file uploader.</p>
			<!-- or put a simple form for upload here -->
		</noscript>         
	</div>
	<div id = "folder_path">
	<?=$folderPath?>
	</div>
	<div id = "thumbnails">
		<ul class = "thumb">

		<?=$thumbs?>
		</ul>
	</div>

<div id = "output" class = 'information'>
	<span id = "image_details_title" class="right-col-title">IMAGE DETAILS</span>
	<form id = "image_info_form">
		<label>
		   <span>Image Title</span>
		   <input type="text" class="input_text" name="title" id="title" tabindex = "1"/>
		</label>
		<label>
			<span>Tags</span>
			<input type="text" class="input_text" name="tags" id="tags" tabindex = "3"/>
			
			<div style="clear:both;"></div>
		</label>
		<label>
		   <span>Caption</span>
		  
		   <textarea class = "caption" name = "caption" id = "caption" tabindex = "2"/>
		</label>
		
		<input type="button" class="update" value="Update" tabindex = "4"/>
	</form>	
</div>

<div id = "imagetips" class = 'information'>
	<span id = "image_tips_title" class="right-col-title">IMAGE TIPS</span>
	<span id = "tips">
		This is image tips section. This will be changed on upgrades. Ignore this for the time being.
	</span>
</div>

<div id = "upload_details" class = 'information'>
	<span id = "image_uploaded_title" class="right-col-title">UPLOAD DETAILS</span>
	<ul id='upload-progress'></ul>
</div>

<div id = "coverpage" class = 'information'>
	<span id = "coverpage_title" class="right-col-title">
		COVERPAGE <i style="font-size:10px;color:#F97A0C">(Dont forget to save..)</i>
		<span class = "coverpage_toolbar">
			Width:<input name = "coverpagewidth" MAXLENGTH="3" id = "coverpagewidth" value = "<?=$coverpagewidth?>" type = "text" size = "3">
			<input type = "submit" class = "coverpage_but" value = "Save" id = "coverpage_save_but">
			<button class="<?=$coverpagestatus?> coverpage_but" state = "<?=$coverpagestatus?>" id="coverpagestatus"><?=ucfirst($coverpagestatus)?></button>
			
		</span>
	</span>
	<span id = "coverpage_box">
		<textarea id='input'>sample</textarea>
	</span>	
</div>
<div id = "gallery_plugins" class = 'information'>
	<span id = "gallery_title" class="right-col-title">SELECT PLUGIN</span>
	<span id = "plugin_list">
		<?=$gallery_plugin_list_markup?>
	</span>
</div>
