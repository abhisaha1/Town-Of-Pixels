<style type = "text/css">
#content_col {
	background: none repeat scroll 0 0 #444444;
	height: 100%;
}
#uploadtitle {	
	color: #ddd;
	border-bottom: 1px dotted #000000;
    color: #DDDDDD;    
    font-size: 12px;
    padding: 0 0 10px 10px;
}
#uploadtitle .label {
	display: inline-block;
    width: 130px;
}

</style>
<?php

include_once ("../../paths.php");
include_once(ROOT_DIR."/admin/pages/check.session.php");
$pbdb = new queries();
$navArr = $pbdb->prepareToUpload($_GET['catid'],$_GET['subcatid']);

$cat_id = $navArr['id'];
$cat_name = $navArr['cat_name'];
$sub_cat_id = $navArr['sub_cat_id'];
$sub_cat_name = $navArr['sub_name'];


?>
<div id = "uploadtitle">
	<span class = 'label'>Current Category</span><span class = 'name'>: <?=$cat_name?></span><p/>
	<span class = 'label'>Current Album</span><span class = 'name'>: <?=$sub_cat_name?></span>
</div>