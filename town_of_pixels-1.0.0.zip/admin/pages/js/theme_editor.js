var handle="no-repeat";
function repeatxylogic(objx,objy)
	{
		
		
		if(objx == "yes" && objy == "yes") {
			handle = "repeat";
		}
		if(objx == "no" && objy == "no") {
			handle = "no-repeat";
		}
		if(objx == "yes" && objy == "no") {
			handle = "repeat-x";
		}
		if(objx == "no" && objy == "yes") {
			handle = "repeat-y";
		}
		
		console.log(objx,objy);
		
		return handle;
	}

$('document').ready(function() {
	
	$("body").css('background',$("#fullbackground").val());
	$("#headerid").css('background',$("#header_color").val());
	$("#left_col_id").css('background',$("#fullbackground").val());
	$("#content_col_id").css('background',$("#gallery_color").val());
	$("#footerid").css('background',$("#footer_color").val());
	
	
	
	$(".input_text").keyup(function() {
		
		//NAVIGATION
		$("#"+left_col_id).css({
							'background-image':'url('+$("#navigationimage").val()+')',							
							'background-color': $("#navigation_color").val(),
							'background-size': $("#backgroundsize").val()
		})
		if(repeatxylogic("#navigationrepeatx","#navigationrepeaty") != "")
		{			console.log(repeatxylogic($("#navigationrepeatx").val(),$("#navigationrepeaty").val()));
			$("#"+left_col_id).css('background-repeat', repeatxylogic($("#navigationrepeatx").val(),$("#navigationrepeaty").val()));
		}
		
		//HEADER
		$("#"+headerid).css({
							'background-image':'url('+if($("#headerimage").val() != "")$("#headerimage").val()')',														
							'background-color': $("#header_color").val(),
							'background-size': $("#headersize").val()
		})
		if(repeatxylogic("#headerrepeatx","#headerrepeaty") != "")
		{
			$("#"+headerid).css('background-repeat', repeatxylogic($("#headerrepeatx").val(),$("#headerrepeaty").val()));
		}
		
		//CONTENT COLUMN
		$("#"+content_col_id).css({
							'background-image':'url('+$("#galleryimage").val()+')',														
							'background-color': $("#gallery_color").val(),
							'background-size': $("#gallerysize").val()
		})
		if(repeatxylogic($("#galleryrepeatx"),"#galleryrepeaty") != "")
		{
			$("#"+content_col_id).css('background-repeat',repeatxylogic($("#galleryrepeatx").val(),$("#galleryrepeaty").val()));
		}
		
		//FOOTER
		$("#"+footerid).css({
							'background-image':'url('+$("#nfooterimage").val()+')',							
							'background-color': $("#footer_color").val(),
							'background-size': $("#footersize").val()
		})
		if(repeatxylogic("#footerrepeatx","#footerrepeaty") != "")
		{
			$("#"+footerid).css('background-repeat', repeatxylogic($("#footerrepeatx").val(),$("#footerrepeaty").val()));
		}
	
	});
	
	
	/**
	 * SAVE THEME TO DATABASE
	 */
	$("#theme_submit_but").click(function() {
		$("#message").slideDown().html("Updating. Please Wait..");
		var data = $("#theme_editor").serialize();
		$.ajax({
			url: '<?=ROOT_URL?>/admin/classes/queries.class.php',
			data: "applyTheme=true&"+data,
			type: 'POST',
			success: function() {				
				$("#message").html("Theme updated successfully.").fadeOut(10000);
			}
			
		
		});
		
	});
	
});