function createUploader(){
	var uploader = new qq.FileUploader({
		element: document.getElementById('plugin-uploader'),
		action: '<?=ROOT_URL?>/admin/classes/plugin.upload.class.php',
		debug: true,
		params: {
			plugin_upload: true			
		},
		onProgress: function(id, fileName, loaded, total){$(".message").html("Uploading. Please Wait..").fadeIn("fast");},
		onComplete: function(id, fileName, responseJSON){
			var plugininfo = $.parseJSON(responseJSON.pluginData);
			
			if(responseJSON.success) {
				$("#info #plugintable").append(
								"<tr id= '"+plugininfo.plugin_tech_name+"'>"+
									"<td><input type = 'checkbox'></td>"+
									"<td class = 'plugin-activate' id = 'state'>Inactive</td>"+
									"<td>"+plugininfo.plugin_name[0]+"</td>"+
									"<td class='nav_status'>"+plugininfo.navigation[0]+"</td>"+
									"<td class='gallery_status'>"+plugininfo.gallery[0]+"</td>"+
									"<td>"+plugininfo.author[0]+"</td>"+
									"<td>"+plugininfo.weblink[0]+"</td>"+
									"<td>"+plugininfo.description[0]+"</td>"+
								"</tr>");
				
				$(".message").html("Plugin Installed Successfully...").fadeIn("fast");$(".message").delay(5000).fadeOut("slow");
				
			}else
			{
				$(".message").html("Failed. Either the Plugin is installed or not in proper format.").fadeIn("fast");$(".message").delay(5000).fadeOut("slow");
			}
		},
		showMessage: function(message){
			console.log(message);
		}    
	});           
}
$(document).ready(function() {
	
	createUploader();
	var nav_active = false,gallery_active = false;
	
	
	$("#state").die("click").live('click',function() {
		
		
		$.ajax({
			url: "<?=ROOT_URL?>/admin/classes/queries.class.php",
			type: "POST",
			data: "pluginActivation=true&current_plugin="+$(this).parent().attr('id'),
			success: function() {
				$(".message").html("Changes Saved.").fadeIn("fast");$(".message").delay(2000).fadeOut("slow");
			}
		
		});
		$(this).parent().addClass('current');
		
		/**
		 * First we get the section where this plugin will load.
		 * There are two sections.
		 * Gallery and Navigation
		 */
		var current_nav_status = $(".current .nav_status").html();
		var current_gallery_status = $(".current .gallery_status").html();
		/**
		 * Check the state of exsisting plugins.
		 * This excludes the current uploaded plugin and the plugin selected to activate.
		 */
		$("#info #plugintable tr:not('.current')").each(function() {
			
			var nav_status = $(this).find(".nav_status").html();
			var gallery_status = $(this).find(".gallery_status").html();
			if(nav_status == "true" && current_nav_status == "true")
			{				
				$(this).find("#state").attr('class','plugin-activate').html("Inactive");
				
			}
			if(gallery_status == "true" && current_gallery_status == "true")
			{				
				$(this).find("#state").attr('class','plugin-activate').html("Inactive");
			}
			
		
		});
		
		var state = ($(this).attr('class') == "plugin-de-activate")?"Inactive":"Active";
		var newclass = ($(this).attr('class') == "plugin-de-activate")?"plugin-activate":"plugin-de-activate";
		$(this).html(state);
		$(this).attr('class',newclass);
		$(this).parent().removeClass('current');
	
	});
	
	/**
	 * DELETE PLUGINS
	 */
		$("#deleteplugin").click(function() {
			
					
			$("#plugintable input:checked").each(function() {

				var pluginId = $(this).parent().attr('id');
				var plugin_tech_name = $(this).parent().parent().attr('id');
				$.ajax({
					url: "<?=ROOT_URL?>/admin/classes/queries.class.php",
					type: "POST",
					data: "deletePlugin=true&plugin_tech_name="+plugin_tech_name+"&pluginId="+pluginId,
					dataType: 'json',
					success: function(msg) {
						if(msg.success)
						$("#"+plugin_tech_name).remove();
						$(".message").html("Plugin Un-Installed Successfully...").fadeIn("fast");$(".message").delay(5000).fadeOut("slow");
					}
				
				});

			});
		
		});
	
});