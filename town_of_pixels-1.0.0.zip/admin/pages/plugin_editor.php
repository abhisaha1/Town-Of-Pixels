<style type = "text/css">
h2.plugin_editor_header{
	color: #7D7D7D;
	border-bottom: 1px dotted #404040;
	margin-bottom:20px;
}

.plugin_editor_title {
	margin-bottom: 30px;
	color: #8E8E8E;
	margin-left: 50px;
	font-family: times New Roman;
	display:block;
}
#pluginfolder {
	height: 100%;
    position: absolute;
	background: #CCC;
	margin-left: 50px;
}
#pluginfolder ul{
	list-style-type: none;
}
textarea {background: none repeat scroll 0 0 #EDEDED;
    border: 1px solid #CCCCCC;
    color: #121212;
    font-family: monospace;
    height: 600px;
    width: 80%;
}
#plugin_edit,#file_editor {
	margin-left: 50px;
}
select {
	border: 1px solid #CCC;
	padding: 1px;
}
#plugin_edit{
	background: none repeat scroll 0 0 #FFFFFF;
    padding: 5px;
    width: 801px;
}
#plugin_code_save {
	background: none repeat scroll 0 0 #282828;
    border: 1px solid #333333;
    color: #CCCCCC;
    cursor: pointer;    
    padding: 1px 5px;
    position: relative;   
    width: 50px;
}
#plugin_code_save:hover {
	background: #151515
}
#message {
	background: none repeat scroll 0 0 #880000;
    color: #A4A4A4;
    font-family: Times New Roman;
    font-size: 13px;
    padding: 8px;
	display:none;	
    width: 100%;
}
</style>

<div id = "message"></div>
<h2 class = 'plugin_editor_header headline'>Plugin Editor</h2>
<span class = "plugin_editor_title headdesc">
	You can edit the plugin files from here. 
	<span class = 'note'><br/>(Only meant for developers)</span>
</span>

<?php 
include_once('../../paths.php');

global $pbdb;
$plugins = $pbdb->displayAllPlugins();


$pluginsFolder = '<div id = "plugin_edit">
					<select id = "plugin_dirs_select">
						<option value = "">-Select-</option>';
foreach($plugins as $key => $pluginArr) {
	
	$plugin_name = $pluginArr['plugin_name'];
	$plugin_tech_name = str_replace("//","/",$pluginArr['plugin_tech_name']);
	$pluginsFolder .=   "<option value = '$plugin_tech_name'>".$plugin_name."</option>";

}

$pluginsFolder .= 	'</select>						 
				  </div>';
echo $pluginsFolder;
?>

<div id = "file_editor"></div>

<script language = "javascript">

	$(document).ready(function() {
		var savebutton = "<button id = 'plugin_code_save' class='cbutton'>Save</button>";
		//SELECT PLUGIN FOLDER
		$("#plugin_dirs_select").change(function() {
			var pluginFolder = $(this).val();
			$("#file_editor").html('');
			if(pluginFolder != "") {
				$.ajax({
					url: "<?=ROOT_URL?>/admin/pages/scan_plugin_files.php",
					type: "POST",
					data: "plugin_folder="+pluginFolder,
					success: function(msg) {
						$("#plugin_edit #plugin_files_select,#plugin_code_save").remove();
						$("#plugin_edit").append(msg);
					
					}
					
				
				});
			}else $("#plugin_edit #plugin_files_select,#plugin_code_save").remove();
			
		});
		
		//SELECT FILE FROM A PLUGIN TO EDIT
		$("#plugin_files_select").die("change").live('change',function() {
			
			var pluginFile = $(this).val();
			var pluginFolder = $("#plugin_dirs_select").val();
			$("#plugin_code_save").remove();
			if(pluginFile != "") {
				$.ajax({
					url: "<?=ROOT_URL?>/admin/pages/edit_plugin_file.php",
					type: "POST",
					data: "fileselect=true&plugin_folder="+pluginFolder+"&plugin_file="+pluginFile,
					success: function(msg) {
						$("#file_editor").html('');
						$("#file_editor").html("<textarea class = 'plugin_code' wrap='off'>"+msg+"</textarea>");
						$("#plugin_edit").append(" "+savebutton);
					}
					
				
				});
			}else {
				$("#file_editor").html('');				
			}
			
		});
		
		//SAVE CODE
		$("#plugin_code_save").die("click").live("click", function() {
			var pluginFile = $("#plugin_files_select").val();
			var pluginFolder = $("#plugin_dirs_select").val();
			var code = mod_escape($(".plugin_code").val());
			$.ajax({
				url: "<?=ROOT_URL?>/admin/pages/edit_plugin_file.php",
				type: "POST",
				data: "savecode=true&plugin_folder="+pluginFolder+"&plugin_file="+pluginFile+"&code="+code,
				success: function(msg) {
					$("#message").html("Saved Successfully..").slideDown().delay(2000).slideUp();
				}					
				
			});
		
		});
		function mod_escape(code) {				  
			newcode = code.replace(/\+/g,"&#43;");
			newcode = newcode.replace(/\*/g,"&#42;");
			newcode = newcode.replace(/\@/g,"&#64;");
			newcode = newcode.replace(/\-/g,"&#45;");
			newcode = newcode.replace(/\_/g,"&#95;");
			newcode = newcode.replace(/\./g,"&#46;");
			newcode = newcode.replace(/\//g,"&#47;");
			return escape(newcode);		  
		}
	});

</script>
