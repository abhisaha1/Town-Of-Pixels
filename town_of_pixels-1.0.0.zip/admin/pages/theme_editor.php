<?php
include_once("../../paths.php");
include_once(ROOT_DIR."/admin/pages/check.session.php");
$pbdb = new queries();
$theme = $pbdb->getTheme();

$header_color = $theme['header_color'];
$navigation_color = $theme['navigation_color'];
$gallery_color = $theme['gallery_color'];
$footer_color = $theme['footer_color'];

$navigationimage = $theme['navigationimage'];
$navigationsize = $theme['navigationsize'];
$navigationrepeatx = $theme['navigationrepeatx'];
$navigationrepeaty = $theme['navigationrepeaty'];

$headerimage = $theme['headerimage'];
$headersize = $theme['headersize'];
$headerrepeatx = $theme['headerrepeatx'];
$headerrepeaty = $theme['headerrepeaty'];

$galleryimage = $theme['galleryimage'];
$gallerysize = $theme['gallerysize'];
$galleryrepeatx = $theme['galleryrepeatx'];
$galleryrepeaty = $theme['galleryrepeaty'];

$footerimage = $theme['footerimage'];
$footersize = $theme['footersize'];
$footerrepeatx = $theme['footerrepeatx'];
$footerrepeaty = $theme['footerrepeaty'];


/**
 * LEFT-MENU-FONT-COLOR
 */
$navigationcatcol = $theme['navigationcatcol'];
$navigationsubcatcol = $theme['navigationsubcatcol'];

/**
 * HEADER COLOR
 */
$header_font_color = $theme['header_font_color'];
$header_title_color = $theme['header_title_color'];

/**
 * COMMENT COLOR
 */
$comment_bg_color = $theme['comment_bg_color'];
$comment_bg_opacity = $theme['comment_bg_opacity'];
?>

<script language = "javascript">
var handle="no-repeat";
function repeatxylogic(objx,objy)
	{
		
		
		if(objx == "yes" && objy == "yes") {
			handle = "repeat";
		}
		if(objx == "no" && objy == "no") {
			handle = "no-repeat";
		}
		if(objx == "yes" && objy == "no") {
			handle = "repeat-x";
		}
		if(objx == "no" && objy == "yes") {
			handle = "repeat-y";
		}
		
		
		
		return handle;
	}

$('document').ready(function() {
	
	$("body").css('background',$("#fullbackground").val());
	$("#headerid").css('background',$("#header_color").val());
	$("#left_col_id").css('background',$("#fullbackground").val());
	$("#content_col_id").css('background',$("#gallery_color").val());
	$("#footerid").css('background',$("#footer_color").val());
	
	
	
	$(".input_text").keyup(function() {
		
		//NAVIGATION
		$(".colleft").css({
							'background':$("#navigation_color").val(),
							'background-image':'url('+$("#navigationimage").val()+')',							
							'background-color': $("#navigation_color").val(),
							'background-size': $("#navigationsize").val(),
							'background-repeat': $("#navigationrepeatx").val(),
							'background-position': $("#navigationrepeaty").val()
		});
		
		
		if(repeatxylogic("#navigationrepeatx","#navigationrepeaty") != "")
		{			//console.log(repeatxylogic($("#navigationrepeatx").val(),$("#navigationrepeaty").val()));
			//$(".colleft").css('background-repeat', repeatxylogic($("#navigationrepeatx").val(),$("#navigationrepeaty").val()));
		}
		
		//HEADER
		$("#"+headerid).css({
							'background-image':'url('+$("#headerimage").val()+')',														
							'background-color': $("#header_color").val(),
							'background-size': $("#headersize").val()
		});
		if(repeatxylogic("#headerrepeatx","#headerrepeaty") != "")
		{
			$("#"+headerid).css('background-repeat', repeatxylogic($("#headerrepeatx").val(),$("#headerrepeaty").val()));
		}
		
		//CONTENT COLUMN
		$("#"+content_col_id).css({
							'background':$("#gallery_color").val(),
							'background-image':'url('+$("#galleryimage").val()+')',														
							'background-color': $("#gallery_color").val(),
							'background-size': $("#gallerysize").val(),
							'background-repeat': $("#galleryrepeatx").val(),
							'background-position': $("#galleryrepeaty").val()
		})
		if(repeatxylogic($("#galleryrepeatx"),"#galleryrepeaty") != "")
		{
			//$("#"+content_col_id).css('background-repeat',repeatxylogic($("#galleryrepeatx").val(),$("#galleryrepeaty").val()));
		}
		
		//FOOTER
		$("#"+footerid).css({
							'background':$("#footer_color").val()
							//'background-image':'url('+$("#nfooterimage").val()+')',							
							//'background-color': $("#footer_color").val(),
							//'background-size': $("#footersize").val()
		})
		if(repeatxylogic("#footerrepeatx","#footerrepeaty") != "")
		{
			//$("#"+footerid).css('background-repeat', repeatxylogic($("#footerrepeatx").val(),$("#footerrepeaty").val()));
		}
		
		//HEADER TITLE
		$("#header_title").css('color',$("#header_font_color").val());
		$("#header_tag").css('color',$("#header_title_color").val());
	
	});
	
	
	/**
	 * SAVE THEME TO DATABASE
	 */
	$("#theme_submit_but").click(function() {
		$("#message").slideDown().html("Updating. Please Wait..");
		var data = $("#theme_editor").serialize();
		$.ajax({
			url: '<?=ROOT_URL?>/admin/classes/queries.class.php',
			data: "applyTheme=true&"+data,
			type: 'POST',
			success: function() {				
				$("#message").html("Theme updated successfully.").fadeOut(10000);
			}
			
		
		});
		
	});
	
	$("#theme_editor .section-desc").click(function() {
		handle = $(this).parent().find(".items");
		sectionvisibility = (handle.css('display') == "none")?false:true;
		$("#theme_editor .items").slideUp();		
		if(sectionvisibility == false)
		$(this).parent().find(".items").slideDown();
	
	});
	
});

</script>
<style type = "text/css">
#theme_editor *{
	font-family: times New Roman;
}
#theme_editor {
	margin-left:50px;
}
#theme_editor div.items {
	width:100%;
	display: block;	
	padding:15px 0;
	color: #BBBBBB;
	font-size: 12px;
	display: none;
}
#message {
	background: none repeat scroll 0 0 #232323;
    color: #A4A4A4;
    font-family: Times New Roman;
    font-size: 13px;
    padding: 8px;
	display:none;
	
}
.meta_desc {
	padding:5px;
	width:25%;
	height: 40px;	
	background:#171717;
	border: 1px solid #292929;
	color: #CCC;
}
.update {
    margin: 0 0 10px 270px;
    padding: 4px 7px;
    position: relative;
    top: 10px;
    width: 50px;
}

.explaination {
	color: #1E6299;
    font-style: italic;
    margin-left: 360px;
}
#theme_editor h5{
	color: #006796;
    width: 500px;	
	cursor:pointer;
}
h2.theme_editor_header{
	color: #7D7D7D;
	border-bottom: 1px dotted #404040;
	margin-bottom:20px;
}

.theme_editor_title {
	margin-bottom: 30px;
	color: #8E8E8E;
	margin-left: 50px;
	font-family: times New Roman;
	display:block;
}
#theme_submit_but {
	margin-bottom: 20px;
    margin-left: 332px;
    margin-top: 40px;
}

.theme_editor_title .note{
	color: #FF6500;
    font-family: monospace;
	font-style: italic;
}

code {
	border: 1px solid #484848;
    color: #B43636;
    padding: 5px 5px 5px 5px;
}
</style>
<div id = "message"></div>
<h2 class = 'theme_editor_header headline'>Theme Editor</h2>
<span class = "theme_editor_title">
	You can take control of the entire theme by configuring the below settings. It will dynamically change the admin-panel theme for quick preview.
	<span class = 'note'><br/>(You can enter colors in hex or names. eg. #FFFFFF, #CCCCCC, black, grey etc...)</span>

	
</span>
<form id = "theme_editor">	
	<div class = "section">
		<h5 class='section-desc'>NAVIGATION</h5>
		<div class = "items">	
		   <label class='input_label'>Navigation Background Color</label>
		   <input type="text" class="input_text ui-corner-all" name="navigation_color" id="navigation_color" value = "<?=$navigation_color?>" tabindex = "1"/>
		</div>
		<!--
			----------------FOR FUTURE UPGRADE----------------
		-->
		<div class = "items">
		   <label class='input_label'>Navigation Image</label>
		   <input type="text" class="input_text ui-corner-all" name="navigationimage" id="navigationimage" value = "<?=$navigationimage?>" tabindex = "1"/>
		</div>
		<div class = "items">
		   <label class='input_label'>Navigation Size:</label>
		   <input type="text" class="input_text ui-corner-all" name="navigationsize" id="navigationsize" value = "<?=$navigationsize?>" tabindex = "1"/>
		</div>		
		<div class = "items">
		   <label class='input_label'>Navigation Background Repeat:</label>
		   <input type="text" class="input_text ui-corner-all" name="navigationrepeatx" id="navigationrepeatx" value = "<?=$navigationrepeatx?>" tabindex = "1"/>
		</div>
		<div class = "items">
		   <label class='input_label'>Navigation Background Position:</label>
		   <input type="text" class="input_text ui-corner-all" name="navigationrepeaty" id="navigationrepeaty" value = "<?=$navigationrepeaty?>" tabindex = "1"/>
		</div> 
		<div class = "items">
		   <label class='input_label'>Navigation Category Color:</label>
		   <input type="text" class="input_text ui-corner-all" name="navigationcatcol" id="navigationcatcol" value = "<?=$navigationcatcol?>" tabindex = "1"/>
		</div>
		<div class = "items">
		   <label class='input_label'>Navigation Sub-Category Color:</label>
		   <input type="text" class="input_text ui-corner-all" name="navigationsubcatcol" id="navigationsubcatcol" value = "<?=$navigationsubcatcol?>" tabindex = "1"/>
		</div>
	</div>
	
	
	<div class = "section">
		<h5 class = "section-desc">HEADER</h5>
		<div class = "items">
		   <label class='input_label'>Header Background Color</label>
		   <input type="text" class="input_text ui-corner-all" name="header_color" id="header_color" value = "<?=$header_color?>" tabindex = "1"/>
		</div>
		<div class = "items">
		   <label class='input_label'>Header Font Color</label>
		   <input type="text" class="input_text ui-corner-all" name="header_font_color" id="header_font_color" value = "<?=$header_font_color?>" tabindex = "1"/>
		</div>
		<div class = "items">
		   <label class='input_label'>Header Title Color</label>
		   <input type="text" class="input_text ui-corner-all" name="header_title_color" id="header_title_color" value = "<?=$header_title_color?>" tabindex = "1"/>
		</div>
		<!--
			----------------FOR FUTURE UPGRADE----------------
		<div class = "items">
		   <label class='input_label'>Header Logo</label>
		  <input type="text" class="input_text ui-corner-all" name="header_color" id="header_color" value = "<?=$header_color?>" tabindex = "1"/>
		</div>
		
		
		<div class = "items">
		   <label class='input_label'>Header Image</label>
		   <input type="text" class="input_text ui-corner-all" name="headerimage" id="headerimage" value = "<?=$headerimage?>" tabindex = "1"/>
		</div>
		<div class = "items">
		   <label class='input_label'>Header Size:</label>
		   <input type="text" class="input_text ui-corner-all" name="headersize" id="headersize" value = "<?=$headersize?>" tabindex = "1"/>
		</div>		
		<div class = "items">
		   <label class='input_label'>Header Background Repeat-x:</label>
		   <input type="text" class="input_text ui-corner-all" name="headerrepeatx" id="headerrepeatx" value = "<?=$headerrepeatx?>" tabindex = "1"/>
		</div>
		<div class = "items">
		   <label class='input_label'>Header Background Repeat-y:</label>
		   <input type="text" class="input_text ui-corner-all" name="headerrepeaty" id="headerrepeaty" value = "<?=$headerrepeaty?>" tabindex = "1"/>
		</div>-->
	</div>
	
	
	<div class = "section">
		<h5 class = "section-desc">GALLERY</h5>
		<div class = "items">
		   <label class='input_label'>Gallery Background Color</label>
		   <input type="text" class="input_text ui-corner-all" name="gallery_color" id="gallery_color" value = "<?=$gallery_color?>" tabindex = "1"/>
		</div>
		<!--
			----------------FOR FUTURE UPGRADE----------------
		-->
		<div class = "items">
		   <label class='input_label'>Gallery Image</label>
		   <input type="text" class="input_text ui-corner-all" name="galleryimage" id="galleryimage" value = "<?=$galleryimage?>" tabindex = "1"/>
		</div>
		<div class = "items">
		   <label class='input_label'>Gallery Size:</label>
		   <input type="text" class="input_text ui-corner-all" name="gallerysize" id="gallerysize" value = "<?=$gallerysize?>" tabindex = "1"/>
		</div>
		
		<div class = "items">
		   <label class='input_label'>Gallery Background Repeat:</label>
		   <input type="text" class="input_text ui-corner-all" name="galleryrepeatx" id="galleryrepeatx" value = "<?=$galleryrepeatx?>" tabindex = "1"/>
		</div>
		<div class = "items">
		   <label class='input_label'>Gallery Background Position:</label>
		   <input type="text" class="input_text ui-corner-all" name="galleryrepeaty" id="galleryrepeaty" value = "<?=$galleryrepeaty?>" tabindex = "1"/>
		</div>
	</div>
	
	
	<div class = "section">
		<h5 class = "section-desc">FOOTER</h5>
		<div class = "items">
		   <label class='input_label'>Footer Background Color</label>
		   <input type="text" class="input_text ui-corner-all" name="footer_color" id="footer_color" value = "<?=$footer_color?>" tabindex = "1"/>
		</div>
		<!--
			----------------FOR FUTURE UPGRADE----------------
		
		
		<div class = "items">
		   <label class='input_label'>Footer Image</label>
		   <input type="text" class="input_text ui-corner-all" name="footerimage" id="footerimage" value = "<?=$footerimage?>" tabindex = "1"/>
		</div>
		<div class = "items">
		   <label class='input_label'>Footer Size:</label>
		   <input type="text" class="input_text ui-corner-all" name="footersize" id="footersize" value = "<?=$footersize?>" tabindex = "1"/>
		</div>		
		<div class = "items">
		   <label class='input_label'>Footer Background Repeat-x:</label>
		   <input type="text" class="input_text ui-corner-all" name="footerrepeatx" id="footerrepeatx" value = "<?=$footerrepeatx?>" tabindex = "1"/>
		</div>
		<div class = "items">
		   <label class='input_label'>Gallery Background Repeat-y:</label>
		   <input type="text" class="input_text ui-corner-all" name="footerrepeaty" id="footerrepeaty" value = "<?=$footerrepeaty?>" tabindex = "1"/>
		</div>-->
	</div>
	
	<div class = "section">
		<h5 class = "section-desc">COMMENTS</h5>
		<div class = "items">
		   <label class='input_label'>Comment Background Color</label>
		   <input type="text" class="input_text ui-corner-all" name="comment_bg_color" id="comment_bg_color" value = "<?=$comment_bg_color?>" tabindex = "1"/>
		</div>
		
		<div class = "items">
		   <label class='input_label'>Comment Background Opacity</label>
		   <input type="text" class="input_text ui-corner-all" name="comment_bg_opacity" id="comment_bg_opacity" value = "<?=$comment_bg_opacity?>" tabindex = "1"/>
		</div>
		
	</div>
</form>

		<input type="submit" name="theme_submit_but" class = "ui-corner-all cbutton" id="theme_submit_but" value = "Save" tabindex = "1"/>