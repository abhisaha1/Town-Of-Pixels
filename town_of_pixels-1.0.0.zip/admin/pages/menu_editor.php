<?php
include_once ("../../paths.php");
include_once(ROOT_DIR."/admin/pages/check.session.php");
$pbdb = new queries();

$edit_icon = ROOT_URL.'/admin/images/edit.png';
$upload_icon = ROOT_URL.'/admin/images/folder.jpg';
$delete_icon = ROOT_URL.'/admin/images/delete.png';

/*********************************************************************************
 * getNavigationData contains the information of Categories and Sub-Categories.
 * The DIV - #menueditor contains this markup. 
**********************************************************************************/
	$navArr = $pbdb->getAllNavigationData();
?>
<!--Menu Editor Heading -->
<h2 class = 'menu_header headline'>Categories & Images</h2>
<div id = "menueditor_heading" class="headdesc">
	Create, Edit or Delete menus. You can also reorder the menus by dragging them up or down.
</div>

<script type="text/javascript">

/* var script = document.createElement( 'script' );
script.type = 'text/javascript';
script.src = "<?=ROOT_URL.'/resources/js/menu-editor.js'?>";
$("head").append( script );  */

$(document).ready(function() {  
	Menu_editor.queryURL = "<?=ROOT_URL?>";
	Menu_editor.images.edit_icon = "<?=ROOT_URL?>/admin/images/edit.png";
	Menu_editor.images.upload_icon = "<?=ROOT_URL?>/admin/images/folder.jpg";
	Menu_editor.images.delete_icon = "<?=ROOT_URL?>/admin/images/delete.png";
    Menu_editor.init();	
});

</script>

<?php
	$menumarkup = "<div id = 'menueditor'>";

	foreach($navArr as $key => $array)
	{
		$count = 1;		
		$catid = $navArr[$key][0]['cat_id'];
		$menumarkup .= "<ul class = 'navigation-list' id = '".$catid."'>";	
		
		$menumarkup .= ($count == 1)?"<li class = 'section-title'><span class = 'cat_name'>".$key."</span><span class = 'add_new_sub'>Add New Sub Category</span></li>":"";
		
		foreach($array as $key => $value)
		{		
			
			
			if($value['sub_cat_name'] != "")
			{
				$subcatid =  $value['sub_cat_id'];
				$count++;
				$totalImages = $pbdb->getImageCount($catid,$subcatid);
				$defaulter = ($pbdb->getDefaulter($subcatid))?"<span subcatid = '$subcatid' class= 'unmarkdefault'>Default</span>":"<span subcatid = '$subcatid' class= 'markdefault'>Mark Default</span>";
				$menumarkup .= "<li class = 'sub-section' id = 'listItem_$subcatid'>
									<span class='controls'>
										<img title = 'Delete' class = 'delete_sub_cat' src = '".$delete_icon."'/>
										<img title = 'Rename' class = 'edit_sub_cat' src = '".$edit_icon."'/>
										<img title = 'Browse & Upload' class = 'upload_sub_cat' src = '".$upload_icon."'/>
										<a class = '".$value['state']."' href='#'>".$value['state']."</a>
									</span>
									<span class='handle'>".$value['sub_cat_name']."</span>									
									<span class= 'imagecount'>($totalImages)</span>
									$defaulter
								</li>";			
			}
		}
		
		$menumarkup .= "</ul>";

	}

	$menumarkup .= "</div>";
	

/*********************************************************************************
 * getCategories contains the information of Categories.
 * The DIV - #menueditor contains this markup. 
**********************************************************************************/

	$catArr = $pbdb->getCategories();
	
	
	$catmarkup = "<div id = 'categoryeditor'>";
		
	$count = 1;
	$catmarkup .= "<ul class = 'navigation-list'>";	

	$catmarkup .= "<li class = 'section-title'><span class = 'cat_name'>Categories</span><span class = 'add_cat'>Add New Category</span></li>";
	foreach($catArr as $position => $array)
	{		
		$count++;
		$catid =  key($array);
		$catmarkup .= "<li class = 'sub-section' id = 'listItem_$catid'><span class='controls'><img title = 'Delete this category (Its sub categories will also be deleted)' class = 'delete_cat' src = '".$delete_icon."'/><img class = 'edit_cat' src = '".$edit_icon."'/></span><span class='handle section'>".$array[$catid]."</span></li>";			
	}

	$catmarkup .= "</ul>";

	$catmarkup .= "</div>";
	
?>
<table id = "cat_subcat" width = "96%" style = "display:none">
<tr>	
	<td class = "category_section" valign="top"><?=$catmarkup?></td>
	<td><?=$menumarkup?></td>
</tr>
</table>


<div style = "display:none" id="delete-confirm" title="Are you Serious ?">
	<p>
		<span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
		Are you sure you want to delete this ? Think again. I wont ask you twice.
	</p>
</div>