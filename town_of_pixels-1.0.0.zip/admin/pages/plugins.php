<?php
include_once("../../paths.php");			
include_once(ROOT_DIR."/admin/pages/check.session.php");
$pbdb = new queries();
$pluginData = $pbdb->displayAllPlugins();
$pluginMarkup = "";
if(sizeof($pluginData) > 0):

foreach($pluginData as $key => $array)
{
	$stateclass = ($array['status'] == "Active")?"plugin-de-activate":"plugin-activate";
	$pluginMarkup .= "<tr id = '".$array['plugin_tech_name']."'>
						<td id = '".$array['id']."'><input type = 'checkbox'></td>
						<td class = '$stateclass' id = 'state'>".$array['status']."</td>
						<td>".$array['plugin_name']."</td>		
						<td class='nav_status'>".$array['navigation']."</td>
						<td class='gallery_status'>".$array['gallery']."</td>
						<td>".$array['author']."</td>
						<td>".$array['weblink']."</td>
						<td>".$array['description']."</td>
					  <tr>";
}
endif;
?>
<link href="<?=ROOT_URL.'/resources/css/fileuploader.css'?>" rel="stylesheet" type="text/css">	
<script src="<?=ROOT_URL.'/resources/js/fileuploader.js'?>" type="text/javascript"></script>
<script type = "text/javascript">
function createUploader(){
	var uploader = new qq.FileUploader({
		element: document.getElementById('plugin-uploader'),
		action: '<?=ROOT_URL?>/admin/classes/plugin.upload.class.php',
		debug: true,
		params: {
			plugin_upload: true			
		},
		onProgress: function(id, fileName, loaded, total){$(".message").html("Uploading. Please Wait..").fadeIn("fast");},
		onComplete: function(id, fileName, responseJSON){
			var plugininfo = $.parseJSON(responseJSON.pluginData);
			
			if(responseJSON.success) {
				$("#info #plugintable").append(
								"<tr id= '"+plugininfo.plugin_tech_name+"'>"+
									"<td><input type = 'checkbox'></td>"+
									"<td class = 'plugin-activate' id = 'state'>Inactive</td>"+
									"<td>"+plugininfo.plugin_name[0]+"</td>"+
									"<td class='nav_status'>"+plugininfo.navigation[0]+"</td>"+
									"<td class='gallery_status'>"+plugininfo.gallery[0]+"</td>"+
									"<td>"+plugininfo.author[0]+"</td>"+
									"<td>"+plugininfo.weblink[0]+"</td>"+
									"<td>"+plugininfo.description[0]+"</td>"+
								"</tr>");
				
				$(".message").html("Plugin Installed Successfully...").fadeIn("fast");$(".message").delay(5000).fadeOut("slow");
				
			}else
			{
				$(".message").html("Failed. Either the Plugin is installed or not in proper format.").fadeIn("fast");$(".message").delay(5000).fadeOut("slow");
			}
		},
		showMessage: function(message){
			console.log(message);
		}    
	});           
}
$(document).ready(function() {
	
	createUploader();
	var nav_active = false,gallery_active = false;
	
	
	$("#state").die("click").live('click',function() {
		
		
		$.ajax({
			url: "<?=ROOT_URL?>/admin/classes/queries.class.php",
			type: "POST",
			data: "pluginActivation=true&current_plugin="+$(this).parent().attr('id'),
			success: function() {
				$(".message").html("Changes Saved.").fadeIn("fast");$(".message").delay(2000).fadeOut("slow");
			}
		
		});
		$(this).parent().addClass('current');
		
		/**
		 * First we get the section where this plugin will load.
		 * There are two sections.
		 * Gallery and Navigation
		 */
		var current_nav_status = $(".current .nav_status").html();
		var current_gallery_status = $(".current .gallery_status").html();
		/**
		 * Check the state of exsisting plugins.
		 * This excludes the current uploaded plugin and the plugin selected to activate.
		 */
		$("#info #plugintable tr:not('.current')").each(function() {
			
			var nav_status = $(this).find(".nav_status").html();
			var gallery_status = $(this).find(".gallery_status").html();
			if(nav_status == "true" && current_nav_status == "true")
			{				
				$(this).find("#state").attr('class','plugin-activate').html("Inactive");
				
			}
			if(gallery_status == "true" && current_gallery_status == "true")
			{				
				$(this).find("#state").attr('class','plugin-activate').html("Inactive");
			}
			
		
		});
		
		var state = ($(this).attr('class') == "plugin-de-activate")?"Inactive":"Active";
		var newclass = ($(this).attr('class') == "plugin-de-activate")?"plugin-activate":"plugin-de-activate";
		$(this).html(state);
		$(this).attr('class',newclass);
		$(this).parent().removeClass('current');
	
	});
	
	/**
	 * DELETE PLUGINS
	 */
		$("#deleteplugin").click(function() {
			
					
			$("#plugintable input:checked").each(function() {

				var pluginId = $(this).parent().attr('id');
				var plugin_tech_name = $(this).parent().parent().attr('id');
				$.ajax({
					url: "<?=ROOT_URL?>/admin/classes/queries.class.php",
					type: "POST",
					data: "deletePlugin=true&plugin_tech_name="+plugin_tech_name+"&pluginId="+pluginId,
					dataType: 'json',
					success: function(msg) {
						if(msg.success)
						$("#"+plugin_tech_name).remove();
						$(".message").html("Plugin Un-Installed Successfully...").fadeIn("fast");$(".message").delay(5000).fadeOut("slow");
					}
				
				});

			});
		
		});
	
});
</script>
<link rel="stylesheet" type="text/css" href="<?=ROOT_URL.'/admin/pages/css/plugins.css'?>" media="screen">

<h2 class = 'plugin_header headline'>Plugins</h2>
<span class = "headdesc">
	You can activate a Plugin here which will be used as global plugin for all sub-sections. If you want a different plugin
	for a particular subsection you can do so by going to Menu-Editor->Browse & Upload(Click Folder Icon)->Link Plugins.
</span>
<div id="plugin-uploader">		
		<noscript>			
			<p>Please enable JavaScript to use file uploader.</p>
			<!-- or put a simple form for upload here -->
		</noscript>         
</div>
<button class = "toolbar cbutton" id = "deleteplugin">Delete</button>
<span class= "message">Plugin Installed Successfully...</span>
<div id = "info">	
<table id = "plugintable" width = "95%" cellpadding = "8px" cellspacing="0">
	<tr>
		<th></th>
		<th>State</th>
		<th>Plugin Name</th>		
		<th>Navigation Support</th>
		<th>Gallery Support</th>
		<th>Author</th>
		<th>WebLink</th>
		<th>Description</th>
	</tr>	
	<?=$pluginMarkup?>
</table>
</div>