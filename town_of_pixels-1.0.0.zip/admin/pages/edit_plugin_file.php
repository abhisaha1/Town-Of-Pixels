<?php
include_once("../../paths.php");

$pluginFolder = (isset($_POST['plugin_folder']))?$_POST['plugin_folder']:"";
$pluginFile = (isset($_POST['plugin_file']))?$_POST['plugin_file']:"";
$pluginPath = str_replace("\\","/",PLUGIN_DIR).$pluginFolder.$pluginFile;

if(isset($_POST['fileselect'])) {	
	
	$file = file_get_contents($pluginPath, false);
	echo htmlspecialchars(stripslashes($file));
	
}

if(isset($_POST['savecode'])) {

	
	echo $code = html_entity_decode(stripcslashes($_POST['code']));
	//echo $code = str_replace("&#092;","{\}",$code);
	// Let's make sure the file exists and is writable first.
	if (is_writable($pluginPath)) {

		// In our example we're opening $filename in append mode.
		// The file pointer is at the bottom of the file hence
		// that's where $somecontent will go when we fwrite() it.
		if (!$handle = fopen($pluginPath, 'w')) {
			 echo "Cannot open file ($pluginPath)";
			 exit;
		}

		// Write $somecontent to our opened file.
		if (fwrite($handle, $code) === FALSE) {
			echo "Cannot write to file ($pluginPath)";
			exit;
		}

		//echo "Success, wrote ($code) to file ($pluginPath)";

		fclose($handle);

	} else {
		echo "The file $pluginPath is not writable";
	}

}
