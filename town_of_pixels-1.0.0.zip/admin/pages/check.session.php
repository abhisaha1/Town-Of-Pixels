<?php
@session_start();
$queries = new queries;
if($_SESSION['SID'] != session_id())
{	
	@header("Location:".ROOT_URL.'/admin/admin-login.php');	
}
?>