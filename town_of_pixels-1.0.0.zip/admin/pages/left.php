<?php
include_once ("../../paths.php");
include_once(ROOT_DIR."/admin/pages/check.session.php");

/* if (!$s = new session()) {
		echo "<h2>There is a problem with the session!</h2>";
		echo $s->log;
		exit();
	}
 */
?>
<style type = "text/css">
#menueditor ul{
	list-style-type: none;
}

#adminmenu ul li {	
    padding-bottom: 7px;
    padding-top: 7px;
}
#adminmenu ul {
	list-style-type: none;
	 color: #CDCDCD;
    font-family: Georgia;
}
#left_col {	
	height:100%;
	padding: 0px !important;	
}
		
ul#adminmenu li {
	cursor:pointer;
}
#version {
	background: none repeat scroll 0 0 #6FFB00;
    font-size: 12px;
    padding: 10px;
    position: absolute;
    width: 169px;
}
</style>
<script language = "javascript">
$(document).ready(function() {
 $("#adminmenu li").attr('id','');
                         $(location.hash.replace("#",".")).attr('id','selected');

});
</script>
<div id = "adminmenu">
<ul id = "adminmenu">
	<li class = "menu_editor" id="selected">Menu Editor</li>
	<li class = "plugins">Plugins</li>
	<li class = "theme_editor">Theme Editor</li>	
	<li class = "plugin_editor">Plugin Editor</li>
	<li class = "configuration">Configurations</li>	
</ul>
</div>
