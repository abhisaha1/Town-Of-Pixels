<?php
echo '<style type = "text/css">
html{background:#f9f9f9;}body{background:#fff;color:#333;font-family:"Lucida Grande",Verdana,Arial,"Bitstream Vera Sans",sans-serif;margin:2em auto;width:700px;padding:1em 2em;-moz-border-radius:11px;-khtml-border-radius:11px;-webkit-border-radius:11px;border-radius:11px;border:1px solid #dfdfdf;}a{color:#2583ad;text-decoration:none;}a:hover{color:#d54e21;}h1{border-bottom:1px solid #dadada;clear:both;color:#666;font:24px Georgia,"Times New Roman",Times,serif;margin:5px 0 0 -4px;padding:0;padding-bottom:7px;}h2{font-size:16px;}p,li,dd,dt{padding-bottom:2px;font-size:12px;line-height:18px;}code,.code{font-size:13px;}ul,ol,dl{padding:5px 5px 5px 22px;}a img{border:0;}abbr{border:0;font-variant:normal;}#logo{margin:6px 0 14px 0;border-bottom:none;text-align:center;}.step{margin:20px 0 15px;}.step,th{text-align:left;padding:0;}.submit input,.button,.button-secondary{font-family:"Lucida Grande",Verdana,Arial,"Bitstream Vera Sans",sans-serif;text-decoration:none;font-size:11px!important;line-height:16px;padding:4px;cursor:pointer;border:1px solid #bbb;color:#464646;-moz-border-radius:15px;-khtml-border-radius:15px;-webkit-border-radius:15px;border-radius:15px;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;-khtml-box-sizing:content-box;box-sizing:content-box;}.button:hover,.button-secondary:hover,.submit input:hover{color:#000;border-color:#666;}.button,.submit input,.button-secondary{background:#f2f2f2 url(../images/white-grad.png) repeat-x scroll left top;}.button:active,.submit input:active,.button-secondary:active{background:#eee url(../images/white-grad-active.png) repeat-x scroll left top;}textarea{border:1px solid #bbb;-moz-border-radius:4px;-khtml-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;}.form-table{border-collapse:collapse;margin-top:1em;width:100%;}.form-table td{margin-bottom:9px;padding:10px;border-bottom:8px solid #fff;font-size:12px;}.form-table th{font-size:13px;text-align:left;padding:16px 10px 10px 10px;border-bottom:8px solid #fff;width:130px;vertical-align:top;}.form-table tr{background:#f3f3f3;}.form-table code{line-height:18px;font-size:18px;}.form-table p{margin:4px 0 0 0;font-size:11px;}.form-table input{line-height:20px;font-size:15px;padding:2px;}.form-table th p{font-weight:normal;}#error-page{margin-top:50px;}#error-page p{font-size:12px;line-height:18px;margin:25px 0 20px;}#error-page code,.code{font-family:Consolas,Monaco,Courier,monospace;}#pass-strength-result{background-color:#eee;border-color:#ddd!important;border-style:solid;border-width:1px;margin:5px 5px 5px 1px;padding:5px;text-align:center;width:200px;}#pass-strength-result.bad{background-color:#ffb78c;border-color:#ff853c!important;}#pass-strength-result.good{background-color:#ffec8b;border-color:#fc0!important;}#pass-strength-result.short{background-color:#ffa0a0;border-color:#f04040!important;}#pass-strength-result.strong{background-color:#c3ff88;border-color:#8dff1c!important;}.message{border:1px solid #e6db55;padding:.3em .6em;margin:5px 0 15px;background-color:#ffffe0;}
.input_text{border:1px solid #ddd; padding: 4px; font-size: 10px;color:#696969;display:block;margin:5px 0 15px 0;}
label {font-size: 12px;}
.error {font-size: 12px;color:darkred;}
form{margin-top:10px;}
.center{text-align:center}
</style>';
include_once("../paths.php");
$pbdb = new db(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$totalTables = $pbdb->total_tables(DB_NAME);

$error = "";
$install = true;
if($totalTables != 11)
{
    $install = $pbdb->execute_file(ROOT_DIR . "/admin/sql.sql");
}
function pd_die($msg) {
    $msg = "<p class='center'>$msg</p>";
    die(display_header() . $msg);
    break;
}


if(isset($_POST['pwd']) && isset($_POST['confpwd']))
{
    $pwd = trim($_POST['pwd']);
    $confpwd = trim($_POST['confpwd']);
    
    if($pwd != $confpwd)$error = "Passwords doesnt match";
    else if(strlen($pwd) < 6)$error = "Passwords should be atleast 6 characters long";
    else $pwd = md5($pwd);
    if($error == "") {
        $pbdb->update_sql("UPDATE admin SET adminpwd='$pwd'");
        
    }
}
function display_header() {
//header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Town of Pixels &rsaquo; Setup Configuration File</title>
        <link rel="stylesheet" href="css/install.css" type="text/css" />

    </head>
    <body>
        <h1 id="logo"><img alt="Town of Pixels" src="" /></h1>
        <?php
        }
$checkPwd = $pbdb->select("SELECT adminpwd FROM admin WHERE adminpwd = ''");
$pwdExist = 1;

if($pbdb->row_count == 0) {
    $pwdExist = 0;
    pd_die("This page is no longer required..<p class='center'>Please navigate to <a href = '" . ROOT_URL . "/admin/admin.php'>Admin Panel</a></p><p  class='center'> Or <a href='".ROOT_URL."'>Click Here</a> to see your Pixel Town !</p>");
}
        if ($install) {
            echo display_header();
            if(@$_GET['step'] != 'done')
            echo "<p>Hurray !! All the tables were successfully created. Now its time to add some security. Please enter a password for Admin Panel.</p>";

            if((@$_GET['step'] != 'done' || $error != "")) {
            echo "<span class='error'>".$error."</span>";
            echo "<form method='POST' action = '?step=done'>
                        <label>Password:</label>
                        <input type = 'password' name = 'pwd' class = 'input_text' size='30'>

                        <label>Confirm Password:</label>
                        <input type = 'password' name = 'confpwd' class = 'input_text' size='30'>     

                       <button class = 'button'>Submit</button>  
                        </form>";
            } else {
                echo "<p>Alrighty, password has been updated successfully. <p>Your userid is <b>admin</b>. <p>Please navigate to <a href = '" . ROOT_URL . "/admin/admin.php'>Admin Panel</a></p><p> Or <a href='".ROOT_URL."'>Click Here</a> to see your Pixel Town !</p>";
            }
            
        }
        else
            echo "<p>We faced some problem in creating tables inside the database. You might open <a href = '" . ROOT_URL . "/admin/sql.sql'>SQL File</a> and install it yourself or ask your Hosting Provider to do it for you.</p>";