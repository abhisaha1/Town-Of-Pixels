<?php
class session {

	function checkSession() {
		@session_start();
		if(isset($_SESSION['LOGGED_IN']))
		{			
			return 1;
		
		}else{			
			return 0;			
		}
	}
	
	function setSession() {
		
		$this->destroySession();	
		@session_start();
		@session_regenerate_id(true);
		$_SESSION['LOGGED_IN'] = 1;	
		$_SESSION['SID'] = session_id();
		return session_id();	
		
	}
	
	function destroySession()
	{
		@session_start();
		session_unset(); 
		session_destroy();		
	}

}
?>