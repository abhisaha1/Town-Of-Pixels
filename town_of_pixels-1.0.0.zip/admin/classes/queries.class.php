<?php
if ((isset($_GET['loadpaths']) && $_GET['loadpaths'] == false) || (isset($_POST['loadpaths']) && $_POST['loadpaths'] == false))
    include_once ("../../paths.php");

class queries {

    var $pbdb;

    function __construct() {
        $this->pbdb = new db(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    }

    function getHeaderMarkup() {
        $siteConfig = $this->getSiteDetails();
        return "<div id = 'header_info'>
					<h2 id = 'header_title'>" . $siteConfig['site_name'] . "</h2>
					<span id = 'header_tag'>" . $siteConfig['site_tag'] . "</span>
				</div>";
    }

    function applyHeaderCSS() {
        return "<style type = 'text/css'>
					#header_title {
						margin-bottom: 3px;
						margin-top: 0px;

					}
					#header_info {	
						border: 0px;
						position:absolute;
						padding:0px;
						color: inherit;
						text-align: center;
					}
					#header_tag {
						font-size:10px;
					}
				</style>";
    }

    function applyLeftColHeaderCSS() {
        return "<style type = 'text/css'>
					#header_title {
						margin-bottom: 3px;
						margin-top: 0px;

					}
					#header_info {
						border-bottom: 1px dotted #393939;
						color: #FFF;
						margin-left: 5px;
						padding: 30px 0;
						position: relative;
						text-align: center;
					}
					#header_tag {
						font-size:10px;
					}
				</style>";
    }

    function getNavigationData() {
        $data = array();
        $title = $this->pbdb->select("SELECT * FROM categories ORDER BY cat_position ASC");
        $count = 0;
        while ($catrow = $this->pbdb->get_row($title)) {
            $subtitle = $this->pbdb->select("SELECT * FROM sub_categories WHERE categoryid = '" . $catrow['id'] . "' AND state = 'de-activate' ORDER BY sub_cat_position ASC");
            if ($this->pbdb->row_count != 0) {
                while ($row = $this->pbdb->get_row($subtitle)) {
                    $count++;
                    $data[$catrow['cat_name']][] = array('cat_id' => $catrow['id'], 'sub_cat_name' => $row['sub_name'], 'sub_cat_id' => $row['sub_cat_id'], 'state' => $row['state']);
                }
            }
        }
        return $data;
    }

    function getAllNavigationData() {
        $data = array();
        $title = $this->pbdb->select("SELECT * FROM categories ORDER BY cat_position ASC");
        $count = 0;
        while ($catrow = $this->pbdb->get_row($title)) {
            $subtitle = $this->pbdb->select("SELECT * FROM sub_categories WHERE categoryid = '" . $catrow['id'] . "' ORDER BY sub_cat_position ASC");
            if ($this->pbdb->row_count != 0) {
                while ($row = $this->pbdb->get_row($subtitle)) {
                    $count++;
                    $data[$catrow['cat_name']][] = array('cat_id' => $catrow['id'], 'sub_cat_name' => $row['sub_name'], 'sub_cat_id' => $row['sub_cat_id'], 'state' => $row['state']);
                }
            } else {
                $data[$catrow['cat_name']][] = array('cat_id' => $catrow['id'], 'sub_cat_name' => '', 'sub_cat_id' => '', 'state' => '');
            }
        }

        return $data;
    }

    function getNavigationMarkup() {
        $navArr = $this->getNavigationData();

        $navigationMarkup = '<div id = "navigationMenu">';

        foreach ($navArr as $key => $value) {
            $count = 1;
            $navigationMarkup .= "<ul class = 'test-list'>";

            foreach ($value as $id => $subsection) {
                $catid = $subsection['cat_id'];
                $subcatid = $subsection['sub_cat_id'];

                $imagecount = $this->getImageCount($catid, $subcatid);

                $navigationMarkup .= ($count == 1) ? "<li class = 'section-title' id = 'cat_$catid'>" . $key . "</li>" : "";
                $navigationMarkup .= "<li class = 'sub-section' id = 'subcat_$subcatid'><a href='http://" . $_SERVER['HTTP_HOST'] . ROOT_URL . "/#!catid=$catid&subcatid=$subcatid' class='handle'>" . $subsection['sub_cat_name'] . "</a></li>"; //<span class = 'imagecount'>$imagecount</span>			
                $count++;
            }
            $navigationMarkup .= "</ul>";
        }
        return $navigationMarkup .= "</div>";
    }

    /* function prepareToUpload($catid,$subcatid)
      {
      $q = $this->pbdb->select("SELECT * FROM categories,sub_categories WHERE categories.id = ".$catid." && sub_categories.sub_cat_id ='".$subcatid."'");
      return $this->pbdb->get_row($q);
      } */

    function getCategories() {
        $data = array();
        $category = $this->pbdb->select("SELECT DISTINCT id,cat_name, cat_position FROM categories ORDER BY cat_position ASC");

        while ($row = $this->pbdb->get_row($category)) {
            $data[$row['cat_position']][$row['id']] = $row['cat_name'];
        }
        return $data;
    }

    function getImageCount($catid, $subcatid) {
        $sql = $this->pbdb->select("SELECT id FROM uploads WHERE catid='$catid' AND subcatid='$subcatid'");
        return $this->pbdb->row_count;
    }

    function getDescription($imageId) {
        $data = array();
        $desc = $this->pbdb->select("SELECT caption,tags,title FROM uploads WHERE id = '$imageId'");

        while ($row = $this->pbdb->get_row($desc)) {
            $data = $row;
        }
        return json_encode($data);
    }

    function getMaxPosition() {
        $sql = $this->pbdb->select("SELECT max(cat_position) FROM categories");
        $row = $this->pbdb->get_row($sql);
        return $row['max(cat_position)'] + 1;
    }

    function insertCategory($cat_name) {
        $sql = $this->pbdb->insert_sql("INSERT INTO categories (cat_name, cat_position) VALUES ('$cat_name','" . $this->getMaxPosition() . "')");
        if ($sql)
            return $sql;
    }

    function insertSubCategory($sub_cat_name, $cat_id) {
        $sql = $this->pbdb->insert_sql("INSERT INTO sub_categories (sub_name,sub_cat_position,categoryid) VALUES ('$sub_cat_name','" . $this->getMaxPosition() . "', '$cat_id')");
        if ($sql)
            return $sql;
    }

    function updateSubCatSec($position, $item) {
        $sql = $this->pbdb->update_sql("UPDATE `sub_categories` SET `sub_cat_position` = $position WHERE `sub_cat_id` = $item");
        if ($sql)
            return $sql;
    }

    function updateCatSec($position, $item) {
        $sql = $this->pbdb->update_sql("UPDATE `categories` SET `cat_position` = $position WHERE `id` = $item");
        if ($sql)
            return $sql;
    }

    function insertImageInfo($data) {
        $sql = $this->pbdb->insert_array("uploads", $data);
        if ($sql)
            return $sql;
    }

    function displayThumbnails($catid, $subcatid) {
        $data = array();
        $getThumbs = $this->pbdb->select("SELECT * FROM uploads WHERE catid = '$catid' && subcatid ='$subcatid' ORDER BY position");

        while ($row = $this->pbdb->get_row($getThumbs)) {
            //$data[$row['image_name']] = $row['image_desc']; 	
            $row['thumbpath'] = htmlentities(ROOT_URL . $row['thumbpath'], ENT_NOQUOTES);
            $row['imagepath'] = htmlentities(ROOT_URL . $row['imagepath'], ENT_NOQUOTES);
            $data[] = $row;
        }
        return $data;
    }

    function displayImages($catid, $subcatid) {
        $data = array();
        $getImages = $this->pbdb->select("SELECT * FROM uploads WHERE catid = '$catid' && subcatid ='$subcatid' ORDER BY position");

        while ($row = $this->pbdb->get_row($getImages)) {
            $row['thumbpath'] = htmlentities(ROOT_URL . $row['thumbpath'], ENT_NOQUOTES);
            $row['imagepath'] = htmlentities(ROOT_URL . $row['imagepath'], ENT_NOQUOTES);
            $data[] = $row;
        }
        return $data;
    }

    function deleteSubCategory($subcatid, $col = "subcatid") {
        $error = array();

        $sql2 = $this->pbdb->select("SELECT * FROM uploads WHERE $col = '$subcatid'");
        while ($row = $this->pbdb->get_row($sql2)) {

            $original_path = str_replace("uploads/", "uploads/originals/", $row['imagepath']);

            if (!@unlink($_SERVER['DOCUMENT_ROOT'] . ROOT_URL . $row['thumbpath']))
                $error[] = "Could not delete image from path " . ROOT_URL . $row['thumbpath'];
            if (!@unlink($_SERVER['DOCUMENT_ROOT'] . ROOT_URL . $row['imagepath']))
                $error[] = "Could not delete image from path " . ROOT_URL . $row['imagepath'];
            if (!@unlink($_SERVER['DOCUMENT_ROOT'] . ROOT_URL . $original_path))
                $error[] = "Could not delete image from path " . ROOT_URL . $original_path;
        }
        $sql2 = $this->pbdb->delete_sql("DELETE FROM uploads WHERE $col = '$subcatid'");
        $sql3 = $this->pbdb->delete_sql("DELETE FROM sub_categories WHERE sub_cat_id = '$subcatid'");

        //I AM NOT GOING TO DISPLAY THIS ERROR. NO. I AM PISSED. HAD A FIGHT WITH MY GIRL.
    }

    function deleteCategory_and_children($catid) {
        $sql = $this->pbdb->delete_sql("DELETE FROM categories WHERE id = '$catid'");
        $this->deleteSubCategory($catid, "catid");
        if ($sql)
            return $sql;
    }

    function updateImageInfo($imageId, $data) {
        $sql = $this->pbdb->update_array("uploads", $data, "id='$imageId'");
        if ($sql)
            return true;
    }

    function getMaxSize() {
        $data = array();
        $sql = $this->pbdb->select("SELECT * FROM configurations");

        while ($row = $this->pbdb->get_row($sql)) {
            $data['max_height'] = $row['maxheight'];
            $data['max_width'] = $row['maxwidth'];
        }
        return $data;
    }

    function getPlugin() {
        $data = array();
        $sql = $this->pbdb->select("SELECT * FROM plugins WHERE status = 'Active' && gallery = 'true'");
        $row = $this->pbdb->get_row($sql);
        $data['plugin_tech_name']['gallery'] = $row['plugin_tech_name'];

        $sql = $this->pbdb->select("SELECT * FROM plugins WHERE status = 'Active' && navigation = 'true'");
        $row = $this->pbdb->get_row($sql);
        $data['plugin_tech_name']['navigation'] = $row['plugin_tech_name'];

        return $data;
    }

    function pluginActivation($pluginTechName) {
        $data = array();
        $sql1 = $this->pbdb->select("SELECT * FROM plugins WHERE plugin_tech_name = '$pluginTechName'");
        $row = $this->pbdb->get_row($sql1);
        $current_nav_status = $row['navigation'];
        $current_gallery_status = $row['gallery'];
        echo $status = ($row['status'] == "Active") ? "Inactive" : "Active";
        echo $pluginTechName;
        $updateActive = $this->pbdb->update_sql("UPDATE plugins SET status = '$status' WHERE plugin_tech_name = '$pluginTechName'");

        $sql2 = $this->pbdb->select("SELECT * FROM plugins WHERE plugin_tech_name != '$pluginTechName'");
        while ($row = $this->pbdb->get_row($sql2)) {
            $nav_status = $row['navigation'];
            $gallery_status = $row['gallery'];
            $id = $row['id']; //We can use $row['plugin_tech_name'] as well. Both are Primary Key
            //If selected plugin has Nav feature, activate that and deactivate all other WHICH HAS NAV FEATURE.
            if ($nav_status == "true" && $current_nav_status == "true") {
                $updateInactive = $this->pbdb->update_sql("UPDATE plugins SET status = 'Inactive' WHERE id = '$id'");
            }

            //If selected plugin has Gallery feature, activate that and deactivate all other WHICH HAS GALLERY FEATURE.
            if ($gallery_status == "true" && $current_gallery_status == "true") {
                $updateInactive = $this->pbdb->update_sql("UPDATE plugins SET status = 'Inactive' WHERE id = '$id'");
            }
        }
    }

    function insertPluginInfo($pluginConfigData) {
        $sql = $this->pbdb->insert_array("plugins", $pluginConfigData);
        if ($sql)
            return $sql;
    }

    function displayAllPlugins() {
        $data = array();
        $sql = $this->pbdb->select("SELECT * FROM plugins");

        while ($row = $this->pbdb->get_row($sql)) {
            $data[] = $row;
        }
        return $data;
    }

    function getImageAspectSize($imageId) {
        $data = array();
        $size = $this->getMaxSize();
        $imagepaths = $this->getImagePaths($imageId);
        list($width, $height, $type, $attr) = getimagesize(ROOT_DIR . $imagepaths['imagepath']);
        $max_width = $size['max_width'];
        $max_height = $size['max_height'];

        $ratioh = $max_height / $height;
        $ratiow = $max_width / $width;
        $ratio = min($ratioh, $ratiow);
        // New dimensions
        $data['originalwidth'] = $width;
        $data['originalheight'] = $height;
        $data['newwidth'] = intval($ratio * $width);
        $data['newheight'] = intval($ratio * $height);

        return $data;
    }

    function getImagePaths($imageId) {
        $data = array();
        $sql = $this->pbdb->select("SELECT * FROM uploads WHERE id = '$imageId'");
        $row = $this->pbdb->get_row($sql);
        return $row;
    }

    function insertSiteDetails($data) {

        $sql = $this->pbdb->update_array("configurations", $data, "");


        return $sql;
    }

    function renameSubcat($subcatid, $subcatname) {

        $sql = $this->pbdb->update_sql("UPDATE `sub_categories` SET `sub_name` = '$subcatname' WHERE `sub_cat_id` = '$subcatid'");
        if ($sql)
            return $sql;
    }

    function renameCat($catid, $catname) {

        $sql = $this->pbdb->update_sql("UPDATE `categories` SET `cat_name` = '$catname' WHERE `id` = '$catid'");
        if ($sql)
            return $sql;
    }

    function getSiteDetails() {

        $sql = $this->pbdb->select("SELECT * FROM configurations LIMIT 1");
        return $this->pbdb->get_row($sql);
    }

    function changeState($data) {
        $subcatid = $data['sub_cat_id'];
        $data['state'] = ($data['state'] == "activate") ? "de-activate" : "activate";
        $sql = $this->pbdb->update_array("sub_categories", $data, "sub_cat_id=$subcatid");
        if ($sql)
            return $data['state'];
        else
            return false;
    }

    function applyTheme($data) {
        $sql = $this->pbdb->update_array("theme_editor", $data, "");
        if ($sql)
            
        return $sql;
    }

    function getTheme() {
        $sql = $this->pbdb->select("SELECT * FROM theme_editor LIMIT 1");
        $row = $this->pbdb->get_row($sql);

        return $row;
    }

    function fetchComments($imageid) {
        $data = "";
        $sql = $this->pbdb->select("SELECT * FROM comments WHERE imageid = '$imageid'");

        while ($row = $this->pbdb->get_row($sql)) {

            $link_open = '<a target = "_blank" href="' . $row['url'] . '">';
            $link_close = '</a>';
            $added_at = "<span class = 'time'>Added " . $this->time_since($row['dt']) . "</span>";
            $data .=
                    '<div class="comment">				
					<div class="name">' . $link_open . $row['name'] . $link_close . $added_at . '</div>					
					<p>' . $row['body'] . '</p>
				</div>';
        }
        return $data;
    }
	
	function totalComments($imageid) {
		$sql = $this->pbdb->select("SELECT * FROM comments WHERE imageid = '$imageid'");
		return mysql_num_rows($sql);
	}
	function time_since($since) {
		$chunks = array(
			array(60 * 60 * 24 * 365 , 'year'),
			array(60 * 60 * 24 * 30 , 'month'),
			array(60 * 60 * 24 * 7, 'week'),
			array(60 * 60 * 24 , 'day'),
			array(60 * 60 , 'hour'),
			array(60 , 'minute'),
			array(1 , 'second')
		);

		for ($i = 0, $j = count($chunks); $i < $j; $i++) {
			$seconds = $chunks[$i][0];
			$name = $chunks[$i][1];
			if (($count = floor($since / $seconds)) != 0) {
				break;
			}
		}

		$print = ($count == 1) ? '1 '.$name : "$count {$name}s";
		return $print;
	}

    function insertComment($data) {		
        $sql = $this->pbdb->insert_array("comments", $data);
        $sitedetails = $this->getSiteDetails();
        if ($sql) {

            if (strpos($sitedetails['comment_notify'], "@") !== false) {
                $to = $sitedetails['comment_notify'];
                $subject = 'New Comment';
                $message = $data['body'];
                $headers = 'From: no-reply@townofpixels.com' . "\r\n" .
                        'Reply-To: ' . $sitedetails['comment_notify'] . "\r\n" .
                        'X-Mailer: PHP/' . phpversion();
                @mail($to, $subject, $message, $headers);
            }
            $link_open = '<a target = "_blank" href="' . $data['url'] . '">';
            $link_close = '</a>';
            $added_at = "<span class = 'time'>Added " . $this->time_since(date('r', time())) . "</span>";
            ;
            return '<div class="comment">				
						<div class="name">' . $link_open . $data['name'] . $link_close . $added_at . '</div>					
						<p>' . $data['body'] . '</p>
					</div>';
        }
    }

    function currentFolder($catid, $subcatid) {
        $sql = $this->pbdb->select("SELECT * FROM categories, sub_categories WHERE categories.id='$catid' AND sub_categories.sub_cat_id = '$subcatid'");
        $row = $this->pbdb->get_row($sql);
        return strtoupper($row['cat_name']) . ' >> ' . strtoupper($row['sub_name']);
    }

    function getExifOf($imageid) {
        $sql = $this->pbdb->select("SELECT * FROM uploads WHERE id = '$imageid'");
        $row = $this->pbdb->get_row($sql);
        return $row['exif'];
    }

    function saveCoverpage($data, $catid, $subcatid) {

        $data['coverpage'] = preg_replace('/[\r\n]+/', null, htmlspecialchars(addslashes($data['coverpage'])));
        $data['coverpagestatus'] = ($data['coverpagestatus'] == "active") ? 1 : 0;
        $sql = $this->pbdb->update_array("sub_categories", $data, "sub_cat_id = '" . $subcatid . "'");
        echo $this->pbdb->print_last_error();
        if ($sql)
            return $sql;
    }

    function getCoverpageData($subcatid) {
        $data = array();
        $q = $this->pbdb->select("SELECT * FROM sub_categories WHERE sub_cat_id ='$subcatid'");
        $row = $this->pbdb->get_row($q);
        $data['coverpage'] = htmlspecialchars_decode(stripslashes($row['coverpage']));
        $data['coverpagewidth'] = $row['coverpagewidth'];
        $data['coverpagestatus'] = ($row['coverpagestatus'] == 0) ? "inactive" : "active";
        return $data;
    }

    function getPackageInfo() {
        $q = $this->pbdb->select("SELECT * FROM package_data");
        $row = $this->pbdb->get_row($q);
        return $row;
    }

    function deleteImage($data) {
        $message = array();
        foreach ($data as $key => $value) {
            $thumbinfo = explode("!@-", $value);

            $id = $thumbinfo[0];
            $thumbpath = $thumbinfo[1];
            if (!@$this->pbdb->select("DELETE FROM uploads WHERE id ='$id'")) {
                $message['success'] = 0;
                $message['mysql_error'] = "There is an error in the delete query.";
            } else {
                unlink(ROOT_DIR . '/resources/' . $thumbpath);
                unlink(ROOT_DIR . '/resources/' . str_replace("thumb_", "", $thumbpath));
                unlink(ROOT_DIR . '/resources/uploads/' . str_replace("uploads/", "originals/", str_replace("thumb_", "", $thumbpath)));
                $message['success'] = 1;
            }
        }
        echo json_encode($message);
    }

    function adminLogin($data) {

        $q = $this->pbdb->select("SELECT * FROM admin WHERE adminid='" . $data['adminid'] . "' AND adminpwd='" . md5($data['adminpwd']) . "'");
        if ($this->pbdb->row_count == 0) {
            return json_encode(array("success" => 0));
        } else {
            $session = new session;
            $sid = $session->setSession();

            $q = $this->pbdb->update_sql("UPDATE admin SET sid = '$sid'");
            if ($q)
                return json_encode(array("success" => 1));
        }
    }

    function deleteSession() {
        $q = $this->pbdb->update_sql("UPDATE admin SET sid = ''");
        if ($q)
            return true;
    }

    function getSid() {
        $q = $this->pbdb->select("SELECT sid FROM admin LIMIT 1");
        $row = $this->pbdb->get_row($q);
        return $row['sid'];
    }

    function updatePackage($version) {
        $q = $this->pbdb->select("UPDATE package_data SET version = '$version'");
        if ($q)
            return true;
    }

    function getDefaultPage() {
        $q1 = $this->pbdb->select("SELECT * FROM sub_categories WHERE defaulter = '1'");

        if ($this->pbdb->row_count > 0) {
            $row = $this->pbdb->get_row($q1);
            return array('catid' => $row['categoryid'], 'subcatid' => $row['sub_cat_id']);
        } else {
            $q2 = $this->pbdb->select("SELECT DISTINCT * FROM categories,sub_categories ORDER BY sub_categories.sub_cat_position ASC LIMIT 1");
            $row = $this->pbdb->get_row($q2);
            return array('catid' => $row['id'], 'subcatid' => $row['sub_cat_id']);
        }
    }

    function getDefaulter($subcatid) { //used in menu editor to set the default page
        $q = $this->pbdb->select("SELECT defaulter FROM sub_categories WHERE sub_cat_id = '$subcatid'");
        $row = $this->pbdb->get_row($q);
        return ($row['defaulter']);
    }

    function updateDefaultPage($subcatid) {
        $q1 = $this->pbdb->update_sql("UPDATE sub_categories SET defaulter = 0");
        $q2 = $this->pbdb->update_sql("UPDATE sub_categories SET defaulter = 1 WHERE sub_cat_id = '$subcatid'");
        if ($q2)
            return $q2;
    }

    function displayGalleryPluginsOnly($subcatid) {
        $q = $this->pbdb->select("SELECT linked_plugin FROM sub_categories WHERE sub_cat_id = '$subcatid'");
        $row = $this->pbdb->get_row($q);
        $linkedPlugin = $row['linked_plugin'];

        $data = "<input type='radio' id = 'none' name='g_plugin_rb' /><label for='none'>None</label>";
        $q = $this->pbdb->select("SELECT * FROM plugins WHERE gallery = 'true'");
        while ($row = $this->pbdb->get_row($q)) {
            if ($row['plugin_tech_name'] == $linkedPlugin)
                $data .= "<input checked='true' type='radio' id='" . $row['plugin_tech_name'] . "' name='g_plugin_rb' /><label for='" . $row['plugin_tech_name'] . "'>" . $row['plugin_name'] . "</label>";
            else
                $data .= "<input type='radio' id='" . $row['plugin_tech_name'] . "' name='g_plugin_rb' /><label for='" . $row['plugin_tech_name'] . "'>" . $row['plugin_name'] . "</label>";
        }

        return $data;
    }

    function updateSubcatPlugin($data) {
        $linked_plugin = ($data['plugin_tech_name'] != "none") ? $data['plugin_tech_name'] : "";
        $subcatid = $data['subcatid'];
        $q = $this->pbdb->update_sql("UPDATE sub_categories SET linked_plugin = '$linked_plugin' WHERE sub_cat_id='$subcatid'");
        if ($q)
            return true;
    }

    function getSubCatLinkedPlugin() {
        $data = array();
        $q = $this->pbdb->select("SELECT sub_cat_id,linked_plugin FROM sub_categories WHERE state = 'de-activate'");
        $getPlugin = $this->getPlugin();
        while ($row = $this->pbdb->get_row($q)) {
            $data[$row['sub_cat_id']] = ($row['linked_plugin'] == "") ? $getPlugin['plugin_tech_name']['gallery'] : $row['linked_plugin'];
        }
        return json_encode($data);
    }

    function deletePlugin($pluginData) {
        $pluginId = $_POST['pluginId'];
        $plugin_tech_name = $_POST['plugin_tech_name'];
        $q1 = $this->pbdb->delete_sql("DELETE FROM plugins WHERE id ='$pluginId'");
        $q2 = $this->pbdb->update_sql("UPDATE sub_categories SET linked_plugin = '' WHERE linked_plugin ='$plugin_tech_name'");
        $this->recursiveDelete(ROOT_DIR . "/resources/plugins/$plugin_tech_name");
        if ($q1 && $q2)
            return json_encode(array("success" => 1));
    }

    function recursiveDelete($str) {
        if (is_file($str)) {
            return @unlink($str);
        } elseif (is_dir($str)) {
            $scan = glob(rtrim($str, '/') . '/*');
            foreach ($scan as $index => $path) {
                $this->recursiveDelete($path);
            }
            return @rmdir($str);
        }
    }

    function updateImagePosition($sql, $catid, $subcatid) {
        $q1 = $this->pbdb->update_sql($sql, "catid=$catid && subcatid=$subcatid");
    }

    function getRandomImage() {

        $q = $this->pbdb->select("SELECT * FROM uploads ORDER BY RAND() LIMIT 1");
        $row = $this->pbdb->get_row($q);
        $row['thumbpath'] = htmlentities(ROOT_URL . $row['thumbpath'], ENT_NOQUOTES);
        $row['imagepath'] = htmlentities(ROOT_URL . $row['imagepath'], ENT_NOQUOTES);
        return $row;
    }

    function updatePassword($pwd) {
        $q = $this->pbdb->update_sql("UPDATE admin SET adminpwd = '$pwd'");
    }

    function validateCaptcha($captchacode) {
        if (@strtolower($captchacode) == strtolower($_SESSION['random_number'])) {
            return true;
        } else {
            return false;
        }
    }

}

/**
 * ADMIN REQUESTS. VALIDATES SESSION TO AVOID DIRECT ACCESS
 */
 
if (isset($_POST['savecategory']) && $_POST['savecategory'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    echo $queries->insertCategory($_POST['savecategory']);
}

if (isset($_POST['savesubcategory']) && $_POST['savesubcategory'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    echo $queries->insertSubCategory($_POST['savesubcategory'], $_POST['catid']);
}

if (isset($_POST['deletesubcat']) && $_POST['deletesubcat'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    echo $queries->deleteSubCategory($_POST['subcatid']);
}

if (isset($_POST['deletecat']) && $_POST['deletecat'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    echo $queries->deleteCategory_and_children($_POST['catid']);
}

if (isset($_POST['update']) && $_POST['update'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    $data = array();
    $data['title'] = $_POST['title'];
    $data['caption'] = $_POST['caption'];
    $data['tags'] = $_POST['tags'];
    echo $queries->updateImageInfo($_POST['selectedImageId'], $data);
}
if (isset($_POST['insertSiteDetails']) && $_POST['insertSiteDetails'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    unset($_POST['insertSiteDetails']);
    echo $queries->insertSiteDetails($_POST);
}

if (isset($_POST['changeState']) && $_POST['changeState'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    unset($_POST['changeState']);
    echo $queries->changeState($_POST);
}

if (isset($_POST['pluginActivation']) && $_POST['pluginActivation'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    echo $queries->pluginActivation($_POST['current_plugin']);
}
if (isset($_POST['renamesubcat']) && $_POST['renamesubcat'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    echo $queries->renameSubcat($_POST['subcatid'], $_POST['subcatname']);
}
if (isset($_POST['renamecat']) && $_POST['renamecat'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    echo $queries->renameCat($_POST['catid'], $_POST['catname']);
}
if (isset($_POST['applyTheme']) && $_POST['applyTheme'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    unset($_POST['applyTheme']);
    echo $queries->applyTheme($_POST);
}
if (isset($_POST['cat_pos']) && $_POST['cat_pos'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    foreach ($_POST['listItem'] as $position => $item) :
        $sql[] = "UPDATE `navigation` SET `position` = $position WHERE `id` = $item";
        $pbdb = new queries();
        echo $navArr = $pbdb->updateCatSec($position, $item);
    endforeach;
}
if (isset($_POST['sub_cat_pos']) && $_POST['sub_cat_pos'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    foreach ($_POST['listItem'] as $position => $item) :        
        $pbdb = new queries();
        echo $navArr = $pbdb->updateSubCatSec($position, $item);
    endforeach;
}
if (isset($_GET['coverpage']) && $_GET['coverpage'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    echo $queries->saveCoverpage($_POST, $_GET['catid'], $_GET['subcatid']);
}
if (isset($_POST['deleteImage']) && $_POST['deleteImage'] != "") {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    unset($_POST['deleteImage']);
    echo $queries->deleteImage($_POST['images']);
}

if (isset($_POST['update_cat_plugin']) && $_POST['update_cat_plugin'] == true) {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    unset($_POST['update_cat_plugin']);
    echo $queries->updateSubcatPlugin($_POST);
}
if (isset($_POST['defaulter']) && $_POST['defaulter'] == true) {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    echo $queries->updateDefaultPage($_POST['sub_cat_id']);
}
if (isset($_POST['deletePlugin']) && $_POST['deletePlugin'] == true) {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    echo $queries->deletePlugin($_POST['pluginId']);
}
if (isset($_POST['image_pos']) && $_POST['image_pos'] == true) {
    include_once ("../../paths.php");
	sessionCheck();
    $queries = new queries();
    unset($_POST['image_pos']);
    $subcatid = $_POST['subcatid'];
    $catid = $_POST['catid'];
    unset($_POST['subcatid']);
    unset($_POST['catid']);
    print_r($_POST);
    foreach ($_POST['imagepos'] as $position => $item) :
        $sql = "UPDATE `uploads` SET `position` = $position WHERE `id` = $item";
        $navArr = $queries->updateImagePosition($sql, $catid, $subcatid);
    endforeach;
}
/**
 * END USER REQUESTS.
 */
if (isset($_POST['getDescription']) && $_POST['getDescription'] != "") {
    include_once ("../../paths.php");
    $queries = new queries();
    echo $queries->getDescription($_POST['selectedImageId']);
}
if (isset($_POST['insertComment']) && $_POST['insertComment'] != "") {
    include_once ("../../paths.php");    
    $queries = new queries();
    unset($_POST['insertComment']);
    @session_start();
    $captcha = $queries->validateCaptcha($_POST['code']);
    if ($captcha) {
        unset($_POST['code']);
        echo $queries->insertComment($_POST);
    } else {
        echo "Incorrect Captcha Code";
    }
}
if (isset($_POST['login']) && $_POST['login'] == true) {
    include_once ("../../paths.php");
    $queries = new queries();
    unset($_POST['login']);
    echo $queries->adminLogin($_POST);
}
if (isset($_GET['image']) && $_GET['image'] != "") {
    include_once ("../../paths.php");	
    $queries = new queries();
    echo $queries->getDescription($_GET['image']);
}
/**
 * FUNCTION TO VALIDATE SESSION. REALLY SMALL :)
 */
function sessionCheck() {
	@session_start();
	if(@$_SESSION['SID'] != @session_id()) {
		die("Cannot Execute. Bad Attempt.");
	}
}
?>
