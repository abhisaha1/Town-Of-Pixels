<?php
error_reporting(1);
class upgradeCheck {
	
	var $upgrade_required = false;
	var $upgrade_message;
	var $info_message_display;
	var $info_message;
	
	function __construct()
	{
		$queries = new queries();
		$packageInfo = $queries->getPackageInfo();
		$installedVersion = $packageInfo['version'];
		$upgradeCheck = $this->checkUpgrade($installedVersion);
		
		if($upgradeCheck){
			$this->upgrade_required = true;		
		}else return false;
	}
	
	function getNewPackage()
	{
		$url  = 'http://townofpixels.com/upgrade/upgrade.zip';
		$upgradeFile = ROOT_DIR.'/upgrade.zip';	 
		$fp = fopen($upgradeFile, 'w');
	 
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_FILE, $fp);
	 
		$data = curl_exec($ch);
	 
		curl_close($ch);
		fclose($fp);
		
		if(file_exists($upgradeFile)) {
			$t = $this->unzipPackage($upgradeFile);
			if($t) return true;
		}
	}
	
	function unzipPackage($upgradeFile)
	{
		
		$zip=zip_open($upgradeFile);
		if(!$zip) {return("Unable to proccess file '{$upgradeFile}'");}
		
		$error='';
	
		while($zip_entry=zip_read($zip)) {
		   
		   $zdir=dirname(zip_entry_name($zip_entry));
		   $zname=zip_entry_name($zip_entry);
		   

		   if(!zip_entry_open($zip,$zip_entry,"r")) {$error.="Unable to proccess file '{$zname}'";continue;}
			
		   $last_char = substr($zname, -1);
			
		   if($last_char == "/" && !is_dir(ROOT_DIR.'/'.$zname)) $this->mkdirr(ROOT_DIR.'/'.$zname,0777);		  

		   $zip_fs=zip_entry_filesize($zip_entry);
		   if(empty($zip_fs)) continue;

		   $zz=zip_entry_read($zip_entry,$zip_fs);
		   $z=fopen(ROOT_DIR.'/'.$zname,"w");
		   fwrite($z,$zz);
		   fclose($z);
		   zip_entry_close($zip_entry);

		}
		zip_close($zip);

		return true;
	}
	
	function mkdirr($pn,$mode=null) {
	  if(is_dir($pn)||empty($pn)) return true;
	  $pn=str_replace(array('/', ''),DIRECTORY_SEPARATOR,$pn);

	  if(is_file($pn)) {trigger_error('mkdirr() File exists', E_USER_WARNING);return false;}

	  $next_pathname=substr($pn,0,strrpos($pn,DIRECTORY_SEPARATOR));
	  if($this->mkdirr($next_pathname,$mode)) {if(!file_exists($pn)) {return mkdir($pn,$mode);} }
	  return false;
	  
	} 
	
	function checkUpgrade($installedVersion)
	{								
		if($this->latestUpdate())
		return ($this->latestUpdate() != $installedVersion)?true:false;	
		else
		return false;

	}
	
	function latestUpdate()
	{
		if($this->ifServerActive("http://townofpixels.com/upgrade/version.xml"))
		{
			$xml = @simplexml_load_file("http://townofpixels.com/upgrade/version.xml");// or die("Coudnt check for updates."); 
			
			if(!$xml) return false;		
			$current_version = $xml->config->version;
			
			$this->upgrade_message = $xml->config->upgrade_message;
			$this->info_message_display = $xml->config->info_message_display;
			$this->info_message = $xml->config->info_message;
			
			return $current_version;
		}else
		{			
			return false;
		}
	}
	
	function ifServerActive($link)
	{		
		ini_set("default_socket_timeout","02");
        set_time_limit(15);		
		//$fp = fopen($link, "r"); 
		//@fclose($fp); 
		$fp = fsockopen($link); 
		if (!$fp){			
			return true; 
		}else {
			@fclose($fp); 
			return true;  
		}
	}
}

if(isset($_POST['startupgrade']))
{
	include_once("../../paths.php");
	$pbdb = new queries();
	
	$packInfo = $pbdb->getPackageInfo();
	$currentVersion = $packInfo['version'];
	
	$upgradeCheck = new upgradeCheck();
	if($upgradeCheck->upgrade_required)
	{		
		
		if($upgradeCheck->getNewPackage())
		{			
			if(file_exists(ROOT_DIR . '/upgrade.sql')){
				
				$sql = $queries->execute_file(ROOT_DIR . '/upgrade.sql');
				if($sql) unlink(ROOT_DIR . '/upgrade.sql');
			}
			echo "<span style = 'color: #696969'>Upgrade Successfully Completed<p>Total Time: 5000ms.</span>";//$upgradeCheck->getNewPackage();
			unlink(ROOT_DIR.'/upgrade.zip'); //DELETE THE ZIP FILE
			$pbdb->updatePackage($upgradeCheck->latestUpdate());
		}
	}
}
?>