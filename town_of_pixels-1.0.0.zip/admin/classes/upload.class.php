<?php
include_once("../../paths.php");
error_reporting(0);

ini_set("post_max_size", "20M"); 
ini_set("upload_max_filesize", "20M");


class qqFileUploader {

    private $allowedExtensions = array();
    private $sizeLimit = 10485760;
    private $file;
	private $thumbPrefix;
	private $exif_tags_array = array();
	private $queries;
	private $catid;
	private $subcatid;
	private $watermark;
	
	
    function __construct(array $allowedExtensions = array(), $sizeLimit = 10485760,$thumbPrefix="thumbs",$exif_tags_array,$siteDetails){        
        
		$allowedExtensions = array_map("strtolower", $allowedExtensions);            
        $this->allowedExtensions = $allowedExtensions;        
        $this->sizeLimit = $sizeLimit;
        $this->thumbPrefix = $thumbPrefix;
		$this->exif_tags_array = $exif_tags_array;
        $this->checkServerSettings();       
		$this->queries = new queries();
		$this->watermark = trim($siteDetails['watermark']);
		$this->catid = $_GET['catid'];
		$this->subcatid = $_GET['subcatid'];
		
		
        if (isset($_GET['qqfile'])) {
            $this->file = new qqUploadedFileXhr($siteDetails);
        } elseif (isset($_FILES['qqfile'])) {
            $this->file = new qqUploadedFileForm($siteDetails);
        } else {
            $this->file = false; 
        }
    }
    
    private function checkServerSettings(){        
        $postSize = $this->toBytes(ini_get('post_max_size'));
        $uploadSize = $this->toBytes(ini_get('upload_max_filesize'));        
        
        if ($postSize < $this->sizeLimit || $uploadSize < $this->sizeLimit){
            $size = max(1, $this->sizeLimit / 1024 / 1024) . 'M';             
            //die("{'error':'increase post_max_size and upload_max_filesize to $size'}");    
        }        
    }
    
    private function toBytes($str){
        $val = trim($str);
        $last = strtolower($str[strlen($str)-1]);
        switch($last) {
            case 'g': $val *= 1024;
            case 'm': $val *= 1024;
            case 'k': $val *= 1024;        
        }
        return $val;
    }
    
    /**
     * Returns array('success'=>true) or array('error'=>'error message')
     */
    function handleUpload($uploadDirectory, $replaceOldFile = TRUE, $uploadUrl, $uploadOriginalDirectory){
	
		
		
		
		$imageProperties = array();
		
        if (!is_writable($uploadDirectory)){
            return array('error' => "Server error. Upload directory isn't writable.");
        }
        if ($this->file->saveOriginals && !is_writable($uploadOriginalDirectory)){
            return array('error' => "Server error. Original Upload directory isn't writable.");
        }
        if (!$this->file){
            return array('error' => 'No files were uploaded.');
        }
        
        $size = $this->file->getSize();
        
        if ($size == 0) {
            return array('error' => 'File is empty');
        }
        
        if ($size > $this->sizeLimit) {
            return array('error' => 'File is too large');
        }
        
        $pathinfo = pathinfo($this->file->getName());
        $filename = $pathinfo['filename'];
        //$filename = md5(uniqid());
        $ext = $pathinfo['extension'];

        if($this->allowedExtensions && !in_array(strtolower($ext), $this->allowedExtensions)){
            $these = implode(', ', $this->allowedExtensions);
            return array('error' => 'File has an invalid extension, it should be one of '. $these . '.');
        }
        
        if(!$replaceOldFile){
            /// don't overwrite previous files that were uploaded
            while (file_exists($uploadDirectory . $filename . '.' . $ext)) {
                $filename .= rand(10, 99);
				return array('error'=>'File already Exist');
            }
        } 
        $today = date("Ymd"); 
		$uploadDir = $uploadDirectory.$filename.'.'.$ext;
		$uploadThumbURL = $uploadUrl.$this->thumbPrefix.$filename.'.'.$ext;
		$uploadOrigDir = $uploadOriginalDirectory.$filename.'.'.$ext;
		
        if ($this->file->save($uploadDir, $uploadThumbURL, $uploadOrigDir)){
            
			$ext = pathinfo($uploadOrigDir, PATHINFO_EXTENSION);
			$thumb_path = $uploadDirectory.$this->thumbPrefix.$this->file->getName();
			$image_path = $uploadDirectory.$this->file->getName();
			$original_path = $uploadDirectory.$this->file->getName();
			
			$thumb_url = $uploadUrl.$this->thumbPrefix.$this->file->getName();
			$image_url = $uploadUrl.$this->file->getName();			
			$original_url = $uploadUrl.'originals/'.$this->file->getName();	
			
			
			if(function_exists('exif_read_data'))
			{
				$exif = @exif_read_data($image_path,'', true, false);				
			}
			
			foreach($this->exif_tags_array as $key => $value)
			{
				if(isset($exif['IFD0']) && array_key_exists($value,$exif['IFD0']))				
				$imageProperties[$value] = $exif['IFD0'][$value];
				
				if(isset($exif['EXIF']) && array_key_exists($value,$exif['EXIF']))				
				$imageProperties[$value] = $exif['EXIF'][$value];
			}
			
			//Creating Thumbnail
			if(!$this->image_resize($image_path, $thumb_path, 100, 100, 1,0)) {
			
				return array('success'=>false,'error'=>'Couldnt create thumbnail.');			
			}
			
			//Resizing the Original Image
			if(!$this->image_resize($image_path, $image_path, 1280, 1024, 0, 1)) {			
				return array('success'=>false,'error'=>'Couldnt create thumbnail.');			
			}
			//rename($original_path, ROOT_DIR.'/resources/uploads/originals/'.rand(100000,999999).'.'.$ext);
			//rename($original_path, ROOT_DIR.'/resources/uploads/originals/'.rand(100000,999999).'.'.$ext);
			//rename($original_path, ROOT_DIR.'/resources/uploads/originals/'.rand(100000,999999).'.'.$ext);
			

			$insertedImageId = $this->saveImageDB($thumb_path,$image_path,$thumb_url,$image_url,$original_path,$original_url,json_encode($imageProperties));
			if(!$insertedImageId) {
				return array('success'=>false,'error'=>'Couldnt save in database.');	
			}			
			
			return array('success'=>true,'error'=>"",'id'=>$insertedImageId,'thumb_path'=>$thumb_url,'image_path'=>$image_url,'exif'=>json_encode($imageProperties));
        } else {
            return array('error'=> 'Could not save uploaded file.' .
                'The upload was cancelled, or server error encountered');
        }
        
    }	
	
	function image_resize($src, $dst, $width, $height, $crop=0,$watermark=0){

	  if(!list($w, $h) = getimagesize($src)) return "Unsupported picture type!";

	  $type = strtolower(substr(strrchr($src,"."),1));
	  if($type == 'jpeg') $type = 'jpg';
	  switch($type){
		case 'bmp': $img = imagecreatefromwbmp($src); break;
		case 'gif': $img = imagecreatefromgif($src); break;
		case 'jpg': $img = imagecreatefromjpeg($src); break;
		case 'png': $img = imagecreatefrompng($src); break;
		default : return "Unsupported picture type!";
	  }

	  // resize
	  if($crop){
		if($w < $width or $h < $height) return "Picture is too small!";
		$ratio = max($width/$w, $height/$h);
		$h = $height / $ratio;
		$x = ($w - $width / $ratio) / 2;
		$w = $width / $ratio;
	  }
	  else{
		if($w < $width and $h < $height) return "Picture is too small!";
		$ratio = min($width/$w, $height/$h);
		$width = $w * $ratio;
		$height = $h * $ratio;
		$x = 0;
	  }

	  $new = imagecreatetruecolor($width, $height);

	  // preserve transparency
	  if($type == "gif" or $type == "png"){
		imagecolortransparent($new, imagecolorallocatealpha($new, 0, 0, 0, 127));
		imagealphablending($new, false);
		imagesavealpha($new, true);
	  }

	  imagecopyresampled($new, $img, 0, 0, $x, 0, $width, $height, $w, $h);

	  switch($type){
		case 'bmp': imagewbmp($new, $dst); break;
		case 'gif': imagegif($new, $dst); break;
		case 'jpg': imagejpeg($new, $dst,$this->file->compressionQuality); break;
		case 'png': imagepng($new, $dst); break;
	  }
	  if(strlen($this->watermark) > 0 && $watermark)new Watermark($dst, $this->watermark, $dst);
	  return true;
	}
	
	
	function saveImageDB($thumb_path,$image_path,$thumb_url,$image_url,$original_path,$original_url,$exif) {
	
		$data = array(
					"catid" 		=> $this->catid,
					"subcatid" 		=> $this->subcatid,
					"thumbpath" 	=> str_replace(ROOT_URL,"",$thumb_url),
					"imagepath" 	=> str_replace(ROOT_URL,"",$image_url),
					"originalpath"	=> str_replace(ROOT_URL,"",$original_url),
					"caption" 		=> "",
					"tags" 			=> "",
					"exif" 			=> $exif,

		);
		$insertImage = $this->queries->insertImageInfo($data);
		
		
		if($insertImage)
		{
			return $insertImage;
		}
		else
		{
			// ...it didn't work properly.  Unlink (delete) the actual and thumbnail files and then notify the user.
			unlink($image_path);
			unlink($thumb_path);
			
			return false;
		}
	}
}

/**
 * Handle file uploads via XMLHttpRequest
 * When using Drag n Drop. XHR
 */
class qqUploadedFileXhr{
    /**
     * Save the file to the specified path
     * @return boolean TRUE on success
     */
	public $compressionQuality;
	public $saveOriginals;
	
	function __construct($siteDetails) {
		$this->compressionQuality = $siteDetails['image_quality'];
		$this->saveOriginals = $siteDetails['allow_originals'];
	}
    function save($imgPath,$thumbPath,$original) {
        $input = fopen("php://input", "r");
        $temp = tmpfile();
        $realSize = stream_copy_to_stream($input, $temp);
		
        fclose($input);
        
        if ($realSize != $this->getSize()){            
            return false;
        }
        
        $target = fopen($imgPath, "w");  
		
        fseek($temp, 0, SEEK_SET);
		
        stream_copy_to_stream($temp, $target);		
		fclose($target);
		if($this->saveOriginals)
		{
			$original_target = fopen($original, "w");
			fseek($temp, 0, SEEK_SET);
			stream_copy_to_stream($temp, $original_target);
			fclose($original_target);
		}
		
        
		
        
        return true;
    }
    function getName() {
        return ereg_replace("[^A-Za-z0-9.]", "", $_GET['qqfile'] );
    }
	
    function getSize() {
        if (isset($_SERVER["CONTENT_LENGTH"])){
            return (int)$_SERVER["CONTENT_LENGTH"];            
        } else {
            throw new Exception('Getting content length is not supported.');
        }      
    }
}

/**
 * Handle file uploads via regular form post (uses the $_FILES array)
 */
class qqUploadedFileForm{
    /**
     * Save the file to the specified path
     * @return boolean TRUE on success
     */
	public $compressionQuality;
	public $saveOriginals;
	
	function __construct($siteDetails) {
		$this->compressionQuality = $siteDetails['image_quality'];
		$this->saveOriginals = $siteDetails['allow_originals'];
	}
	
    function save($imgPath,$thumbPath,$originalPath) {
        if(!move_uploaded_file($_FILES['qqfile']['tmp_name'], $imgPath)){
            return false;
        }
	
		if($this->saveOriginals) {
			if(!move_uploaded_file($_FILES['qqfile']['tmp_name'], $originalPath)){
				return false;
			}
			echo "wwrong";
		}
        return true;
    }
    function getName() {
        return ereg_replace("[^A-Za-z0-9.]", "", $_FILES['qqfile']['name'] );
    }
    function getSize() {
        return $_FILES['qqfile']['size'];
    }	
}

/**********************************************************************************
 * Instantiating the Class
 ***************************/

$allowedExtensions = array("jpg","bmp","gif","png");
$thumbPrefix = "thumb_";

// max file size in bytes
$sizeLimit = 10 * 1024 * 1024;

$exif_tags_array = array('Make','Model','ExposureTime','FNumber','ISOSpeedRatings','ExifVersion','ShutterSpeedValue','ApertureValue',
						 'ExposureBiasValue','MaxApertureValue','MeteringMode','Flash','FocalLength','ExifImageWidth',
						 'ExifImageLength','FocalPlaneXResolution','FocalPlaneYResolution','Flash','FocalLength','ExifImageWidth',);

$pbdb = new queries();

$siteDetails = $pbdb->getSiteDetails();
//$compressionQuality = $siteDetails['image_quality'];

$uploader = new qqFileUploader($allowedExtensions, $sizeLimit, $thumbPrefix, $exif_tags_array,$siteDetails);

$result = $uploader->handleUpload(ROOT_DIR.'/resources/uploads/',FALSE,ROOT_URL.'/resources/uploads/',ROOT_DIR.'/resources/uploads/originals/');

// to pass data through iframe you will need to encode all html tags
echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);