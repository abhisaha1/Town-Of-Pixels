<?php
include_once("../../paths.php");

class Watermark {
	private $originalFile;
	private $DestinationFile;
	private $watermarkText;
	private $type;
	
	function __construct($originalFile, $watermarkText, $DestinationFile) {
		
		$this->originalFile = $originalFile;
		$this->watermarkText = $watermarkText;
		$this->DestinationFile = $DestinationFile;			
		
		$this->applyWaterMark();
	}
	
	function applyWaterMark() {		
		
		list($width, $height) = getimagesize($this->originalFile);
		$image_wm = imagecreatetruecolor($width, $height);
		$image = $this->getImage();
		imagecopyresampled($image_wm, $image, 0, 0, 0, 0, $width, $height, $width, $height); 
		$black = imagecolorallocate($image_wm, 124, 124, 124);
		$white = imagecolorallocate($image_wm, 255, 255, 255);
		$font = ROOT_DIR.'/admin/pages/arial.ttf';
		$font_size = 14; 
		
		$dimensions = imagettfbbox($font_size, 0, $font, $this->watermarkText);
		
		$textWidth = abs($dimensions[4] - $dimensions[0]);
		$x = imagesx($image_wm) - $textWidth;
		
		$rgb = imagecolorat($image, $x-30, $height-30);
		$r = ($rgb >> 16) & 0xFF;
		$g = ($rgb >> 8) & 0xFF;
		$b = $rgb & 0xFF;
		
		if($r > 200 || $g > 200 || $b > 200)
		{
			$fontcolor = $black;
		}else{
			$fontcolor = $white;
		}

		imagettftext($image_wm, $font_size, 0, $x-30, $height-10, $fontcolor, $font, $this->watermarkText);
		
		
		
		if($this->type == "jpeg")			
		imagejpeg($image_wm, $this->DestinationFile, 100); 
		
		if($this->type == "gif")
		imagegif($image_wm, $this->DestinationFile, 100); 
		
		if($this->type == "png")
		imagepng($image_wm, $this->DestinationFile, 100); 
		
		
		imagedestroy($image); 
		imagedestroy($image_wm); 
	}
	
	function getImage() {
    
		$size=getimagesize($this->originalFile);
		switch($size["mime"]){
		   
			case "image/jpeg":
				$this->type = "jpeg";
				$image = imagecreatefromjpeg($this->originalFile); //jpeg file
				break;
			
			case "image/gif":
				$this->type = "gif";
				$image = imagecreatefromgif($this->originalFile); //gif file
				break;
		  
			case "image/png":
				$this->type = "png";
				$image = imagecreatefrompng($this->originalFile); //png file
				break;		
			
		}
		
		return $image;

	}
	
}


/* $originalFile = ROOT_DIR.'/resources/uploads/street.jpg';
$DestinationFile = ROOT_DIR.'/resources/uploads/street.jpg';
$watermarkText = 'Copyright: Abhishek Sahawwwwwwwwwwwwwww'; */


//new Watermark($originalFile, $watermarkText, $DestinationFile);

?>