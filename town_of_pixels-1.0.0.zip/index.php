<?php
ini_set( 'zlib.output_compression', '1' );
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd"> 
<html>
  <head> 
<?php	
	require 'paths.php';
	
	$pbdb = new db(DB_HOST,DB_USER,DB_PASSWORD); 

	$queries = new queries();
	
	
	include_once(ROOT_DIR.'/resources/load_scripts.php');	
	$siteInfo = $queries->getSiteDetails();

	$title = $siteInfo['site_title'];
	
	//GET GOOGLE TRACKING ID
	$google_tracking_id = $siteInfo['g_track_id'];
?>
   
    <title><?=$title?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" >
    <meta name="description" content="<?=$siteInfo['meta_desc']?>" > 
	<script type="text/javascript">

	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', '<?=$google_tracking_id?>']);
	  _gaq.push(['_trackPageview']);

	  (function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();

	</script>
	 <style type = "text/css">
    body{
		overflow-x:hidden;
    }
	#container {
		min-height: 80%;
		position: absolute;
		background: url("<?=ROOT_URL?>/resources/css/images/body-background.jpg") repeat scroll 0 0 transparent;
	}
	
	#supersize img, #supersize a{  
		height:100%;  
		width:100%;  
		display:none;  
	}  
	#supersize .activeslide, #supersize .activeslide img{  
		display:inline;  
	}  
	#comments_bg {
		width: 340px;
		height: 100%;
		background: #000;
		opacity: 0.9;
		position: absolute;
		margin-left: -340px;
		left:100%;
	
	}
	#comments {
		width: 336px;
		height:100%;		
		position: absolute;
		margin-left: -336px;		
		left:100%;
	
	}
	#comments span {
		color:white;
	}
	.colleft {
		border-right:1px dotted #414040;
	}
  </style>
  </head>
  <body>
 
   
  
  <div id = "container"></div>
   
  </body>
</html>