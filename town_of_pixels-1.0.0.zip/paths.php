<?php
DEFINE('ROOT_DIR', dirname(__FILE__));
DEFINE('ROOT_URL', substr($_SERVER['PHP_SELF'], 0, - (strlen($_SERVER['SCRIPT_FILENAME']) - strlen(ROOT_DIR))));
DEFINE('PLUGIN_URL',ROOT_URL.'/resources/plugins/');
DEFINE('PLUGIN_DIR',ROOT_DIR.'/resources/plugins/');
$PATHS_LOADED = TRUE;


if(!file_exists(ROOT_DIR.'/config.php'))
{
	
   header("Location: ".ROOT_URL."/admin/setup-config.php");	
	die();
}

include_once(ROOT_DIR."/config.php");

function __autoload($class_name) {
		include_once ( ROOT_DIR.'/admin/classes/'.$class_name . '.class.php' );
}

$queries = new db(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME); 
$pbdb = new queries;
function display($array)
{
	echo "<pre>";
	print_r($array);
	echo "</pre>";
}
?>