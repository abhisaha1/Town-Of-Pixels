<style type = "text/css">
#navigationMenu{
	margin-top:10px;
	 text-align: right;
	font-family: georgia;
}

#navigationMenu ul{
	 list-style-type: none;
    margin: 0 0 30px 10px;
    padding: 0;
    width: 85%;
}

#navigationMenu .section-title {
	  color: #2C6282;
    font-size: 13px;
    font-weight: bold;
    padding: 3px 12px;
}
#navigationMenu li a{
	color: #B3B4B5;	
	font-size: 11px;
	 text-decoration: none;
	
}
#navigationMenu li a:hover{
	color: red;
	font-size: 11px;
	text-decoration: none;
	
}
#navigationMenu .imagecount {
	 color: #DDDDDD;
    font-size: 10px;
    left: 95%;
    line-height: 20px;
    position: absolute;
}
#navigationMenu .sub-section {
	cursor: pointer;
    padding: 3px 12px;
}
#left_col {	
	height:100%;
	padding: 0px !important;
	
}
#sound{
	margin-left: 28px;
    margin-top: -19px;
    position: absolute;
    top: 100%;
}

.selected {
	color: orange !important;
	font-style: italic;
}
</style>

<?php
include_once ("../../paths.php");

$pbdb = new queries();

$navigationMarkup = $pbdb->getNavigationMarkup();

$siteConfig = $pbdb->getSiteDetails();

if(!$siteConfig['header_display'])
{
	echo $pbdb->applyLeftColHeaderCSS();
	echo $pbdb->getHeaderMarkup();
}


echo $navigationMarkup;
?>
<script language = 'javascript'>

$(document).ready(function() {

	$("#navigationMenu .sub-section").click(function() {

		$("#navigationMenu .sub-section a").removeClass('selected');
		$(this).find('a').addClass('selected');


	});

});

</script>