<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 3.2//EN">
<?php
include_once("../../paths.php");

$pbdb = new queries();
$exif = $pbdb->getExifOf($_GET['imageid']);

$theme = $pbdb->getTheme();
$exifmeta = (isset($exif))?json_decode($exif):array();
$exifmarkup = "";
foreach($exifmeta as $key => $value)
{
	if($value != "")
	$exifmarkup .= "<tr>
						<td>".$key."</td>
						<td>".$value."</td>
					</tr>";
}

$comments = @$pbdb->fetchComments($_GET['imageid']);
?>
<html>
  <head>
    <meta name="generator" content="HTML Tidy for Windows (vers 14 February 2006), see www.w3.org">
    <title></title>
  </head>
  <body>
  <script language = "javascript">
	$(document).ready(function() {
		
		
		
		$("#submitcomment").click(function() {
			
			var commentname = $("#commentname").val();
			var commentemail = $("#commentemail").val();
			var commentbody = $("#commentbody").val();
			var commenturl = $("#commentsite").val();
			var imageid = $("#imageid").val();
			var code = $("#confirm_code").val();
			
			if(commentname == "" || commentbody == "" || code == "")
			alert("You are missing some mandatory(*) information.");
			else {
				$.ajax({
					url: '<?=ROOT_URL?>/admin/classes/queries.class.php',
					data: "insertComment=true&name="+commentname+"&url="+commenturl+"&email="+commentemail+"&body="+commentbody+"&imageid="+imageid+"&code="+code,
					type: 'POST',
					success: function(newcommentmarkup) {
						$("#commentbox h4.commenthead").after(newcommentmarkup).hide().slideDown(1000);
						change_captcha();
						cleanCommentsForm();
					}
					
				});
			}
		
		});
		
		$("#gotop").click(function() {
			 $('body').animate({scrollTop : 0},'slow');
		});
		
		
		//Refresh Captcha
		
		 $('img#refresh').click(function() {  
				
				change_captcha();
		 });
		 
		 function change_captcha()
		 {
			document.getElementById('captcha').src="<?=ROOT_URL?>/resources/pages/captcha/get_captcha.php?rnd=" + Math.random();
		 }
		 
		 //Clear all fields
		 function cleanCommentsForm() {
			$("input,textarea").not("#submitcomment").val("");
		 }
	});
  </script>
  <style type = "text/css">
	
	
	#info-wrapper {
		width: 800px;
	}
	
	#exif {
		width: 300px;
		float: left;
        position: relative;
	}
	
	#commentbox {
		width: 500px;
		float: right;
		position: relative;
	}
	
	#comment-box-bg {
			position:absolute;
			width: 800px;
			height: 100%;
			margin-left: -20px;
			background: <?=$theme['comment_bg_color']?>;
			opacity: <?=$theme['comment_bg_opacity']?>;
	}

	#exif-data-table {
		font-size: 12px;
		color:#999898;
	}
	.comment {
		margin-right: 50px;
		padding: 5px;
		border-bottom: 1px solid #393939;
	}
	.comment p {
		
	}
	label {
		 display: inline;
		position: absolute;
		width: 100px;
	}
	input,textarea {
		margin-left: 100px;
		display: inline;
		border: 1px solid #393939;
		font-size: 11px;
		padding: 5px 5px;
	}
	#write-comment div {
		margin-bottom: 10px;
		margin-left: 20px;
	}
	.goupicon {
		color: #005F92;
		font-family: monospace;
		margin-left: 250px;
		cursor: pointer;
	}
	.comment .name a {
		color: white;
		margin-right: 200px;
		text-decoration: none;
	}
	.comment .name .time {
		font-family: Georgia;
		font-size: 11px;
	}
	.captcha {
		margin-left:100px;
		height: 26px;
	}
	#refresh {
		cursor: pointer;
	}
	#submitcomment {cursor: pointer}
  </style>
        
	<div id = "info-wrapper">
	
		<div id = "comment-box-bg"></div>

		<div id = "exif">
			<h4>Camera & Exposure Information</h4>
			<table id = "exif-data-table" border = "0">
				<?=$exifmarkup?>
			</table>		
		</div>
		
		<div id = "commentbox">
			<h4 class = "commenthead">Comments</h4>
			
			<?=$comments?>
			
			<div id = "write-comment">
				<h4>Write a comment: <span id = "gotop" class = "goupicon">GO TOP</span></h4>
				<div>
					<label>Name*</label><input type = "text" name = "name" id = "commentname"/>
				</div>
				<div>
					<label>Email</label><input type = "text" name = "email" id = "commentemail"/>
					
				</div>
				<div>
					<label>Website</label><input type = "text" name = "website" id = "commentsite"/>
				</div>
				<div>
					<label>Comment*</label><textarea rows = "4" cols = "40" name = "comment" id = "commentbody"></textarea>
				</div>
				<div>			
					<img class = "captcha" src="<?=ROOT_URL?>/resources/pages/captcha/get_captcha.php" alt="" id="captcha" />		
					<img src="<?=ROOT_URL?>/resources/pages/captcha/refresh.jpg" width="25" alt="" id="refresh" />
					<p>
					<label>Enter Code*</label><input name="confirm_code" type="text" id="confirm_code">
				</div>
				<div>
				
				
				
				
					<input type = "submit" id = "submitcomment" value = "submit"/>
					<!--<input type = "submit" id = "gotop" value = "Top"/>-->
					<input type = "hidden" id = "imageid" value = "<?=$_GET['imageid']?>"/>
				</div>
			</div>
		</div>		
	</div>
  </body>
</html>
