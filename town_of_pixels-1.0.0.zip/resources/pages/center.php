<?php
/*****************************************
 * Mandatory Section for any Plugin
 */
include_once("../../paths.php");

/* Get the category and subcategory id*/
$catid = isset($_GET['catid'])? $_GET['catid'] : "";
$subcatid = isset($_GET['subcatid'])? $_GET['subcatid'] : "";

/* Instance of Query Class. You can get all information from database through $pbdb */
$pbdb = new queries();

/* Holds information of all images contained in selected category and subcategory */
$imageInfo = $pbdb->displayImages($catid,$subcatid);

/* You can uncomment the below line to check what information $imageInfo contains. */

// display($imageInfo);

/* ----------------END-OF-MANDATORY-SECTION---------------------*/

 
 
if(sizeof($imageInfo) > 0):

$count = 0;
$fullscreen=array();
$images = "<ul class = 'imagecontainer'>";
foreach($imageInfo as $key => $array) {
	
/**
 * Image Resolution can be high. The below code, gets the desired HEIGHT and WIDTH through
 * the function getImageAspectSize()
 */
	$imageUrlPath = ROOT_URL.$array['imagepath']; //contains full url path of image eg. http://localhost/xxx/image.jpg
	$imageDirPath = ROOT_DIR.$array['imagepath']; //contains full dir path of image eg. C:/www/xxx/image.jpg
	$thumbPath = ROOT_URL.$array['thumbpath'];
	$id = $array['id'];	
	
	$count++;	

/* getImageAspectSize() accepts the full DIRECTORY PATH OF IMAGE */

	$imageAspectSize = $pbdb->getImageAspectSize($imageDirPath);	
	$newWidth = $imageAspectSize['newwidth'];
	$newHeight = $imageAspectSize['newheight'];
	
	$originalSize = $imageAspectSize['originalwidth']."_".$imageAspectSize['originalheight'];
/* So now we have the $newHeight and $newWidth */


	$images .= "<li  class = 'test' id = '$count'><a class = 'atest' href='#'><img width='$newWidth' height='$newHeight' src='$imageUrlPath' alt='' oSize = '$originalSize'/></a></li>";
	//$fullscreen .= "<span id = '$count' style = 'width:$newWidth;display:none'><img width='$newWidth' height='$newHeight' src='$imageUrlPath' alt='' oSize = '$originalSize'/></span>";
	$fullscreen[] = array("image"=>$imageUrlPath, "thumb" => $thumbPath);
	//echo $imageUrlPath;
}
$images .= "</ul>";
echo $images;
$thumbJson =  json_encode($fullscreen);
?>
<style type = "text/css">

.imagecontainer {
	width:12800px;
	padding: 0px;
	margin: 0px;
	margin-top: 50px;
	margin-left: 30px;
	display:none;
}

#controls button {
	  background: none repeat scroll 0 0 transparent;
    border: 1px solid #696969;
    color: #CCCCCC;
    font-size: 12px;
    font-weight: bold;
    padding: 3px;
}
.atest {
	display: inline;
}

.test {
	display: inline;
   // padding: 30px;
	padding: 10px 30px 30px 0;
}

#fullscr {
	border:0px;
}
</style>
<script language = "javascript">

var pointer = 1;
var gap = 30;
var prevImageWidth = 0;
var curImageWidth = 0;
var marginLeft= 30;
var initialMarginLeft= 30;
var nextimageExist = true;
var count=0;
var totalimages;
var t;
$(document).ready(function() {
	
	totalimages = $('.imagecontainer img').length;
	$('.imagecontainer img').load(function(){
	count++;
	console.log(totalimages +" "+ count)
	if(totalimages == count)
		$('.imagecontainer').show();
	});
	
	t = '<?=$thumbJson?>';
	
	$("#next").click(function(e) {
		
		e.preventDefault();
		curImageWidth = $("#"+pointer).width();
		nextimageExist = ($("#"+(pointer+1)).length > 0) ? true : false;
		if(nextimageExist)
		{
			pointer = pointer + 1;
			marginLeft = marginLeft - gap - curImageWidth;			
			$(".imagecontainer").animate({"margin-left": marginLeft}, "slow","linear");
			$("#next,#prev").attr('current',pointer);
		}
		
		
	});
	
	$("#prev").click(function(e) {
		
		e.preventDefault();		
			
		if(pointer > 1)
		{
			pointer = pointer - 1;			
			prevImageWidth = $("#"+pointer).width();			
			marginLeft = marginLeft + gap + prevImageWidth;
			$(".imagecontainer").animate({"margin-left": marginLeft}, "slow","linear");
			$("#next,#prev").attr('current',pointer);
		}
		
	});
	
	$("#first").click(function(e) {
		$(".imagecontainer").animate({"margin-left": initialMarginLeft}, "slow","linear");
		pointer = 1;		
		marginLeft = initialMarginLeft;
	});
	
	
});


</script>

<div id = "controls">
<button id = "first" >First</button><button id = "prev" current = "0">Prev</button><button id = "next" current = "0">Next</button>
</div>
<div style = "display:none" id = "thumbjson">
<?=$thumbJson?>
</div>	
<?php
endif;
?>