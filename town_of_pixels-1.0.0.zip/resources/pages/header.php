<?php
/**
 * Display Header;
 * 
 * applyHeaderCSS() : Default CSS
 * getHeaderMarkup() : Gets the HTML Markup of Header
 *
 * ---Optional---
 * If you want to create your own header Markup, you can use
 * 
 *        getSiteDetails()
 * 
 * It returns an array containing Site Information, which contains the Header Information as well.
 *
 * You can use display(array) to print the available information in any array (debugging). 
 */


?>
<style type = "text/css">
#header{
	background:url("http://www.photoshopstar.com/tutorials/44/02.jpg") repeat scroll 0 0 #141414;
	color: #A6A6A6; !important;
	padding: 20px !important;
	height:40px;
}
</style>
<?php
include_once ("../../paths.php");

$pbdb = new queries();

echo $pbdb->applyHeaderCSS();
echo $pbdb->getHeaderMarkup();


?>

