<!--
THIS PAGE IS THE MOST IMPORTANT PART FOR LOADING AJAXDUDE.
AND HENCE I CALL IT AS THE ENGINE.
=====================
WHAT DOES IT DO ?
=====================
STEP 1:
WE START THE ENGINE. THE ENGINE CONTINIOUSLY CHECKS IF THINGS ARE IN PLACE.
MEANING IF WE HAVE GOT ALL THE REQUIRED DATA TO DISPLAY THE GALLERY.

STEP 2: 
IT GETS THE DEFAULT PLUGIN FOR NAVIGATION AND GALLERY.
THIS DEFAULT PLUGIN IS COMMON FOR ALL SUBCATEGORIES.

STEP 3:
IT CHECKS IF WE NEED TO SHOW THE HEADER OR NOT.

STEP 4:
NOW WE GET THE PLUGINS WHICH ARE DIRECTLY LINKED WITH A SUBCATEGORY.
IF A SUBCATEGORY IS NOT DIRECTLY LINKED WITH ANY PLUGIN, THEN WE USE THE 
PLUGIN WHICH WE GET IN STEP1.

STEP 5:
NEXT WE CHECK WHAT IS THE DEFAULT SUBCATEGORY THAT NEEDS TO BE LOADED FIRST.
IF DEFAULT IS NOT SET FOR ANY SUBCATEGORY, IT WILL OPEN THE FIRST SUBCATEGORY FOR THE FIRST CATEGORY.

STEP 6:
ONCE EVERYTHING IS SET, WE STOP THE ENGINE AND LOAD THE LAYOUT.

-->

<script src = "<?=ROOT_URL.'/resources/js/combine.js'?>" type = "text/javascript"></script>
<!--
<script src = "<?=ROOT_URL.'/resources/js/combine.js'?>" type = "text/javascript"></script>
	JS Files
jquery-latest.js,layoutquery.2.0.js,jquery-ui-1.8.16.custom.min.js,hashchange.js,core.js



<script src = "<?=ROOT_URL.'/resources/js/jquery.js'?>" type = "text/javascript"></script>
<script src = "<?=ROOT_URL.'/resources/js/layoutquery.2.0.js'?>" type = "text/javascript"></script>
<script src = "<?=ROOT_URL.'/resources/js/hashchange.js'?>" type = "text/javascript"></script>
<script src = "<?=ROOT_URL.'/resources/js/core.js'?>" type = "text/javascript"></script>
-->
<?php

$plugins = $queries->getPlugin(); //$plugins will contain min 0 rows or max 2 rows.
$siteConfig = $queries->getSiteDetails();
$headerDisplay = $siteConfig['header_display'];

//GET PLUGINS FOR ALL ACTIVE SUBCATEGORIES
$subcat_plugin = $queries->getSubCatLinkedPlugin();

//coverting THE ABOVE to php array
$subcat_plugin_phpArr = json_decode($subcat_plugin);
?>
<script type = "text/javascript">

var checkparameters = location.hash.split("=");
var centerpage = "";

if(checkparameters.length > 0)
{
	var subcatid = parseInt(checkparameters[2]);
	var subcat_plugin = jQuery.parseJSON('<?=$subcat_plugin?>');
	var plugin_to_be_used = subcat_plugin[subcatid];
	
	centerpage = "<?=ROOT_URL?>/resources/plugins/"+plugin_to_be_used+"/center.php";
}
else 
{
	<?php

	//GET THE DEFAULT CENTER PAGE TO SHOW
	$defaultPage = $queries->getDefaultPage();
	//GET THE DEFAULT CENTER PAGE PARAMETERS
	$defaultURI = "#!catid=".$defaultPage['catid']."&subcatid=".$defaultPage['subcatid'];


	//CHECKING THE PLUGIN TO BE USED FOR FIRST SUBCAT
	$user_defined_plugin = $subcat_plugin_phpArr->$defaultPage['subcatid'];

	//IF USER HAS SELECTED A PLUGIN FOR SUBCAT, USE IT ELSE FALLBACK TO DEFAULT ONE
	
	if($user_defined_plugin != "")
	{
		$centerpage = ROOT_URL."/resources/plugins/".$user_defined_plugin."/center.php";
	}
	else 
	{
		//CHECKING THE GALLERY PLUGIN. IF FOUND, SET IT AS CENTER PAGE.
		$gallery_pluginname = (isset($plugins['plugin_tech_name']) && sizeof($plugins['plugin_tech_name']['gallery']) > 0) ? $plugins['plugin_tech_name']['gallery']."/" : "";

		$gallery_pluginFolderDir = ROOT_DIR."/resources/plugins/".$gallery_pluginname;
		$gallery_pluginFolderUrl = ROOT_URL."/resources/plugins/".$gallery_pluginname;
		$centerpage = (file_exists($gallery_pluginFolderDir."center.php")) ? $gallery_pluginFolderUrl."center.php" :  ROOT_URL.'/resources/pages/center.php';
	}
	?>
}

if(centerpage == "")
centerpage = "<?=$centerpage?>";

</script>
<?php

//CHECKING THE NAVIGATION PLUGIN. IF FOUND, SET IT AS NAVIGATION PAGE
$nav_pluginname = (isset($plugins['plugin_tech_name']) && sizeof($plugins['plugin_tech_name']['navigation']) > 0) ? $plugins['plugin_tech_name']['navigation']."/" : "";

$nav_pluginFolderDir = ROOT_DIR."/resources/plugins/".$nav_pluginname;
$nav_pluginFolderUrl = ROOT_URL."/resources/plugins/".$nav_pluginname;
$navpage = (file_exists($nav_pluginFolderDir."left.php")) ? $nav_pluginFolderUrl."left.php" :  ROOT_URL.'/resources/pages/left.php';

//GET THEMES
$theme = $queries->getTheme();
$headerbgcolor = $theme['header_color'];
$navigationbgcolor = $theme['navigation_color'];
$gallerybgcolor = $theme['gallery_color'];
$footerbgcolor = $theme['footer_color'];
$navigationcatcol = $theme['navigationcatcol'];
$navigationsubcatcol = $theme['navigationsubcatcol'];
$header_font_color = $theme['header_font_color'];
$header_title_color = $theme['header_title_color'];
$navigationimage = $theme['navigationimage'];
$galleryimage = $theme['galleryimage'];


echo "<style type = 'text/css'>
       #navigationMenu .section-title{color:{$navigationcatcol} !important}
       #navigationMenu .sub-section *{color: {$navigationsubcatcol} !important}
	   
	   #header_info #header_title {color:{$header_font_color} !important}
	   #header_info #header_tag {color:{$header_title_color} !important}
	   
	   #container .colleft {			
			background-image:url('{$navigationimage}') !important;						
			background-color: {$navigationbgcolor} !important;
			background-size: {$theme['navigationsize']} !important;
			background-repeat: {$theme['navigationrepeatx']} !important;
			background-position: {$theme['navigationrepeaty']} !important;
	   }
	   #container #content_col {			
			background-image:url('{$galleryimage}') !important;						
			background-color: {$gallerybgcolor} !important;
			background-size: {$theme['gallerysize']} !important;
			background-repeat: {$theme['navigationrepeatx']} !important;
			background-position: {$theme['navigationrepeaty']} !important;
	   }
      </style>";
?>


<script type = "text/javascript">
var subcat_plugin,defaultCenter,engineTimer;
subcat_plugin = jQuery.parseJSON('<?=$subcat_plugin?>');

defaultCenter = "<?=$centerpage?>";
/**
 * THIS IS THE THEME SET BY THE USER IN THE ADMIN PANEL.
 * IT IS CALLED WHEN THE LAYOUT IS LOADED COMPLETELY.
 */
function applyTheme() {
	
	$("#"+headerid).css('background',"<?=$headerbgcolor?>");
	//$(".colleft").css('background',"<?=$navigationbgcolor?>");
	$("#"+content_col_id).css('background',"<?=$gallerybgcolor?>");
	$("#"+footerid).css('background',"<?=$footerbgcolor?>");	
	
}



/**
 * HERE WE SET THE URL WITH PARAMETERS WHEN THE PAGE IS CALLED FOR THE FIRST TIME
 */ 
if(location.hash.substring() == "")
location.href = '<?=$defaultURI?>';



/**
 * THE BELOW FUNCTION IS RESPONSIBLE TO LOAD THE LAYOUT.
 * THE FUNCTION startEngine() WILL DECIDE WHEN TO CALL THIS FUNCTION.
 */
function runLayoutQuery(content_col_path) {
	

	var leftwidth = 15;
	var centercol = 85;//$("body").width() - leftwidth + 6;
	$("#container").layout({			
					cols: 2,
					layoutWidth:100,//screen.width,
					left_col: {'display':true,'width':leftwidth,'id':'left_col','_class':'left_col','path':'<?=$navpage?>'},		
					content_col: {'width':centercol,'id':'content_col','_class':'content_col','path':content_col_path},
					right_col: {'display':false,'width':1,'id':'right_col','_class':'right_col','path':'<?=ROOT_URL.'/resources/pages/right.html'?>'},		
					header: {'display':<?=$headerDisplay?>,'id':'header','_class':'','height':'auto','path':'<?=ROOT_URL.'/resources/pages/header.php'?>','load_once':true},
					footer: {'display':true,'id':'footer','_class':'','height':'auto','path':'<?=ROOT_URL.'/resources/pages/footer.php'?>','load_once':true},		
					menu: {'display':false,'id':'menu','_class':'','height':'auto','path':'<?=ROOT_URL.'/resources/pages/menu.php'?>','load_once':true},		
					colsPadding: 0,
					loadAtOnce: true,
					smartCSS: true,
					unit: '%',
					preloadImage: '<?=ROOT_URL?>/admin/images/spinner.gif',
					paddOthers: true,
					fullHeight: true,
					afterFinish: function(){								
									$("#comments,#comments_bg").css({
																		'margin-top': $("#"+headerid).innerHeight(),
																		'height':$('.colcontent').innerHeight()
																	});									
									applyTheme();
									pleaseResizeLayout();
									
								}										
				});	
	
}

/**
 * IN THE BELOW SECTION WE START THE ENGINE OF PIXELDUDE.
 * THE ENGINE CHECKS IF THE GALLERY PAGE IS CORRECTLY SET.
 * IF THE GALLERY PAGE IS SET CORRECTLY IT STOPS THE ENGINE
 * AND TRIGGERS THE FUNCTION runLayoutQuery() TO LOAD.
 *
 * AS EVERYTHING IS AJAXED, WE STOP THE ENGINE.
 * AT THIS POINT layoutquery.js takes care of the layout.
 */

function startEngine() {
    engineTimer = window.setInterval( function() {
		parameter = location.hash.substring().replace("#!","?");
		try {
			var showPage = (centerpage.indexOf('/undefined/') > 0)?defaultCenter:centerpage;
			content_col_path = showPage+parameter;		
	   
			if(content_col_path.indexOf('/undefined/') == -1 && content_col_path.indexOf('?') >0){
				stopEngine(content_col_path);
			}
		}catch(e) {
			stopEngine(content_col_path);			
		}
    }, 10);
};

function stopEngine(content_col_path){
    window.clearInterval(engineTimer);
    runLayoutQuery(content_col_path);
}
startEngine();
</script>
