<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd"> 
<?php
/*****************************************
 * Mandatory Section for any Plugin
 */
include_once("../../../paths.php");

/* Get the category and subcategory id*/
$catid = isset($_GET['catid'])? $_GET['catid'] : "";
$subcatid = isset($_GET['subcatid'])? $_GET['subcatid'] : "";

/* Instance of Query Class. You can get all information from database through $pbdb */
$pbdb = new queries();

/* Holds information of all images contained in selected category and subcategory */
$imageInfo = $pbdb->displayImages($catid,$subcatid);

/*THIS IS HANDLED BY JQUERY*/
//$comments = $pbdb->fetchComments($imageInfo['id']);

$coverpageData = $pbdb->getCoverpageData($subcatid);


if($coverpageData['coverpagestatus'] == "active"){
	$coverpage = $coverpageData['coverpage'];
	$coverpagewidth = $coverpageData['coverpagewidth'];
}else{
	$coverpage = "";
	$coverpagewidth = 0;
}
//echo ($coverpage);
/* You can uncomment the below line to check what information $imageInfo contains. */

// display($imageInfo);

/* ----------------END-OF-MANDATORY-SECTION---------------------*/

 




if($coverpage  == "" && sizeof($imageInfo) <= 0)
{
	
	die("<span style='color:#ccc'>Empty Page !!</span>");
	
}
elseif($coverpage  == "" && sizeof($imageInfo) <= 0)
{
	
	echo "
			<style type = ;text/css;>
				.imagecontainer {
					width: <?=$coverpagewidth?>px;
					margin-left: 10px;
				}
				#controls {
					visibility:hidden;
				}
			</style>
	
		";
	
	
	echo "
	
		<ul class = 'imagecontainer'>
			<li  class = 'test' id = 'coverpage'><span>".$coverpage."</span></li>
		  </ul>";
		  
	
	die();
}

$count = 0;
$total_width_all_images = 0;
$fullscreen=array();
$full_image="<div style='display:none'>";
$images = "<ul class = 'imagecontainer'>";
/* $images .= "<li  class = 'test' id = 'coverpage'><span>".$coverpage."</span></li>"; */

foreach($imageInfo as $key => $array) {
	

	$imageUrlPath = $array['imagepath']; //contains full url path of image eg. http://localhost/xxx/image.jpg
	$thumbPath = $array['thumbpath'];
	$imageid = $array['id'];
	$id = $array['id'];	
	$oUrlPath = $array['originalpath']; 
	$count++;	
	
/**
 * Image Resolution can be high. The below code, gets the desired HEIGHT and WIDTH through
 * the function getImageAspectSize()
 * getImageAspectSize() accepts the full DIRECTORY PATH OF IMAGE
 */

	$imageAspectSize = $pbdb->getImageAspectSize($imageid);	
	$newWidth = $imageAspectSize['newwidth'].'px';
	$newHeight = $imageAspectSize['newheight'].'px';
	
	$originalSize = $imageAspectSize['originalwidth']."_".$imageAspectSize['originalheight'];
/* So now we have the $newHeight and $newWidth */


	$images .= "<li  class = 'thumb' id = '$count'><a onClick ='fullScreen(\"$imageUrlPath\",\"$newWidth\",\"$newHeight\")'>
	           <img class='thumb1' imageid = '$imageid' src='$thumbPath' alt='' /></a></li>";
	
	//$full_image .= "<img class='full' imageid ='$imageid' src= '$imageUrlPath' />";
	
}
$images .= "</ul>";
$full_image .= "</div>";
echo $images;
echo $full_image;
echo applyCss();

function applyCss() {
	
	return '<style type="text/css">
			.thumb {
			display:inline;
			}
			/* edit the css for thumbnails */
			.thumb1 {
					border: 3px solid #F2EAEA;
					box-shadow: 3px 3px 2px 0 grey;
					margin-left:5px;
					width:50px;
					cursor:pointer;
			}
			#content_col {
					background:#DDDDDD;
			}
			</style>';
}

//echo ROOT_DIR;
?>
<style type="text/css">
.img1 {
border: 5px solid #F2EAEA;
	    box-shadow: 5px 5px 5px 0 grey;
		margin-left:48px;
		
}
</style>
</script>
<script type="text/javascript">
var full_image ="<?=$full_image?>";
function fullScreen(a,width,height) {
  $("#img").fadeOut("slow",function(){
	$(this).html("<img class='img1' width='"+width+"' height='"+height+"' src='"+a+"' alt='' />").fadeIn("slow");
	});
}
$(document).ready(function() {

	$("#1 a").click();
});
</script>
<div id="img"/>
