<?php
/*****************************************
 * Mandatory Section for any Plugin
 */
include_once("../../../paths.php");

/* Get the category and subcategory id*/
$catid = isset($_GET['catid'])? $_GET['catid'] : "";
$subcatid = isset($_GET['subcatid'])? $_GET['subcatid'] : "";

/* Instance of Query Class. You can get all information from database through $pbdb */
$pbdb = new queries();

/* Holds information of all images contained in selected category and subcategory */
$imageInfo = $pbdb->displayImages($catid,$subcatid);

$comments = $pbdb->fetchComments(0);
//echo ($comments);

/* You can uncomment the below line to check what information $imageInfo contains. */

// display($imageInfo);

/* ----------------END-OF-MANDATORY-SECTION---------------------*/

 
 
if(sizeof($imageInfo) > 0):

$count = 0;
$total_width_all_images = 0;
$fullscreen=array();

$images = "<ul class = 'imagecontainer'>";
foreach($imageInfo as $key => $array) {
	

	$imageUrlPath = $array['imagepath']; //contains full url path of image eg. http://localhost/xxx/image.jpg
	$imageDirPath = ROOT_DIR.'../../'.$array['imagepath']; //dirname(__FILE__); //contains full dir path of image eg. C:/www/xxx/image.jpg
	$thumbPath = $array['thumbpath'];
	$imageid = $array['id'];
	$id = $array['id'];	
	
	$count++;	
	
/**
 * Image Resolution can be high. The below code, gets the desired HEIGHT and WIDTH through
 * the function getImageAspectSize()
 * getImageAspectSize() accepts the full DIRECTORY PATH OF IMAGE
 */

	$imageAspectSize = $pbdb->getImageAspectSize($imageDirPath);	
	$newWidth = $imageAspectSize['newwidth'].'px';
	$newHeight = $imageAspectSize['newheight'].'px';
	
	$originalSize = $imageAspectSize['originalwidth']."_".$imageAspectSize['originalheight'];
/* So now we have the $newHeight and $newWidth */


	$images .= "<li  class = 'test' id = '$count'><span style = 'width:$newWidth' id = 'toolbarbg' class='imagestatus'></span><img imageid = '$imageid' class='lazy' width='$newWidth' height='$newHeight' src = '' original-src='$imageUrlPath' alt='' oSize = '$originalSize'/><span id='imagetoolbar'><a href = '#' style = 'width:$newWidth' class = 'showimginfo imagestatus' imageid = '$imageid'>Comments</a></span></li>";
	
	$fullscreen[] = array("image"=>$imageUrlPath, "thumb" => $thumbPath);
	
}
$images .= "</ul>";
echo $images;

$thumbJson =  json_encode($fullscreen);
?>
<style type = "text/css">

.imagecontainer {
	width:2000px;
	padding: 0px;
	margin: 0px;
	margin-top: 50px;
	margin-left: 30px;
	display: none;
}
.imagestatus {
	display:none;
}
#infoholder {
	 margin-left: 50px;
    margin-top: 50px;
    width: 800px;
}
#imagetoolbar{
	margin-left: -90px;
    position: absolute;
	margin-top: 5px;
}
#imagetoolbar a{
	color: #DDDDDD;
    font-family: Georgia;
    text-decoration: none;
}
#toolbarbg {
	background: none repeat scroll 0 0 #030303;
    height: 30px;
    opacity: 0.8;
    position: absolute;
    
}
#controls {
	margin-left:28px;
}
#controls button {
	background: none repeat scroll 0 0 black;
    border: 1px solid #696969;
    border-radius: 3px 3px 3px 3px;
    color: #CCCCCC;
    cursor: pointer;
    font-size: 12px;  
    margin-left: 4px;
    padding: 3px;
	font-family: Comic Sans MS;
}
.atest {
	display: inline;
}

.test {
	display: inline;
   // padding: 30px;
	padding: 10px 30px 30px 0;
}

#fullscr {
	border:0px;
}

#infoholder {
	color: #999898;
}

</style>
<script language = "javascript">

var pointer = 1;
var gap = 30;
var prevImageWidth = 0;
var curImageWidth = 0;
var marginLeft= 30;
var initialMarginLeft= 30;
var nextimageExist = true;
var count=0;
var totalimages;
var t;
var n = 0;
function loadimage(n) {
		
		var curimage = $(".imagecontainer li:nth-child("+n+")").find('img');		
		curimage.attr('src',curimage.attr('original-src')).bind('load',function() {
			
			
			$(this).removeAttr('original-src').fadeIn();
			n++;
			if(n <= totalimages)
			{
				loadimage(n);				
			}
			$('.imagecontainer').css('width',$('.imagecontainer').width() + $(this).width());
		});
		
}
$(document).ready(function() {

	$(".showimginfo").click(function(e)  {
		e.preventDefault();
		var imageid = $(this).attr('imageid');
		showImageInfo(imageid);
	});

	$('.imagecontainer li').hover(function() {
		$(this).find(".imagestatus").show();
	},function() {
		$(this).find(".imagestatus").hide();
	});

	var totalgallerywidth = 2000;
	$('.imagecontainer img').each(function() {
		totalgallerywidth += $(this).width();
	});
	$(".imagecontainer").css('width',totalgallerywidth).fadeIn();
	
	totalimages = $('.imagecontainer img').length;
	
	if(totalimages > 0)loadimage(1);
	
	t = '<?=$thumbJson?>';
	
	$("#next").click(function(e) {
		
		e.preventDefault();
		curImageWidth = $("#"+pointer).width();
		nextimageExist = ($("#"+(pointer+1)).length > 0) ? true : false;
		if(nextimageExist)
		{
			pointer = pointer + 1;
			marginLeft = marginLeft - gap - curImageWidth;			
			$(".imagecontainer").animate({"margin-left": marginLeft}, 1000,"linear");
			$("#next,#prev").attr('current',pointer);
		}
		
		$("#infoholder").slideUp(1000)
		$(document).scrollTop(0);
	});
	
	$("#prev").click(function(e) {
		
		e.preventDefault();		
			
		if(pointer > 1)
		{
			pointer = pointer - 1;			
			prevImageWidth = $("#"+pointer).width();			
			marginLeft = marginLeft + gap + prevImageWidth;
			$(".imagecontainer").animate({"margin-left": marginLeft}, 1000,"linear");
			$("#next,#prev").attr('current',pointer);
		}
		$("#infoholder").slideUp(1000)
		$(document).scrollTop(0);
	});
	
	$("#first").click(function(e) {
		$(".imagecontainer").animate({"margin-left": initialMarginLeft}, "slow","linear");
		pointer = 1;		
		marginLeft = initialMarginLeft;
	});
	
	
	$(document).live('keyup',function(e) {
		//e.preventDefault();
	  if (e.keyCode == 13) { $("#fullscreen").click(); }     // enter
	  if (e.keyCode == 27) { $(document).find("#fullscr").remove();$("#container").show(); }   // esc
	}); 
	$("#fullscreen").click(function(e) {
		e.preventDefault();		
		$("<iframe style = 'display:none' id = 'fullscr' src = '<?=PLUGIN_URL?>/horizontal_slide/fullscreen.php'></iframe>").load(function(){
			  switchdisplay();
		}).prependTo('body');
	});
});
function switchdisplay() {
	
	
	$("#container").hide();
	$("#fullscr").css({
			'background': '#000',
			'position':'absolute',
			'width':'100%',
			'height':'100%'
		}).show().focus();
		
}
</script>

<div id = "controls">
<button id = "first" >First</button><button id = "prev" current = "0">Prev</button><button id = "next" current = "0">Next</button><button id = "fullscreen">Screen</button>

</div>

<div id = "infoholder"/>	
<?php

endif;
?>
<script>


function showImageInfo(id) {

	$.get("<?=ROOT_URL?>/resources/pages/comments.php?imageid="+id, function(msg) {
		
		$("#infoholder").html(msg).slideDown(1000, function(){
		
			$(document).scrollTop(800);
		});
	});
}
</script>