<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd"> 
<?php
/*****************************************
 * Mandatory Section for any Plugin
 */
include_once("../../../paths.php");

/* Get the category and subcategory id*/
$catid = isset($_GET['catid'])? $_GET['catid'] : "";
$subcatid = isset($_GET['subcatid'])? $_GET['subcatid'] : "";

/* Instance of Query Class. You can get all information from database through $pbdb */
global $pbdb;

/* Holds information of all images contained in selected category and subcategory */
$imageInfo = $pbdb->displayImages($catid,$subcatid);

$coverpageData = $pbdb->getCoverpageData($subcatid);


if($coverpageData['coverpagestatus'] == "active"){
	$coverpage = $coverpageData['coverpage'];
	$coverpagewidth = $coverpageData['coverpagewidth'];
}else{
	$coverpage = "";
	$coverpagewidth = 0;
}

$randomImageArr = $pbdb->getRandomImage();
$imagePath = $randomImageArr['imagepath'];
$imageId = $randomImageArr['id'];
$imageAspectSize = $pbdb->getImageAspectSize($imageId);	
$newWidth = $imageAspectSize['newwidth'].'px';
$newHeight = $imageAspectSize['newheight'].'px';

$markup = "<div id = 'imageholder'>";
 
if($coverpage  != "")
{
	
	echo "<div id = 'coverpage'>$coverpage</div>";
	
}

$markup .= "<img width = '$newWidth' height = '$newHeight' src = '$imagePath'>";
$markup .= "</div>";

echo "<style type = 'text/css'>
		#imageholder {
			padding: 10px;	
		}
		#coverpage {
			width: $coverpagewidth;
			padding: 10px;
		}
	 </style>
";
echo $markup;