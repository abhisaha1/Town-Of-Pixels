var Horizontal_slide = {
	
	pointer : 1,	
	gap : 30,
	prevImageWidth : 0,
	curImageWidth : 0,
	marginLeft: 30,
	initialMarginLeft: 30,
	nextimageExist : 0,
	count:0,	
	t:'',
	imagesLoaded : 2,
	totalGalleryWidth: 20000,
	currentImage: "",
	totalImages : $('.imagecontainer img').length + 1,
	rootURL: "",
	pluginURL:"",
	coverPageWidth: 0,
	start:1,
	
	init: function() {
		$('.imagecontainer #coverpage').css('width',this.coverPageWidth);
		if(this.coverPageWidth == 0)
		$("#coverpage").css("padding-right",0);
		$('.imagecontainer').css('margin-left',this.initialMarginLeft);
		var obj = this;
		this.setGalleryWidth();
		if(this.totalImages > 0) {
			this.lazyLoadImage();
		}
		this.clickCommentsAct();		
		this.clickNextAct();
		this.clickPrevAct();
		this.getKeyPress();
		this.clickFirst();			
		this.clickFullscreen();
		
	},
	setGalleryWidth : function() {
	
		$('.imagecontainer img').each(function() {
			this.totalgallerywidth += $(this).width();
		});
		$(".imagecontainer").css('width',this.totalgallerywidth).fadeIn();
	
	},
	clickCommentsAct : function() {
		var obj = this;
		$(".showimginfo").click(function(e)  {
			
			var imageboxheight = $(this).parent().parent().parent().height() - $(this).parent().parent().offset().top - $(this).parent().parent().height();
			e.preventDefault();
			var imageid = $(this).attr('imageid');
			$("#infoholder").css('margin-top',-imageboxheight);
			
			obj.showImageInfo(imageid);
		});
	
	
	},
	showImageInfo : function(id) {
		
		$.get(this.rootURL+"/resources/pages/comments.php?imageid="+id, function(msg) {
			
			
			
			$("#infoholder").html(msg).slideDown(1000, function(){
			
				$(document).scrollTop(800);
			});
			
		});
	
	},
	showhideImageBar : function() {
	
		$('.imagecontainer li').hover(function() {
			$(this).find(".imagestatus").show();
		},function() {
			$(this).find(".imagestatus").hide();
		});
	
	},	
	lazyLoadImage : function(callback) {
		var obj = this;		
		
		var $currentImage = $(".imagecontainer li:nth-child("+obj.imagesLoaded+")").find('img');
		if($currentImage.attr('original-src'))	
		{
			$currentImage.attr('src',$currentImage.attr('original-src')).bind('load',function() {
				$currentImage.removeAttr('original-src').fadeIn("slow");
				$currentImage.parent().find('.caption').fadeIn();
				$('.imagecontainer').css('width',$('.imagecontainer').width() + $currentImage.width());	
				obj.imagesLoaded++;
				if(obj.imagesLoaded <= obj.totalImages){
					obj.lazyLoadImage();console.log(obj.imagesLoaded);
				}
				else obj.showhideImageBar();
			});
			
		}			
	},	
	clickNextAct : function() {
		
		var obj = this;
		
		$("#next").click(function(e) {
			e.preventDefault();
			obj.addImageInURL(parseInt($(this).attr('current')),'next');
			if(obj.start && obj.coverPageWidth > 0) {
			
				obj.marginLeft =  - obj.coverPageWidth;	
				$(".imagecontainer").animate({"margin-left": obj.marginLeft}, 200,"linear");
				obj.start = 0;				
				$("#next,#prev").attr('current',1);
			}
			else
			{
				obj.curImageWidth = $("#"+obj.pointer).width();
				obj.nextimageExist = ($("#"+(obj.pointer+1)).length > 0) ? 1 : 0;	
				obj.start = 0;
			}
			
			if(obj.nextimageExist)
			{
				obj.pointer = obj.pointer + 1;
				obj.marginLeft = obj.marginLeft - obj.gap - obj.curImageWidth;			
				$(".imagecontainer").animate({"margin-left": obj.marginLeft}, 1000,"linear");
				
				$("#next,#prev").attr('current',obj.pointer);
			}
			
			$("#infoholder").slideUp(1000)
			$(document).scrollTop(0);
		});
	
	},
	clickPrevAct : function() {
	
		var obj = this;
		$("#prev").click(function(e) {		
			e.preventDefault();		
			obj.addImageInURL(parseInt($(this).attr('current')),'prev');
			if(obj.coverPageWidth > 0 && $(this).attr('current') == "1") {
				obj.marginLeft = obj.gap;				
				$(".imagecontainer").animate({"margin-left": obj.marginLeft}, 100,"linear");
				obj.start = 1;
				obj.nextimageExist = 0;
				$("#next,#prev").attr('current',0);
			}	
			if(!obj.start && obj.pointer > 1)
			{
				obj.pointer = obj.pointer - 1;			
				obj.prevImageWidth = $("#"+obj.pointer).width();			
				obj.marginLeft = obj.marginLeft + obj.gap + obj.prevImageWidth;
				if(obj.pointer == 1)obj.start = 1;					
				$(".imagecontainer").animate({"margin-left": obj.marginLeft}, 1000,"linear");
				$("#next,#prev").attr('current',obj.pointer);
				
			}
			$("#infoholder").slideUp(1000)
			$(document).scrollTop(0);
			
		});
		
	},
	clickFirst : function() {
		
		var obj = this;
		
		$("#first").click(function(e) {
			$("#infoholder").slideUp(1000);
			$(document).scrollTop(0);
			$(".imagecontainer").animate({"margin-left": obj.initialMarginLeft}, "slow","linear");
			obj.pointer = 1;		
			obj.marginLeft = obj.initialMarginLeft;
			obj.nextimageExist = 0;
			obj.start = 1;
		});
		
		
	
	},
	getKeyPress : function() {
		
		$(document).live('keyup',function(e) {
			//e.preventDefault();
			if (e.keyCode == 13) { $("#fullscreen").click(); }     // enter
			if (e.keyCode == 27) { $(document).find("#fullscr").remove();$("#container").show(); }   // esc
		}); 
	
	},
	clickFullscreen : function() {
		var obj = this;
		$("#fullscreen").click(function(e) {
			e.preventDefault();		
			$("<iframe style = 'display:none' id = 'fullscr' src = '"+obj.pluginURL+"horizontal_slide/fullscreen.php'></iframe>").load(function(){
					
					$("#container").hide();
					$("#fullscr").css({
						'background': '#000',
						'position':'absolute',
						'width':'100%',
						'height':'100%'
					}).show().focus();
					
			}).prependTo('body');
		});
	
	},
	addImageInURL : function(currentClick,action) {
		
		if(currentClick == 0 && action == "next" && this.coverPageWidth == 0){
			current = currentClick+2;
		}
		else if(currentClick == 0 && action == "next" && this.coverPageWidth > 0)current = currentClick+1;		
		else if(action == "next")current = currentClick+1;
		else if(action == "prev")current = currentClick-1;
		
		
		if(current > 0 && current < Horizontal_slide.totalImages)
		{
			imageid = $("#"+current).find('img.lazy').attr('imageid');
			
			add_image_to_url(imageid);
		}
	
	}

};