  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd"> 
<?php
/*****************************************
 * Mandatory Section for any Plugin
 */
include_once("../../../paths.php");

/* Get the category and subcategory id*/
$catid = isset($_GET['catid'])? $_GET['catid'] : "";
$subcatid = isset($_GET['subcatid'])? $_GET['subcatid'] : "";

/* Instance of Query Class. You can get all information from database through $pbdb */
//$pbdb = new queries();
//global $pbdb;
/* Holds information of all images contained in selected category and subcategory */
$imageInfo = $pbdb->displayImages($catid,$subcatid);

/*THIS IS HANDLED BY JQUERY*/
//$comments = $pbdb->fetchComments($imageInfo['id']);

$coverpageData = $pbdb->getCoverpageData($subcatid);


if($coverpageData['coverpagestatus'] == "active"){
	$coverpage = $coverpageData['coverpage'];
	$coverpagewidth = $coverpageData['coverpagewidth'];
}else{
	$coverpage = "";
	$coverpagewidth = 0;
}

/* If commenting is turned on */
$siteInfo = $pbdb->getSiteDetails();
$comment_check = $siteInfo['allow_comments'];

//echo ($coverpage);
/* You can uncomment the below line to check what information $imageInfo contains. */

// display($imageInfo);

/* ----------------END-OF-MANDATORY-SECTION---------------------*/

 
//if(sizeof($imageInfo) <= 0 && $coverpage == "")

echo '<link rel = "stylesheet" media = "screen" type = "text/css" href = "'.PLUGIN_URL.'horizontal_slide/css/horizontal-slide.css">';

if($coverpage  == "" && sizeof($imageInfo) <= 0)
{
	
	die("<span style='color:#ccc'>Empty Page !!</span>");
	
}
elseif($coverpage  != "" && sizeof($imageInfo) <= 0)
{
	
	echo "
			<style type = ;text/css;>
				.imagecontainer {
					width: <?=$coverpagewidth?>px;
					margin-left: 10px;
				}
				#controls {
					visibility:hidden;
				}
				.imagecontainer {
					display:none;
				}
			</style>
	
		";
	
	
	echo "
	
		<ul class = 'imagecontainer'>
			<li  class = 'test' id = 'coverpage'><span>".$coverpage."</span></li>
		  </ul>";
		  
	
	die();
}

$count = 0;
$total_width_all_images = 0;
$fullscreen=array();

$images = "<ul class = 'imagecontainer'>";
$images .= "<li  class = 'test' id = 'coverpage'><span>".$coverpage."</span></li>";

foreach($imageInfo as $key => $array) {
	

	$imageUrlPath = $array['imagepath']; //contains full url path of image eg. http://localhost/xxx/image.jpg
	$thumbPath = $array['thumbpath'];
	$imageid = $array['id'];
	$id = $array['id'];	
	$caption = $array['caption'];
	$count++;	
	
/**
 * Image Resolution can be high. The below code, gets the desired HEIGHT and WIDTH through
 * the function getImageAspectSize()
 * getImageAspectSize() accepts the full DIRECTORY PATH OF IMAGE
 */

	$imageAspectSize = $pbdb->getImageAspectSize($imageid);	
	$newWidth = $imageAspectSize['newwidth'].'px';
	$newHeight = $imageAspectSize['newheight'].'px';
	
	$captionWidth = (intval($imageAspectSize['newwidth']) - 6).'px';
	$originalSize = $imageAspectSize['originalwidth']."_".$imageAspectSize['originalheight'];
/* So now we have the $newHeight and $newWidth */


	$images .= "<li  class = 'test' id = '$count'>";

	if($comment_check) {			
		$images .= "<span style = 'width:$newWidth' id = 'toolbarbg' class='imagestatus'></span>";
	}
	$images .= "<img imageid = '$imageid' class='lazy' src = '' original-src='$imageUrlPath' alt='' oSize = '$originalSize'/>";
	
	if($comment_check) {			
	$images .=  "<span id='imagetoolbar'>						
				<a href = '#' style = 'width:$newWidth' class = 'showimginfo imagestatus' imageid = '$imageid'>Comments</a>
				</span>";
	}			
                                       
	$images .= "<br>";
	
	if($caption != "")
	$images .=      "<span style = 'width:$captionWidth' class = 'caption ui-corner-all'>$caption</span>";
	$images .=		"</li>";
	
	$fullscreen[] = array("image"=>$imageUrlPath, "thumb" => $thumbPath);
	
}
$images .= "</ul>";
$thumbJson =  json_encode($fullscreen);

if(sizeof($imageInfo) > 0){

?>

<div id = "controls">
	
	<span id = "first">First | </span>
	<span id = "prev" current = "0">Prev | </span>
	<span id = "next" current = "0">Next | </span>
	<span id = "fullscreen">FullScreen</span>

</div>
<?php
}
echo $images;
?>
<div id = "infoholder"/>	

<script language = "javascript">

$(document).ready(function() {
	
	var script = document.createElement( 'script' );
	script.type = 'text/javascript';
	script.src = "<?=PLUGIN_URL?>horizontal_slide/js/horizontal-slide.js";
	$("head").append( script );
	
	Horizontal_slide.pluginURL = "<?=PLUGIN_URL?>";
	Horizontal_slide.rootURL = "<?=ROOT_URL?>";	
	Horizontal_slide.width = "<?=$newWidth?>";
	Horizontal_slide.height = "<?=$newHeight?>";
	Horizontal_slide.coverPageWidth = "<?=$coverpagewidth?>";
	Horizontal_slide.t = '<?=$thumbJson?>';
	Horizontal_slide.init();
	
});
</script>