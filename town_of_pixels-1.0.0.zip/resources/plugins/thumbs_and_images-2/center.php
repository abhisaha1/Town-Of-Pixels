 <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd"> 
<?php
/*****************************************
 * Mandatory Section for any Plugin
 */
include_once("../../../paths.php");

/* Get the category and subcategory id*/
$catid = isset($_GET['catid'])? $_GET['catid'] : "";
$subcatid = isset($_GET['subcatid'])? $_GET['subcatid'] : "";

/* Instance of Query Class. You can get all information from database through $pbdb */
$pbdb = new queries();

/* Holds information of all images contained in selected category and subcategory */
$imageInfo = $pbdb->displayImages($catid,$subcatid);

/*THIS IS HANDLED BY JQUERY*/
//$comments = $pbdb->fetchComments($imageInfo['id']);

$coverpageData = $pbdb->getCoverpageData($subcatid);


if($coverpageData['coverpagestatus'] == "active"){
	$coverpage = $coverpageData['coverpage'];
	$coverpagewidth = $coverpageData['coverpagewidth'];
}else{
	$coverpage = "";
	$coverpagewidth = 0;
}

/* ----------------END-OF-MANDATORY-SECTION---------------------*/

if($coverpage  == "" && sizeof($imageInfo) <= 0)
{
	
	die("<span style='color:#ccc'>Empty Page !!</span>");
	
}

$count = 0;
$total_width_all_images = 0;
$fullscreen=array();
$full_image="<div style='display:none'>";
$images = "<ul class = 'imagecontainer'>";
/* $images .= "<li  class = 'test' id = 'coverpage'><span>".$coverpage."</span></li>"; */

foreach($imageInfo as $key => $array) {
	

	$imageUrlPath = $array['imagepath']; //contains full url path of image eg. http://localhost/xxx/image.jpg	
	$thumbPath = $array['thumbpath'];
	$imageid = $array['id'];
	$id = $array['id'];	
	$oUrlPath = $array['originalpath']; 
	$caption = $array['caption'];
	$count++;	
	
	
/**
 * Image Resolution can be high. The below code, gets the desired HEIGHT and WIDTH through
 * the function getImageAspectSize()
 * getImageAspectSize() accepts the full DIRECTORY PATH OF IMAGE
 */

	$imageAspectSize = $pbdb->getImageAspectSize($imageid);	
	$newWidth = $imageAspectSize['newwidth'].'px';
	$newHeight = $imageAspectSize['newheight'].'px';
	
	$originalSize = $imageAspectSize['originalwidth']."_".$imageAspectSize['originalheight'];
/* So now we have the $newHeight and $newWidth */


	$images .= "<li  class = 'thumb' id = '$count'><a id='$imageid' onClick ='fullScreen(\"$imageid\",\"$imageUrlPath\",\"$newWidth\",\"$newHeight\",\"$caption\")'>
	           <img class='thumbClass' imageid = '$imageid' src='$thumbPath' alt='' /></a></li>";
	
	
	
}
$images .= "</ul>";
$full_image .= "</div>";
echo $images;
echo $full_image;
echo applyCss();

function applyCss() {
	
	return '<style type="text/css">
			.thumb {
			display:inline;
			}
			/* edit the css for thumbnails */
			.thumbClass {
					border: 3px solid #F2EAEA;
					box-shadow: 3px 3px 2px 0 grey;
					margin-left:5px;
					width:50px;
			}
			#content_col {
					background:#DDDDDD;
			}
			</style>';
}

?>
<style type="text/css">
.imgClass {
	border: 5px solid #F2EAEA;
	box-shadow: 5px 5px 5px 0 grey;		
}
.thumbClass {
	cursor:pointer;
}
#commentInfo {
	margin-left: 90px;
	margin-top: 30px;
}
#comment-box-bg {
	margin-left: -40px !important;
}
#imageBox {
	margin:auto;
}
#info-wrapper {
    margin: auto;
}
.imagecontainer {
	text-align:center;
	margin-left: -50px;
}
.comment .name a {
    color: #0865C8 !important;
}
.caption {
	background: none repeat scroll 0 0 #FFFFFF;
    display: block;
    padding: 6px;
    width: 100%;
}
.trigger_comments {
	color: #696969;
    float: right;
    font-family: Lucida Grande;
    font-size: 12px;
    font-weight: bold;
    text-decoration: none;
}
</style>
</script>
<script type="text/javascript">
var full_image ="<?=$full_image?>";
function fullScreen(imageid,a,width,height,caption) {
	add_image_to_url(imageid);
	
	$("#commentInfo").html("");
	$("#imageBox").fadeOut("slow",function(){
		$(this).css('width',width).html("<img class='imgClass' width='"+ width +"' height='" +height+ "' src='"+ a +"' alt='' /><span class='caption'>"+caption+"</span><a href = '#' imageid = '"+ imageid+ "' class = 'trigger_comments'>COMMENT</a>").fadeIn("slow");
		if($(".caption").html() == "")$(".caption").hide();
	});
}
$(document).ready(function() {
	
	<?php
	if(isset($_GET['imageid'])) {
	?>
		$("li a#<?=$_GET['imageid']?>").click();
	<?php
	} else {
	?>
		$("#1 a").click();
	<?php
	}
	?>
	$(".trigger_comments").live('click',function(e) {
		e.preventDefault();
		obj = $(this);
		$.get("<?=ROOT_URL?>/resources/pages/comments.php?imageid="+ obj.attr('imageid'), function(msg) {			
				
			$("#commentInfo").html(msg).slideDown(1000, function(){
				
				$(document).scrollTop(800);
			});
			
		});
		
	});
	
});
</script>
<div id="imageBox"/>
<div id = "commentInfo"/>
