<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd"> 
<?php
/*****************************************
 * Mandatory Section for any Plugin
 */
include_once("../../../paths.php");

/* Get the category and subcategory id*/
$catid = isset($_GET['catid'])? $_GET['catid'] : "";
$subcatid = isset($_GET['subcatid'])? $_GET['subcatid'] : "";

/* Instance of Query Class. You can get all information from database through $pbdb */
$pbdb = new queries();

/* Holds information of all images contained in selected category and subcategory */
$imageInfo = $pbdb->displayImages($catid,$subcatid);

/*THIS IS HANDLED BY JQUERY*/
//$comments = $pbdb->fetchComments($imageInfo['id']); // $imageInfo['id'] = $imageid

$coverpageData = $pbdb->getCoverpageData($subcatid);


if($coverpageData['coverpagestatus'] == "active"){
	$coverpage = $coverpageData['coverpage'];
	$coverpagewidth = $coverpageData['coverpagewidth'];
}else{
	$coverpage = "";
	$coverpagewidth = 0;
}
/* ----------------END-OF-MANDATORY-SECTION---------------------*/

echo "<script src = '".PLUGIN_URL."galleryview/js/jquery.galleryview-3.0-dev.js' type = 'text/javascript'></script>";
echo "<script src = '".PLUGIN_URL."galleryview/js/jquery.timers-1.2.js' type = 'text/javascript'></script>";

if($coverpage  == "" && sizeof($imageInfo) <= 0)
{
	
	die("<span style='color:#ccc'>Empty Page !!</span>");
	
}
elseif($coverpage  == "" && sizeof($imageInfo) <= 0)
{	
	echo "
			<style type = ;text/css;>
				.imagecontainer {
					width: <?=$coverpagewidth?>px;
					margin-left: 10px;
				}
				#controls {
					visibility:hidden;
				}
			</style>
	
		";	
	
	echo "
	
		<ul class = 'imagecontainer'>
			<li  class = 'test' id = 'coverpage'><span>".$coverpage."</span></li>
		  </ul>";		  
	
	die();
}

$count = 0;
$images = "<ul class = 'imagecontainer'>";
$commentsArr = array();

foreach($imageInfo as $key => $array) {

	$imageUrlPath = $array['imagepath']; //contains full url path of image eg. http://localhost/xxx/image.jpg
	$thumbPath = $array['thumbpath'];
	$imageid = $array['id'];
	$title = $array['title'];
	$caption = $array['caption'];
	//$comments = $pbdb->fetchComments($imageid);
	$count++;	
	
/**
 * Image Resolution can be high. The below code, gets the desired HEIGHT and WIDTH through
 * the function getImageAspectSize()
 * getImageAspectSize() accepts the full DIRECTORY PATH OF IMAGE
 */

	$imageAspectSize = $pbdb->getImageAspectSize($imageid);	
	$newWidth = $imageAspectSize['newwidth'].'px';
	$newHeight = $imageAspectSize['newheight'].'px';	
/* So now we have the $newHeight and $newWidth */

	$images .= "<li  class = 'thumb' id = '$count'>
	           <img frame='$thumbPath' class='thumb1' imageid = '$imageid' src='$imageUrlPath' title = '$title' longdesc='$caption' />
			   <span class = 'thumb1'></span>
			   </li>";
	$commentsArr[$imageUrlPath] = $imageid;
}

$images .= "</ul>";

echo $images;
echo '<link media="screen, projection" href="'.PLUGIN_URL.'/galleryview/css/jquery.galleryview-3.0-dev.css" rel="stylesheet" type="text/css">';
//print_r($commentsArr);
?>

<script type="text/javascript">
var width = window.innerWidth-window.innerWidth/6.66 - 20;
var height = window.innerHeight-60;
$(document).ready(function() {
	
	$('.imagecontainer').galleryView({
		filmstrip_position: 'top',
		overlay_position: 'top',
		show_filmstrip_nav: true,
		show_overlays: true,
		show_infobar: true,
		panel_width: width,
		panel_height: height,
		panel_scale: 'fit',
		panel_animation: 'crossfade'
		
	});
	
	$(".trigger_comments").live('click',function(e) {
		e.preventDefault();
		$.get("<?=ROOT_URL?>/resources/pages/comments.php?imageid="+$(this).attr('imageid'), function(msg) {			
				
			$("#info").html(msg).slideDown(1000, function(){
			
				$(document).scrollTop(800);
			});
			
		});
		
	});
});

</script>

<div id = "info"/>