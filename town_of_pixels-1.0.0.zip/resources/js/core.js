$(document).ready(function() {
/**
 * We create a variable and assign the old query string here.
 */
oldURL = location.hash;

$.ajaxSetup({cache: true}); 
/**
 * The below lines checks if #GOOGLE-BOT has entered. 
 * If yes, then it makes the invalid bot url to a valid url.
 */ 
	var parameter;
	if(window.location.href.indexOf("?_escaped_fragment_=") > 0)
	{
		window.location.href = window.location.href.replace("?_escaped_fragment_=","#!");
	}
/**
 * Function for detecting #(hash) in url and loading the required page
 */
	//$(window).hashchange();
	$(window).hashchange( function(){
		var s = location.hash;
		if(location.hash.indexOf("?_escaped_fragment_=") >= 0)
		$("#"+window.content_col_id).css('visibility','hidden').load(content_col_path+location.hash.replace("?_escaped_fragment_=","?"), function() {
			$(this).css({visibility:'visible'});
			
		});
		if(location.hash.indexOf("#!") >= 0)
		{
			if(content_col_path!="undefined")content_col_path=defaultCenter;			
			
			newURL = location.hash;
			
			setContentPath();
			
			if(queryMatch(oldURL, newURL)) {
				$(".preload").show();
				
				$("#"+window.content_col_id).load(content_col_path+s.replace("#!","?"),function(){
					//$(this).css({visibility:'visible'});
						
					  setTimeout( function(){
						$(".preload").hide();
						  $("#"+window.content_col_id).css({visibility:'visible'});						  
						  oldURL = newURL;
						},500);		
					
				});
			}
		}
	});
	
	
	
/**
 * Function for Navigation Menu:
 * The click event doesnt load any page. It just removes the query tags from content_col_path(url) variable.
 * This helps the .hashchange() to append the query tag from the url hash tag.
 */
	$("#navigationMenu .sub-section a").live('click',function(e) {							
		
		parameter = $(this).attr('href').replace("#!","?");
	
		if(content_col_path.indexOf("?") > 0)
		{
			var path = content_col_path.split("?");
			content_col_path = path[0];				
		}	 
		
	});
	
	
		
});

function setContentPath() {

	var t = location.hash.split("=");
	var subcatid = parseInt(t[2]);
	var path = content_col_path.split("?");
	var truepathArr = (path[0]).split("/"); //removing all parameters from url and making it array
	var pieces = truepathArr.length;
	
	//SUBCAT_PLUGIN IS DEFINED IN LOAD_SCRIPTS.PHP
	if(subcat_plugin[subcatid].length != 0)
	{
		truepathArr[pieces-2] = subcat_plugin[subcatid];	
	
		var modified = "";
		for(var i = 0; i< pieces;i++) {
			modified += truepathArr[i]+"/"; 
		}
		var x = modified.substring(0, modified.length - 1);
		content_col_path = x;//path[0];	
	}else
	content_col_path = defaultCenter;
}

/**
 * This function will match the old query and the new query and check if content page should be loaded.
 */
function queryMatch(oldURL, newURL) {

	fullquery_old = oldURL.split("=");
	cleanOldURL = "catid="+parseInt(fullquery_old[1])+"&subcatid="+parseInt(fullquery_old[2]);
	
	fullquery_new = newURL.split("=");
	cleanNewURL = "catid="+parseInt(fullquery_new[1])+"&subcatid="+parseInt(fullquery_new[2]);
	
	return (cleanOldURL == cleanNewURL)?false:true;	
}

/**
 * This function will be used by plugins to append the imageid to the URL
 */
function add_image_to_url(imageid) {		
		t = location.hash.split("=");
		location.hash = "!catid="+parseInt(t[1])+"&subcatid="+parseInt(t[2])+"&imageid="+imageid;
}
