var Menu_editor = {
	
	queryURL: "",
	
	images: {
		edit_icon : "",
		upload_icon : "",
		delete_icon : "",
	}, 
	
	init: function() {		
		
		this.changePosition();
		
		this.addCategory();
		this.saveCategory();
		this.renameCategory();
		this.controlCategoryEditor();
		
		this.addSubCategory();		
		this.saveSubCategry();
		this.renameSubCategory();
		this.controlMenueditor();
		
		this.changeState();		
		this.cancelEdit();		
		this.cancelAdd();
		this.tooltip();
		this.showUnMarkedDefaults();
		this.markDefault();
		
		this.applySort();
		$("#cat_subcat").show();
	},	
	applySort: function() {
		
		obj = this;
		
		$(".navigation-list").each(function() {			
			$(this).sortable({		  
			  handle : '.handle',
			  containment: $(this),	
			  items: 'li.sub-section',		 
			  axis: 'y'		  
			});			
		});
	
	},
	changePosition: function() {
		
		obj = this;
		
		$( ".navigation-list" ).bind( "sortupdate", function(event, ui) {			
			if($(this).parent().attr('id') == "menueditor")var order = "sub_cat_pos=true&loadpaths=true&";
			if($(this).parent().attr('id') == "categoryeditor")var order = "cat_pos=true&loadpaths=true&";
			
			$(this).children('li').each(function(idx, elm) {
				
				if(elm.id.length > 0)
				{					
					var idsplit = elm.id.split('_');
					var common = idsplit[0];
					var linenum = idsplit[1];					
					order += common + '[]='+linenum+'&';
				}
				
			});                                     
			$.ajax({url:obj.queryURL + '/admin/classes/queries.class.php',type: "POST", data:order});
				
		});
	
	},
	addCategory: function() {
		
		obj = this;
		
		$('#categoryeditor .add_cat').unbind('click').live('click',function() {
			$("#listItem_x").fadeOut().remove();
			$('#categoryeditor .navigation-list').append("<li id='listItem_x' class='sub-section'><span><input type = 'text' id = 'new_cat_name'><input type = 'submit' value = 'Save' class = 'save_cat_but button'><input type = 'submit' value = 'Cancel' class = 'cancel button'></span></li>");
			$("#new_cat_name").focus().select();
			$(".canceledit").click();
			
		});
	
	},
	saveCategory: function() {
		
		obj = this;
		
		$("#create_new_cat .save_cat_but, #listItem_x .save_cat_but").die('click').live('click',function() {
			$.ajax({
			
				url: obj.queryURL + "/admin/classes/queries.class.php",
				type: 'POST',
				data: 'loadpaths=true&savecategory='+$("#new_cat_name").val(),
				success: function(id) {	
					
					$("#categoryeditor #listItem_x").fadeIn();
					$("<ul class = 'navigation-list' id='"+id.trim()+"'>"+
						"<li class = 'section-title'>"+
							"<span class = 'cat_name'>"+$("#new_cat_name").val()+"</span>"+
							"<span class = 'add_new_sub'>Add New Sub Category</span>"+
						"</li>"+
					"</ul>").appendTo($("#menueditor"));
					
					
					$("<li class = 'sub-section' id = 'listItem_"+id.trim()+"'>"+
							"<span class='controls'>"+
								"<img title = 'Delete this category (Its sub categories will also be deleted)' class = 'delete_cat' src = '" + obj.images.delete_icon + "'/>"+
								"<img class = 'edit_cat' src = '" + obj.images.edit_icon + "'/>"+
								//"<img class = 'upload_cat' src = '" + obj.images.upload_icon + "'/>"+
							"</span>"+
							"<span class='handle section'>"+$("#new_cat_name").val()+"</span>"+
					  "</li>")
					  .hide().appendTo($("#categoryeditor .navigation-list")).fadeIn();
					
					
					$("#categoryeditor #listItem_x").remove();
					
				}
			});
		});
	},
	renameCategory: function() {
		
		obj = this;
		
		$(".update_cat_but").die("click").live("click", function() {
			var catid = $(this).parent().parent().parent().attr("id").split("_");
			var handle = $(this);
			var newcatname = handle.parent().find('#new_cat_name').val()

			$(".canceledit").click();	
		
			   $.ajax({
				  type: 'POST',
				  url: obj.queryURL + "/admin/classes/queries.class.php",
				  data: "renamecat=true&catname="+newcatname+"&catid="+catid[1],
				  success: function(msg) {
					$selector.html(newcatname);
					
					$("#menueditor #"+catid[1]).find('.cat_name').html(newcatname);
				  
				  }
				  
				});
		
		});
	
	},
	controlCategoryEditor: function() {
		
		obj = this;
		
		$("#categoryeditor .controls img").die('click').live('click', function() {
			var catid,action;
			catid = $(this).parent().parent().attr("id").split("_");			
			action = $(this).attr('class');
			
			//if(action == "upload_cat")
			//$("#content_col").load("<?=ROOT_URL.'/admin/'?>demo.php?loadpaths=false&catid="+catid+"&subcatid="+subcatid[1]);
			
			if(action == "delete_cat")
			{
				$( "#delete-confirm" ).dialog({
					resizable: false,
					height:140,
					modal: true,
					buttons: {
						"Delete": function() {
							$(this).dialog( "close" );
							$.ajax({
								  type: 'POST',
								  url: obj.queryURL + "/admin/classes/queries.class.php",
								  data: "deletecat=true&catid="+catid[1],
								  success: function(msg) {										
										$("#menueditor .navigation-list#"+catid[1].trim()).fadeOut('slow').remove();	
										$("#categoryeditor #listItem_"+catid[1]).fadeOut('slow').remove();
																			
								  }									  
							});	
						},
						Cancel: function() {
							$( this ).dialog( "close" );
						}
					}
				});					
				
			}
			if(action == "edit_cat")
			{
				$(".cancel,.canceledit").click();
				$selector = $(this).parent().parent().find('.handle');				
				catname = $selector.html();
				$selector.html( 
								'<span class = "rename_cat">'+
									'<input type="text" id="new_cat_name" value="'+catname+'">'+
									'<input type="submit" value="Save" class="update_cat_but button">'+
									'<input type="submit" value="Cancel" class="canceledit button">'+							   
							    '</span>'
							   );				
			}
		}); 
	
	},	
	addSubCategory: function() {
		
		obj = this;
		
		$('.section-title .add_new_sub').unbind('click').live('click',function() {
			$('.navigation-list').removeClass('clicked');
			$(this).parent().parent().addClass('clicked');
			$("#listItem_x").fadeOut().remove();
			$('#menueditor .navigation-list.clicked').append("<li id='listItem_x' class='sub-section'><span><input type='text' id='new_sub_cat_name'><input type='submit' class='save_sub_cat_but button' value='Save'><input type='submit' class='cancel button' value='Cancel'></span></li>");
			$("#new_sub_cat_name").focus().select();
			$(".canceledit").click();
			
		});
		
	},
	saveSubCategry: function() {
		
		obj = this;
		
		$("#listItem_x .save_sub_cat_but").die('click').live('click',function() {
			$.ajax({
			
				url: obj.queryURL + "/admin/classes/queries.class.php",
				type: 'POST',
				data: 'loadpaths=true&savesubcategory='+$("#new_sub_cat_name").val()+'&catid='+$(".navigation-list.clicked").attr('id'),
				success: function(id) {
				
					$("#menueditor #listItem_x").fadeIn();
					$("<li class = 'sub-section' id = 'listItem_"+id.trim()+"'>"+
							"<span class='controls'>"+
								"<img title = 'Delete' class = 'delete_sub_cat' src = '" + obj.images.delete_icon + "'/>"+
								"<img title = 'Rename' class = 'edit_sub_cat' src = '" + obj.images.edit_icon + "'/>"+
								"<img title = 'Browse & Upload' class = 'upload_sub_cat' src = '" + obj.images.upload_icon + "'/>"+
								"<a href='#' class = 'activate'>activate</a>"+
							"</span>"+
							"<span class='handle section'>"+$("#new_sub_cat_name").val()+"</span>"+
					  "</li>")
					  .hide().appendTo($(".navigation-list.clicked")).fadeIn();
					 
					
					$("#menueditor #listItem_x").remove();
					
				}
			});
		});
		
	},
	renameSubCategory: function() {
		
		obj = this;
		
		$(".update_sub_cat_but").die("click").live("click", function() {
		
			var subcatid = $(this).parent().parent().parent().attr("id").split("_");
			var handle = $(this);
			var newsubcatname = handle.parent().find('#new_sub_cat_name').val()
			
			$(".canceledit").click();			
			   $.ajax({
				  type: 'POST',
				  url: obj.queryURL + "/admin/classes/queries.class.php",
				  data: "renamesubcat=true&subcatname="+newsubcatname+"&subcatid="+subcatid[1],
				  success: function(msg) {
					$selector.html(newsubcatname);
					
				  }
				  
				});
		
		});
	
	},
	controlMenueditor: function() {
		
		obj = this;
		
		$("#menueditor .controls img").die('click').live('click', function() {

			var catid = $(this).parent().parent().parent().attr("id");
			var subcatid = $(this).parent().parent().attr("id").split("_");			
			var action = $(this).attr('class');
			
			if(action == "upload_sub_cat")
			{			
				obj.startSpinner();
				$("#content_col").animate({opacity: 0}, 100,function() {
					
					$(this).load(obj.queryURL+"/admin/pages/upload.php?loadpaths=false&catid="+catid+"&subcatid="+subcatid[1],function(){
						
						$("#content_col").animate({opacity: 1}, 100);
						obj.stopSpinner();
					});
					
				});
			}
			
			if(action == "delete_sub_cat")
			{
			
				$( "#delete-confirm" ).dialog({
					resizable: false,
					height:140,
					modal: true,
					buttons: {
						"Delete": function() {
							$(this).dialog( "close" );
							$.ajax({
							  type: 'POST',
							  url: obj.queryURL + "/admin/classes/queries.class.php",
							  data: "deletesubcat=true&subcatid="+subcatid[1],
							  success: function(msg) {
								
								$("#menueditor #listItem_"+subcatid[1]).fadeOut('slow').remove();
							  
							  }
							  
							});
						},
						Cancel: function() {
							$( this ).dialog( "close" );
						}
					}
				});		
			
			}
			if(action == "edit_sub_cat")
			{
				$(".cancel,.canceledit").click();
				$selector = $(this).parent().parent().find('.handle');				
				subcatname = $selector.html();
				$selector.html( 
								'<span class = "rename_sub_cat">'+
									'<input type="text" id="new_sub_cat_name" value="'+subcatname+'">'+
									'<input type="submit" value="Save" class="update_sub_cat_but button">'+
									'<input type="submit" value="Cancel" class="canceledit button">'+							   
							    '</span>'
							   );				
			}
			
			//This is a hack. Wasnt able to remove tipsy after clicking on folder.
			$(".tipsy").remove();
		});
		
	
	},	
	changeState: function() {
		
		obj = this;
		
		$("#menueditor .controls a").die('click').live('click', function(e) {
		
			e.preventDefault();
			var state = $(this).attr('class');
			var handler = $(this);
			var subcatid = $(this).parent().parent().attr("id").split("_");
			var newclass = ($(this).attr('class') == "activate")?"de-activate":"activate";
			$.ajax({
				  type: 'POST',
				  url: obj.queryURL + "/admin/classes/queries.class.php",
				  data: "changeState=true&state="+state+"&sub_cat_id="+subcatid[1],
				  success: function(msg) {
					handler.html(newclass);
					handler.attr('class',newclass);					
				  }
				  
			});	
		
		});
	
	},
	cancelEdit: function() {
		
		obj = this;
		
		$(".cancel").live('click',function() {
			$("#listItem_x").fadeOut('slow').remove();
			$(".canceledit").click();
		});		
	},
	cancelAdd: function() {
		
		obj = this;
		
		$(".canceledit").die('click').live('click',function() {
			
			if($(this).parent().attr("class") == "rename_cat")
			{
				$(".rename_cat").remove();
				$selector.html(catname);
			}
			else{
				$(".rename_sub_cat").remove();
				$selector.html(subcatname);
			}
		});
	},
	tooltip: function(){
		obj = this;
		
		$('img').tipsy({live: true,gravity: 'e'});
	
	},
	showUnMarkedDefaults: function() {
		obj = this;
		$("#menueditor li.sub-section").hover(function() {		
			$(this).find(".markdefault").show();		
		},function() {
			$(".markdefault").hide();
		});
	},
	markDefault: function() {
		$("#menueditor li.sub-section .markdefault").live('click',function() {
			$("#menueditor li.sub-section .unmarkdefault").addClass('markdefault').removeClass('unmarkdefault').html('Mark Default');
			$(".markdefault").hide();
			//$(this).parent().parent().find('.unmarkdefault').addClass('markdefault').removeClass('unmarkdefault').html('Mark Default').hide();
			$(this).removeClass('markdefault').addClass('unmarkdefault').html('Default').show();
			
			$.ajax({
				  type: 'POST',
				  url: obj.queryURL + "/admin/classes/queries.class.php",
				  data: "defaulter=true&sub_cat_id="+$(this).attr('subcatid'),
				  success: function(msg) {
					//handler.html(newclass);
					//handler.attr('class',newclass);					
				  }
				  
			});
		});
	
	},
	startSpinner: function() {
		
		var spinner = $(".preload").clone();
		spinner.attr('id','spinner').html("<img src = '"+spinnerImage+"'>").appendTo('body');
		$("#spinner").show();
	
	},
	stopSpinner: function() {
		
		$("#spinner").fadeOut("slow",function(){
			$(this).remove();
		});
	
	},
};